using Ocelot.DependencyInjection;
using Ocelot.Middleware;

namespace ShopEZ.ApiGateway
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            // LOAD OCELOT CONFIGURATION
            
            builder.Configuration .AddJsonFile("ocelot.json", optional: false,reloadOnChange: true);
            ///cors

            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAngular", policy =>
                    {
                      policy.WithOrigins("http://localhost:4200",
                                        "https://localhost:4200")
                              .AllowAnyHeader()
                              .AllowAnyMethod();
                    });
            });

            //ADD OCELOT
            builder.Services.AddOcelot();

            var app = builder.Build();

            // HTTPS
            
            app.UseHttpsRedirection();
            //cors

            app.UseCors("AllowAngular");

            //USE OCELOT
            await app.UseOcelot();

            app.Run();
        }
    }
}