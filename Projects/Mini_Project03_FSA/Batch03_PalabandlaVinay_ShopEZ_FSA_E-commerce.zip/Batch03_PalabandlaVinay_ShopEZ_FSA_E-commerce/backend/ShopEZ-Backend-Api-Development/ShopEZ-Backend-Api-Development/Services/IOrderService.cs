﻿using ShopEZ_Backend_Api_Development.DTOs;
using ShopEZ_Backend_Api_Development.Models;

namespace ShopEZ_Backend_Api_Development.Services
{
    public interface IOrderService
    {
        Task<IEnumerable<Order>> GetAllAsync();
        Task<Order> GetByIdAsync(int id);
        //  Task CreateOrderAsync(OrderDTO dto);
        Task<Order> CreateOrderAsync(OrderDTO dto);
    }
}
