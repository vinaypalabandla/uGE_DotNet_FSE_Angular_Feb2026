import { HttpInterceptorFn } from '@angular/common/http';

export const authInterceptor: HttpInterceptorFn = (req, next) => {

  let token: string | null = null;

  // check browser before using localStorage
  if (typeof window !== 'undefined') {
    const user = localStorage.getItem('user');
    token = user ? JSON.parse(user)?.token : null;
  }

  if (token) {
    const cloned = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
    return next(cloned);
  }

  return next(req);
};