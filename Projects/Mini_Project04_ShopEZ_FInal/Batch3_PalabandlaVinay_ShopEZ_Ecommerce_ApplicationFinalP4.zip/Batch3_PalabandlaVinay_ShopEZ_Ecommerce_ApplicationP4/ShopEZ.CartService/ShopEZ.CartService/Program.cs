
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using ShopEZ.CartService.Data;
using ShopEZ.CartService.Middlewares;
using ShopEZ.CartService.Repositories;
using ShopEZ.CartService.Services;
using System.Text;
using System.Text.Json.Serialization;

namespace ShopEZ.CartService
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            // Controllers
            builder.Services.AddControllers().AddJsonOptions(options =>
                 {
                     options.JsonSerializerOptions
                         .ReferenceHandler = ReferenceHandler.IgnoreCycles;
                 });
            // Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
            builder.Services.AddOpenApi();
            // Swagger
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            // Database Connection
            builder.Services.AddDbContext<ApplicationDbContext>( options =>
                {  options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"));
                });
            // Dependency Injection
            builder.Services.AddScoped<ICartRepository, CartRepository>();

            builder.Services.AddScoped<ICartService, CartServiceManager>();

            // JWT Authentication
           
            builder.Services .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                 .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters =
                        new TokenValidationParameters
                        {
                            ValidateIssuer = true,

                            ValidateAudience = true,

                            ValidateLifetime = true,

                            ValidateIssuerSigningKey = true,

                            ValidIssuer = builder.Configuration["Jwt:Issuer"]!,

                            ValidAudience = builder.Configuration["Jwt:Audience"]!,

                            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(
                                        builder.Configuration["Jwt:Key"]!))
                        };
                });

            // Authorization
            builder.Services.AddAuthorization();
            // CORS
            builder.Services.AddCors(options =>
            {
                options.AddPolicy(  "AllowAngular", policy =>
                    {
                        policy.WithOrigins("http://localhost:4200")
                            .AllowAnyHeader()
                            .AllowAnyMethod();
                    });
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.MapOpenApi();
                //swagger middlewares
                app.UseSwagger();

                app.UseSwaggerUI();
            }
            //HTTPS
         //   app.UseHttpsRedirection();
            //ECEPTION MIDLEWARE
            app.UseMiddleware<ExceptionMiddleware>();
            // CORS
            app.UseCors("AllowAngular");
            // Authentication
          
            app.UseAuthentication();
            // Authorization
            app.UseAuthorization();

            //Controllers
            app.MapControllers();

            //docker compose purpose  

            using (var scope = app.Services.CreateScope())
            {
                var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

                db.Database.Migrate();
            }

            app.Run();
        }
    }
}
