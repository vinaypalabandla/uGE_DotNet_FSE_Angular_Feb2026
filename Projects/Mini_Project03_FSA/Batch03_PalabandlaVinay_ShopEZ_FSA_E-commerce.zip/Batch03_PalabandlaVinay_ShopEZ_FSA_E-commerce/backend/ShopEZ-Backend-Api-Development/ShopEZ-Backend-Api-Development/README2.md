# ShopEZ – E-Commerce API (Phase 3)

ASP.NET Core Web API for **ShopEZ**: **SQL Server** + **Entity Framework Core**, layered **Controller → Service → Repository → DbContext**, **DTOs** (entities are not returned from write operations), **async/await** end-to-end, inline **data annotations** inside DTOs, **JWT Bearer** authentication, **password hashing** (`IPasswordHasher<User>`), **Swagger** (JWT **Authorize**), **global exception middleware** (maps business exceptions to HTTP status codes), and **HSTS** in non-Development environments.

---

## Prerequisites

- [.NET SDK](https://dotnet.microsoft.com/download) (project targets **net10.0**)
- **SQL Server** or **LocalDB** (default connection string uses LocalDB)
- **Visual Studio 2022+** or **VS Code** (optional)

---

## Project layout

| Path | Purpose |
|------|---------|
| `ECommerce.API/Controllers/` | HTTP: `AuthController`, `ProductsController`, `OrdersController` — all actions are `async Task` |
| `ECommerce.API/Services/` | Business rules, JWT issuance, order totals (LINQ), registration |
| `ECommerce.API/Repositories/` | EF Core persistence (`*Async`, `CancellationToken`) |
| `ECommerce.API/Data/` | `ApplicationDbContext`, relationships, seed users (hashed passwords) |
| `ECommerce.API/Models/` | Entities + navigation properties |
| `ECommerce.API/DTOs/` | Request/response models with validation attributes |
| `ECommerce.API/Middleware/GlobalExceptionMiddleware.cs` | `BadRequestException` → 400, `NotFoundException` → 404, `ConflictException` → 409, others → 500 |

---

## Run and debug

### 1. Open the project

Open the folder containing `ECommerce.API.slnx` and the `ECommerce.API` project.

### 2. Connection string

Edit `ECommerce.API/appsettings.json` if needed:

```json
"ConnectionStrings": {
  "DefaultConnection": "Server=(localdb)\\VINAYKUMAR\\SQLSERVER;Database=ShopEZDb;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True"
}
```

### 3. EF Core migrations

From `ECommerce.API/ECommerce.API`:

```powershell
dotnet ef database update --project "ECommerce.API.csproj"
```

Install the tool if required:

```powershell
dotnet tool install --global dotnet-ef
```

This creates **Users**, **Products**, **Orders**, **OrderItems**, seeds **two users** (passwords stored as **hashes**, not plain text), and adds a **unique index on `Email`**.

### 4. Run the API

```powershell
dotnet run --project "ECommerce.API.csproj"
```

Default URLs (see `Properties/launchSettings.json`): **https://localhost:7121** and **http://localhost:5081**.

### 5. Swagger

In Development, open **https://localhost:7121/swagger** (port may differ).

1. **Register** `POST /api/auth/register` (optional) with role `Admin` or `Customer`, or use seeded accounts below.
2. **Login** `POST /api/auth/login` — copy `token`.
3. Click **Authorize** → enter `Bearer <token>` (or only the token, depending on UI).
4. Call protected endpoints: **POST/PUT/DELETE** `/api/products` (any logged-in user), **/api/orders** (Customer or Admin).

---

## Register request body

Use one of the allowed roles: `Admin` or `Customer`.

```json
{
  "name": "Demo User",
  "email": "demo.user@shopez.com",
  "password": "Password@123",
  "confirmPassword": "Password@123",
  "role": "Customer"
}
```

---

## API summary

| Area | Endpoint | Auth |
|------|----------|------|
| Register | `POST /api/auth/register` | No |
| Login | `POST /api/auth/login` | No |
| Products | `GET /api/products`, `GET /api/products/{id}` | No |
| Products | `POST` / `PUT` / `DELETE` `/api/products[...]` | **Authenticated user** (JWT) |
| Orders | `POST` / `GET` / `GET {id}` `/api/orders` | **Customer** or **Admin** (JWT) |

**JWT** is configured under `"Jwt"` in `appsettings.json` (`Issuer`, `Audience`, `Key`). Change the **Key** for production.

---

## Seeded users (after migrations)

| Role | Email | Password (for login) |
|------|--------|----------------------|
| Customer | `customer1@gmail.com` | `Password@123` |
| Admin | `admin1@gamil.com` | `Admin@123` |

Passwords are stored using **ASP.NET Core Identity-compatible password hashing** (V3 format). The database column `Users.Password` holds the **hash**, not the plain password.

**Orders:** A **Customer** JWT may only create orders for their own `userId` (claim). **GET** orders returns only that customer’s orders unless the caller is **Admin** (sees all).

---

## Validation rules (summary)

| Field / area | Rules |
|--------------|--------|
| **Name** (register) | Required, **3–100** characters |
| **Email** (register & login) | Required, valid email format (`[EmailAddress]`) |
| **Password** (register) | 
| **Confirm password** | Must match password |
| **Role** (register) | Required, must be exactly `Admin` or `Customer` |
| **Product name / description / imageUrl** (POST & PUT) | Required where applicable; strings **≥3** characters; sensible `MaxLength` |
| **Price** | `> 0`; **Stock** `≥ 0` |
| **Order** | `UserId` valid; **items** non-empty; each **quantity** `≥ 1` |

`PUT` and `POST` on products use the same DTO validation via `CreateProductDto` / `UpdateProductDto`.

---

## Order creation logic (assignment checklist)

Implemented in `OrderService.CreateOrderAsync`:

- Cart **items** required; **quantity** validated (`> 0`) via annotations + service checks.
- **User** must exist.
- **Products** must exist; **stock** checked against quantity.
- **Total** computed with **LINQ** (`Sum` over line items: price × quantity).
- Persists **Order** and **OrderItems**; response reloads product names via `Include`.

---

## Security & exception handling

- **JWT:** Bearer scheme; role claims **Admin** / **Customer**; `[Authorize]` on controllers/actions as needed.
- **Passwords:** Hashed with `IPasswordHasher<User>`; no plain-text storage for new registrations; seed data uses hashes.
- **HTTPS:** `UseHttpsRedirection`; **HSTS** when not in Development.
- **Global errors:** `GlobalExceptionMiddleware` returns JSON `{ "message": "..." }` with appropriate status codes for known exceptions; unexpected errors return **500** with a generic message.

---

## Evaluation rubric mapping (problem statement)

| Criteria | Where it is covered |
|----------|---------------------|
| Product CRUD, Orders CRUD | Controllers + services + repositories |
| Order validation, LINQ total, Order + OrderItems | `OrderService` |
| EF relationships, migrations, DbContext | `ApplicationDbContext`, `Migrations/` |
| Layered architecture + DI | Folders + `Program.cs` |
| DTOs | `DTOs/` |
| Async/await | Controllers, services, repositories |
| Validation + exception handling | Data annotations + `GlobalExceptionMiddleware` + domain exceptions |
| Swagger | Swashbuckle UI with JWT authorize |

> **Note:** The LMS may show “Maximum Marks: 1” as a portal quirk; the rubric in the assignment PDF totals **100** marks.

---

## Submission

Zip the **backend source** (you may exclude `bin/`, `obj/`, `.vs/`). Max **50 MB**, **.zip** only, per instructions.

---

## Troubleshooting

- If `dotnet build` fails because **ECommerce.API.exe is locked**, stop `dotnet run` or the debugger.
- If login fails after pulling changes, run **`dotnet ef database update`** so password hashes and the email unique index are applied.
