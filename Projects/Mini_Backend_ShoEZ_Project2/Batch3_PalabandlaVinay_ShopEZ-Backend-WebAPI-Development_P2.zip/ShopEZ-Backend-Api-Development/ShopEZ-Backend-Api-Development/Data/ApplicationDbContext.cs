﻿using Microsoft.EntityFrameworkCore;
using ShopEZ_Backend_Api_Development.Models;
using static System.Runtime.InteropServices.JavaScript.JSType;
namespace ShopEZ_Backend_Api_Development.Data
{
 //Db Context inherit  it represents database
 //Act as bridge  b/w DB And C# 
    public class ApplicationDbContext : DbContext
    {
        //Dbcontext ==> database manager
        // Recives configuration(conection string) Passes config to parent DbContext -->base(options)
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext>options) : base(options)
        {
        }
        //Inside DB Tables DbSet is tables collections
        public DbSet<User> Users { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //One User → Many Orders  
            modelBuilder.Entity<Order>()
                .HasOne(o => o.User)
                .WithMany(u => u.Orders)
                .HasForeignKey(o => o.UserId);

           // One Order → Many OrderItems
              modelBuilder.Entity<OrderItem>()
                .HasOne(o => o.Order)
                .WithMany(o => o.OrderItems)
                .HasForeignKey(o => o.OrderId);
            //One Product → Many OrderItems
            modelBuilder.Entity<OrderItem>()
                .HasOne(o => o.Product)
                .WithMany(p => p.OrderItems)
                .HasForeignKey(o => o.ProductId);


        }
    }
}
