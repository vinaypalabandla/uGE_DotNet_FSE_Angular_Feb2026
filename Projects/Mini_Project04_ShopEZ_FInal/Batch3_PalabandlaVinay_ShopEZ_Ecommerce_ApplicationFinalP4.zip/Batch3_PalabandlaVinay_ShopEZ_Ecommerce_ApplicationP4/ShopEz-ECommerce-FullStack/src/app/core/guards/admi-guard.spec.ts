import { TestBed } from '@angular/core/testing';
import { CanActivateFn } from '@angular/router';
import { adminGuardTsGuard } from './admi-guard';

describe('adminGuardTsGuard', () => {

  const executeGuard: CanActivateFn = (...params) =>
    TestBed.runInInjectionContext(() => adminGuardTsGuard(...params));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  //  BASIC TEST
  it('should create', () => {
    expect(executeGuard).toBeTruthy();
  });

  //  FUNCTIONAL TEST
  it('should allow access (returns true)', () => {
    const result = executeGuard({} as any, {} as any);
    expect(result).toBeTrue();
  });

});