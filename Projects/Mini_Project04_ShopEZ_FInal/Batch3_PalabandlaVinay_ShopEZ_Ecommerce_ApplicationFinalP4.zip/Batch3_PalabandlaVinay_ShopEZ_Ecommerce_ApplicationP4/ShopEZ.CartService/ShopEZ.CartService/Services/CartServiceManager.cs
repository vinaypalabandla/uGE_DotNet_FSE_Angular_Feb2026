﻿using ShopEZ.CartService.DTOs;
using ShopEZ.CartService.Models;
using ShopEZ.CartService.Repositories;

namespace ShopEZ.CartService.Services
{
    // Cart Service Class
    public class CartServiceManager  : ICartService
    {
        // Repository Object
        private readonly ICartRepository  _repository;

        // Constructor
        public CartServiceManager( ICartRepository repository)
        {
            _repository = repository;
        }

        //ADD TO CART
        public async Task<Cart>AddToCart(AddCartDTO dto)
        {
            return await _repository.AddToCart(dto);
        }
       //GET USER  CART
        public async Task<Cart?> GetCartByUserId(int userId)
        {
            return await _repository.GetCartByUserId(userId);
        }
       //UPDATE CART ITEM
        public async Task<CartItem?> UpdateCartItem(UpdateCartDTO dto)
        {
            return await _repository.UpdateCartItem(dto);
        }

      //REMOVE CARTITEM
        public async Task<bool> RemoveCartItem(int cartItemId)
        {
            return await _repository  .RemoveCartItem(cartItemId);
        }
        //CLEAR CART
        public async Task<bool> ClearCart(int userId)
        {
            return await _repository.ClearCart(userId);
        }
    }
}