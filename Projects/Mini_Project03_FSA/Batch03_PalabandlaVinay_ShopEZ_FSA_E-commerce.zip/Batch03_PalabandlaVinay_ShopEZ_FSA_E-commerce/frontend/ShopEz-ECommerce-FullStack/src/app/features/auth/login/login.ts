import { Component } from '@angular/core';
import { AuthService } from '../../../core/services/auth-service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterModule],
  templateUrl: './login.html',
  styleUrls: ['./login.css'],
})
export class Login {

  email: string = '';
  password: string = '';
  errorMsg: string = '';

  constructor(
    private auth: AuthService,
    private router: Router
  ) { }

  login() {

    // ADDED FRONTEND VALIDATION
    if (!this.email || !this.password) {
      this.errorMsg = 'Please enter email and password';
      return;
    }

    const data = {
      email: this.email,
      password: this.password
    };

    this.auth.login(data).subscribe({

      next: (res: any) => {
        console.log("LOGIN RESPONSE:", res);

        const userData = {
          email: this.email,
          token: res.token,
          role: this.email === 'admin1@gmail.com' ? 'Admin' : 'Customer'
        };

        this.auth.saveUser(userData);

        if (userData.role === 'Admin') {
          this.router.navigate(['/admin']);
        } else {
          this.router.navigate(['/']);
        }
      },

      error: () => {
        this.errorMsg = 'Invalid email or password';
      }
    });
  }
}