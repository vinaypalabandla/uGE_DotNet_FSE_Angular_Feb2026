﻿using global::ShopEZ.UserService.Models;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
//using ShopEZ.UserService.Models;


namespace ShopEZ.UserService.Helpers
{
    
        public class JwtHelper
        {
            // IConfiguration object
            private readonly IConfiguration _config;

            // Constructor
            public JwtHelper(IConfiguration config)
            {
                _config = config;
            }

            // Generate JWT Token
            public string GenerateToken(User user)
            {
                // Claims
                var claims = new[]
                {
                new Claim(ClaimTypes.Name, user.Email!),
                new Claim(ClaimTypes.Role, user.Role!)
            };

                // Secret Key
                var key = new SymmetricSecurityKey(
                    Encoding.UTF8.GetBytes(_config["Jwt:Key"]!)
                );

                // Signing Credentials
                var creds = new SigningCredentials( key, SecurityAlgorithms.HmacSha256
                );

                // JWT Token
                var token = new JwtSecurityToken(
                    issuer: _config["Jwt:Issuer"],
                    audience: _config["Jwt:Audience"],
                    claims: claims,
                    expires: DateTime.Now.AddHours(2),
                    signingCredentials: creds
                );

                // Return Token
                return new JwtSecurityTokenHandler()
                    .WriteToken(token);
            }
        }
    
}
