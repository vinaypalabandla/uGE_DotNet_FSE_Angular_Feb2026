﻿using ShopEZ_Backend_Api_Development.Models;

namespace ShopEZ_Backend_Api_Development.Repositories
{
    public interface IProductRepository
    {
        Task<IEnumerable<Product>> GetAllAsync();
        Task<Product> GetByIdAsync(int id);
        Task<Product> AddAsync(Product product);
        Task<Product>UpdateAsync(Product product);
        Task<bool> DeleteAsync(int id);
    }
}
