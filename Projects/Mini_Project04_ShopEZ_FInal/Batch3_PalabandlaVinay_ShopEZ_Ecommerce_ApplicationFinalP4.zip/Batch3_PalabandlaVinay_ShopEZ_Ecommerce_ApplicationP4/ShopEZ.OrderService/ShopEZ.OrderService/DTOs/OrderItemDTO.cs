﻿namespace ShopEZ.OrderService.DTOs
{
    //Order ItemID DTos
    public class OrderItemDTO
    {
        // Product Id
        public int ProductId { get; set; }

        // Quantity
        public int Quantity { get; set; }

        // Price
        public decimal Price { get; set; }

    }
}
