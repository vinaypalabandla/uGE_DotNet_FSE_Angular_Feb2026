﻿using System.ComponentModel.DataAnnotations;

namespace ShopEZ_Backend_Api_Development.DTOs
{
    public class OrderDTO
    {
        [Required]
        public int UserId { get; set; }

        [Required]
        [MinLength(1, ErrorMessage = "At least one item required")]
        public ICollection<OrderItemDTO> Items { get; set; }
    }
}
