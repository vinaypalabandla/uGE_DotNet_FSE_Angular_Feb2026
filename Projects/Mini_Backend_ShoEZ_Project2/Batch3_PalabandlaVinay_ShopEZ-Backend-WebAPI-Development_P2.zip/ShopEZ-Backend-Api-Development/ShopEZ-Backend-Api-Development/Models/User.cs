﻿using System.ComponentModel.DataAnnotations;

namespace ShopEZ_Backend_Api_Development.Models
{
    //One user --> Many orders
    public class User
    {
        [Key] // PK
        public int UserId { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(50, ErrorMessage = "Max 50 characters allowed")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid Email format")] // Valid  email Enter here  only
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [MinLength(6, ErrorMessage = "Minimum 6 characters required")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Role is required")]
        public string Role { get; set; }

        // Navigation Property1 User => Many Orders
        public ICollection<Order> Orders { get; set; } = new List<Order>();
    }
}