﻿using System.ComponentModel.DataAnnotations;

namespace ShopEZ.CartService.Models
{
    //Cart Model
    public class Cart
    {
        // Primary Key
        [Key]
        public int CartId { get; set; }

        // User Id
        public int UserId { get; set; }

        // Navigation Property
        public List<CartItem> CartItems{ get; set; }= new List<CartItem>();
    }
}
  
