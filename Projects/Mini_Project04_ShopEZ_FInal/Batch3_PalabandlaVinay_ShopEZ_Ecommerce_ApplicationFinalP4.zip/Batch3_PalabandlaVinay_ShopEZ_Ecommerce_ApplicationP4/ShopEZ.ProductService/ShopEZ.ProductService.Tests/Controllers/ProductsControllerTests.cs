﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using ShopEZ.ProductService.Controllers;
using ShopEZ.ProductService.DTOs;
using ShopEZ.ProductService.Models;
using ShopEZ.ProductService.Services;
using Xunit;

namespace ShopEZ.ProductService.Tests.Controllers
{
    public class ProductsControllerTests
    {
        // Mock service
        private readonly Mock<IProductServiceManager> _mockService;

        // Controller object
        private readonly ProductsController _controller;

        // Constructor
        public ProductsControllerTests()
        {
            _mockService = new Mock<IProductServiceManager>();
            _controller = new ProductsController(_mockService.Object);
        }

        // GET ALL PRODUCTS
        [Fact]
        public async Task GetAllProducts_ReturnsOk()
        {
            // Arrange
            _mockService .Setup(x => x.GetAllProducts()).ReturnsAsync(new List<Product>());
            // Act
            var result = await _controller.GetAllProducts();
            // Assert
            Assert.IsType<OkObjectResult>(result);
        }

        

        // ADD PRODUCT
        [Fact]
        public async Task AddProduct_ReturnsOk()
        {
            // Arrange
            var dto = new ProductDTO();
            _mockService.Setup(x => x.AddProduct(dto)).ReturnsAsync(1);
            // Act
            var result = await _controller.AddProduct(dto);
            // Assert
            Assert.IsType<OkObjectResult>(result);
        }

        // DELETE PRODUCT
        [Fact]
        public async Task DeleteProduct_ReturnsOk()
        {
            // Arrange
            _mockService.Setup(x => x.DeleteProduct(1)).ReturnsAsync(1);
            // Act
            var result = await _controller.DeleteProduct(1);
            // Assert
            Assert.IsType<OkObjectResult>(result);
        }

        // REDUCE STOCK SUCCESS
        [Fact]
        public async Task ReduceStock_ReturnsOk()
        {
            // Arrange
            _mockService.Setup(x => x.ReduceStock(1, 2)).ReturnsAsync(1);
            // Act
            var result = await _controller.ReduceStock(1, 2);
            // Assert
            Assert.IsType<OkObjectResult>(result);
        }

        // REDUCE STOCK FAILED
        [Fact]
        public async Task ReduceStock_ReturnsBadRequest()
        {
            // Arrange
            _mockService.Setup(x => x.ReduceStock(1, 2)).ReturnsAsync(0);
            // Act
            var result = await _controller.ReduceStock(1, 2);
            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }
    }
}