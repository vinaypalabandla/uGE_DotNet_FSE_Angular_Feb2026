import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../../core/services/auth-service';
import { CommonModule } from '@angular/common';
import { CartService } from '../../../core/services/cart.service';


@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  user: any = null;
  //CART COUNT
  cartCount = 0;
  //THIS COUNT QUNTITY
  productCount = 0;

  constructor(
    private router: Router,
    private authService: AuthService,
    private cartService: CartService
  ) { }

  ngOnInit() {

    this.authService.user$.subscribe(u => {
      this.user = u;
      this.cartService.loadUserCart();
    });

    this.cartService.cart$.subscribe(items => {
      //total qunatity
      this.cartCount = items.reduce((sum, i) => sum + i.quantity, 0); // THISIS THE CART BADGE LOGIC
      // total unique products
      this.productCount = items.length;
      console.log('Cart Items:', items); //  IT WROTE FOR CHECK PURPOSE
    });

  }

  goToCart() {
    if (!this.user) {
      this.router.navigate(['/login']);
    } else {
      this.router.navigate(['/cart']);
    }
  }

  logout() {
    this.authService.logout();
    //CLEAR CURRENT SESSION MEMORY
    this.cartService.clearCart();

    this.router.navigate(['/login']);
  }
}
