﻿//importing  namespaces
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ShopEZ.ProductService.Models
{
        // Product Model
    public class Product
    {

            // Product Primary Key
            public int ProductId { get; set; }

            // Product Name
            public string Name { get; set; } = string.Empty;

        // Product Description
        public string Description { get; set; } = string.Empty;

        // Product Price
        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }

        // Product Image
        public string ImageUrl { get; set; }= string.Empty;

        // Product Stock
        public int Stock { get; set; }

            // Product Category
            public string Category { get; set; } = string.Empty;
    }
    
}
