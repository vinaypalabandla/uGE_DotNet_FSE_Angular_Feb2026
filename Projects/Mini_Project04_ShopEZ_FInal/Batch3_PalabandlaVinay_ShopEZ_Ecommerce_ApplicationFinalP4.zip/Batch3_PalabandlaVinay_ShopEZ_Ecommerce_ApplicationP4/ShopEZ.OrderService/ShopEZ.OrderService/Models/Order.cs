﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace ShopEZ.OrderService.Models
{
    // Order Model
    public class Order
    {
        // Primary Key
        [Key]
        public int OrderId { get; set; }

        // User Id
        public int UserId { get; set; }

        // Order Date
        public DateTime OrderDate { get; set; }

        // Total Amount
        [Column(TypeName = "decimal(18,2)")]
        public decimal TotalAmount { get; set; }

        // Navigation Property
        public List<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
    }
}

