import { Injectable } from '@angular/core';
import { Product } from '../models/product';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class ProductService {
  getProducts() {
    throw new Error('Method not implemented.');
  }

  private apiUrl = 'https://localhost:7121/api/Products';

  constructor(private http: HttpClient) { }

  // GET ALL
  getAll() {
    return this.http.get<Product[]>(this.apiUrl);
  }

  // GET BY ID
  getById(id: number) {
    return this.http.get<Product>(`${this.apiUrl}/${id}`);
  }

  // ADD
  add(product: Product) {
    return this.http.post<Product>(this.apiUrl, product); // typed
  }

  // UPDATE
  update(product: Product) {
    return this.http.put<Product>(
      `${this.apiUrl}/${product.productId}`, product
    ); // typed
  }

  // DELETE
  delete(id: number) {
    return this.http.delete<void>(`${this.apiUrl}/${id}`); // typed
  }
}