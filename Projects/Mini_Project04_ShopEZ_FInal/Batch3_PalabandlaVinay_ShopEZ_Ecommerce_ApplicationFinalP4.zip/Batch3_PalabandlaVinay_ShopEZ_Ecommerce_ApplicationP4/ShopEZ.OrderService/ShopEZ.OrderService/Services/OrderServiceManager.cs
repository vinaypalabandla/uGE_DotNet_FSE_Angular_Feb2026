﻿using ShopEZ.OrderService.DTOs;
using ShopEZ.OrderService.Models;
using ShopEZ.OrderService.Repositories;
namespace ShopEZ.OrderService.Services
{
    // Order Service Class
    public class OrderServiceManager : IOrderService
    {
        // Repository Object Injecting
        private readonly IOrderRepository _repository;

        // Constructor INjecting 
        public OrderServiceManager(IOrderRepository repository)
        {
            _repository = repository;
        }
        // CREATE ORDER
        public async Task<Order> CreateOrder(OrderDTO dto)
        {
            return await _repository.CreateOrder(dto);
        }
        //GET ALL ORDERS
        public async Task<IEnumerable<Order>> GetAllOrders()
        {
            return await _repository.GetAllOrders();
        }

        //GET  ORDER BY ID
        public async Task<Order?> GetOrderById(int id)
        {
            return await _repository.GetOrderById(id);
        }
        //GET BY USER
        public async Task<IEnumerable<Order>> GetOrdersByUserId(int userId)
        {
            return await _repository.GetOrdersByUserId(userId);
        }
    }
}