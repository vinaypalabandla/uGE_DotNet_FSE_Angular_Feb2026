﻿using ShopEZ_Backend_Api_Development.Data;
using ShopEZ_Backend_Api_Development.DTOs;
using ShopEZ_Backend_Api_Development.Models;
using Microsoft.EntityFrameworkCore;

namespace ShopEZ_Backend_Api_Development.Services
{
    public class OrderService : IOrderService
    {
        private readonly ApplicationDbContext _context;

        // Constructor
        public OrderService(ApplicationDbContext context)
        {
            _context = context;
        }
        //Get All Orders
        public async Task<IEnumerable<Order>> GetAllAsync()
        {
            var orders = await _context.Orders
                .Include(o => o.OrderItems) // load items
                .ToListAsync();

            return orders;
        }
        //GetOrderByID
        public async Task<Order> GetByIdAsync(int id)
        {
            var order = await _context.Orders
                .Include(o => o.OrderItems) // load items
                .FirstOrDefaultAsync(o => o.OrderId == id);

            return order;
        }

       //Create Order
        public async Task CreateOrderAsync(OrderDTO dto)
        {
            // create order object
            var order = new Order
            {
                UserId = dto.UserId,
                OrderDate = DateTime.Now,
                OrderItems = new List<OrderItem>() // empty list
            };

            decimal total = 0;

            // loop through items
            foreach (var item in dto.Items)
            {
                // get product from DB
                var product = await _context.Products.FindAsync(item.ProductId);

                if (product == null)
                {
                    throw new Exception("Product not found");
                }

                if (item.Quantity <= 0)
                {
                    throw new Exception("Invalid quantity");
                }

                // create order item
                var orderItem = new OrderItem
                {
                    ProductId = item.ProductId,
                    Quantity = item.Quantity,
                    Price = product.Price
                };

                // calculate total
                total += item.Quantity * product.Price;

                // add item to order
                order.OrderItems.Add(orderItem);
            }

            // set total amount
            order.TotalAmount = total;

            // save order
            await _context.Orders.AddAsync(order);
            await _context.SaveChangesAsync();
        }
    }
}