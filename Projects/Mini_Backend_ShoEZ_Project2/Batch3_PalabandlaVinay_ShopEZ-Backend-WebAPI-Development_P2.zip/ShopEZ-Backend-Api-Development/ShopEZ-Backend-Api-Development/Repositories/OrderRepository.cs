﻿using Microsoft.EntityFrameworkCore;
using ShopEZ_Backend_Api_Development.Data;
using ShopEZ_Backend_Api_Development.Models;

namespace ShopEZ_Backend_Api_Development.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly ApplicationDbContext _context;
        //Consturctor
        public OrderRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        // Get All Orders
        public async Task<IEnumerable<Order>> GetAllAsync()
        {
            var orders = await _context.Orders
                .Include(o => o.OrderItems)   
                .ToListAsync();

            return orders;
        }

        // Get Order By Id
        public async Task<Order> GetByIdAsync(int id)
        {
            var order = await _context.Orders
                .Include(o => o.OrderItems)
                .FirstOrDefaultAsync(o => o.OrderId == id);

            return order;
        }

        // Add order
        public async Task AddAsync(Order order)
        {
            if (order == null)
                return;

            await _context.Orders.AddAsync(order);
            await _context.SaveChangesAsync();
        }
    }
}