import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../../services/product-service';
import { CartService } from '../../../core/services/cart.service';
import { Router, RouterModule } from '@angular/router';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Observable, map } from 'rxjs';
import { Product } from '../../../models/product';
import { Inject, PLATFORM_ID } from '@angular/core';

@Component({
  selector: 'app-product-list-component',
  standalone: true,
  imports: [RouterModule, CommonModule, FormsModule],
  templateUrl: './product-list-component.html',
  styleUrls: ['./product-list-component.css']
})
export class ProductListComponent implements OnInit {

  products$!: Observable<Product[]>;
  searchText: string = '';

  // category filter
  selectedCategory: string = 'all';

  // add alll categories in array type
  categories: string[] = [
    'all',
    'ac',
    'laptops',
    'tabs',
    'mobiles',
    'coolers',
    'fans',
    'watches',
    'gas',
    'induction',
    'washing machine',
    'appliances',
    'chair',
    'drives',
    'headphones'
  ];

  private isBrowser: boolean;

  constructor(
    private productService: ProductService,
    private cartService: CartService,
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    this.isBrowser = isPlatformBrowser(this.platformId);
  }

  ngOnInit() {
    this.loadProducts();
  }

  // LOAD + SEARCH + CATEGORY FILTER
  loadProducts() {
    this.products$ = this.productService.getAll().pipe(
      map((products: Product[]) => {

        // category filter
        if (this.selectedCategory !== 'all') {
          products = products.filter(p =>
            p.category?.toLowerCase() === this.selectedCategory.toLowerCase()
          );
        }

        // search filter
        if (!this.searchText || this.searchText.trim() === '') {
          return products;
        }

        return products.filter(p =>
          p.name?.toLowerCase().includes(this.searchText.toLowerCase())
        );
      })
    );
  }

  // SEARCH
  applyFilter() {
    this.loadProducts();
  }

  // CATEGORY CLICK
  filterCategory(category: string) {
    this.selectedCategory = category;
    this.loadProducts();
  }

  // ADD TO CART
  addToCart(product: Product) {
    console.log('CLICKED', product);

    const isLoggedIn = localStorage.getItem('user');

    if (!isLoggedIn) {
      this.router.navigate(['/login']);
      return;
    }

    this.cartService.addToCart(product);
  }

  // TRACK BY
  trackById(index: number, item: Product) {
    return item.productId;
  }
}