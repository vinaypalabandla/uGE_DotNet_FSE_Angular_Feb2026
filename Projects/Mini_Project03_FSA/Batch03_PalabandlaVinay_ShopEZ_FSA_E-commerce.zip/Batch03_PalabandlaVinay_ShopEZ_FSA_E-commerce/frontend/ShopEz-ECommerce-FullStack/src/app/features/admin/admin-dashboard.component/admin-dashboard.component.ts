import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../../services/product-service';
import { Product } from '../../../models/product';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-dashboard.component.html'
})
export class AdminDashboardComponent implements OnInit {

  products: Product[] = [];

  newProduct: Product = {
    productId: 0,
    name: '',
    description: '',
    price: 0,
    imageUrl: '',
    stock: 0,
    category: ''
  };

  message: string = '';

  selectedProduct: Product | null = null;

  products$!: Observable<Product[]>;

  constructor(
    private productService: ProductService,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.loadProducts();
  }

  //  UI UPDATE AFTER API
  loadProducts() {
    this.productService.getAll().subscribe({
      next: (res) => {
        this.products = [...res];
        this.cdr.detectChanges(); //chnaged relod
      },
      error: () => console.error('Failed to load products')
    });
  }

  showMessage(msg: string) {
    this.message = msg;
    setTimeout(() => {
      this.message = '';
      this.cdr.detectChanges(); // refresh UI
    }, 1500);
  }

  // AFTER ADD reload from DB
  addProduct() {
    this.productService.add(this.newProduct).subscribe({
      next: () => {

        this.loadProducts(); //instead of manual push

        this.showMessage('Product Added');
        this.resetForm();
      },
      error: () => this.showMessage('Add Failed')
    });
  }

  editProduct(product: Product) {
    this.selectedProduct = { ...product };
  }

  // AFTER UPDATE reload
  updateProduct() {
    if (!this.selectedProduct) return;

    this.productService.update(this.selectedProduct).subscribe({
      next: () => {

        this.loadProducts(); // reload latest data

        this.selectedProduct = null;
        this.showMessage('Product Updated');
      },
      error: () => this.showMessage('Update Failed')
    });
  }

  //  AFTER DELETE reload
  deleteProduct(id: number) {
    this.productService.delete(id).subscribe({
      next: () => {

        this.loadProducts(); // reload

        this.showMessage('Product Deleted');
      },
      error: () => this.showMessage('Delete Failed')
    });
  }

  resetForm() {
    this.newProduct = {
      name: '',
      description: '',
      price: 0,
      imageUrl: '',
      stock: 0,
      category: ''
    };
  }

  trackById(index: number, item: Product) {
    return item.productId;
  }

  cancelEdit() {
    this.selectedProduct = null;
  }
}