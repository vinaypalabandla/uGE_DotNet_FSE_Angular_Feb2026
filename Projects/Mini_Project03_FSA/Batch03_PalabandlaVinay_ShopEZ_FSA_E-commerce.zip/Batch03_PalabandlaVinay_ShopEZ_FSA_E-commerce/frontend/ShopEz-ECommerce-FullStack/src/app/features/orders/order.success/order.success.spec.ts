import { ComponentFixture, TestBed } from '@angular/core/testing';
import { OrderSuccess } from './order.success';
import { provideRouter, Router } from '@angular/router';

describe('OrderSuccess', () => {
  let component: OrderSuccess;
  let fixture: ComponentFixture<OrderSuccess>;
  let router: Router;

  beforeEach(async () => {

    // Mock history.state BEFORE component creation
    window.history.pushState({ order: { id: 1 } }, '');

    await TestBed.configureTestingModule({
      imports: [OrderSuccess], // standalone component
      providers: [
        provideRouter([]) // real router  means not mock
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(OrderSuccess);
    component = fixture.componentInstance;
    router = TestBed.inject(Router);

    fixture.detectChanges();
  });

  // BASIC TEST
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // CHECK ORDER DATA
  it('should load order from history state', () => {
    expect(component.order).toBeTruthy();
    expect(component.order.id).toBe(1);
  });

  // NAVIGATION TEST
  it('should navigate to products', () => {
    spyOn(router, 'navigate');

    component.goToProducts();

    expect(router.navigate).toHaveBeenCalledWith(['/products']);
  });

});