﻿using ShopEZ.OrderService.DTOs;
using ShopEZ.OrderService.Models;

namespace ShopEZ.OrderService.Services
{
    // Order Service Interface
    public interface IOrderService
    {
        // Create Order
        Task<Order> CreateOrder(OrderDTO dto);

        // Get All Orders
        Task<IEnumerable<Order>> GetAllOrders();

        // Get Order By Id
        Task<Order?> GetOrderById(int id);
        // Get Orders By User
        Task<IEnumerable<Order>> GetOrdersByUserId(int userId);
    }
}
