﻿using Microsoft.EntityFrameworkCore;

using ShopEZ.CartService.Data;
using ShopEZ.CartService.DTOs;
using ShopEZ.CartService.Models;

namespace ShopEZ.CartService.Repositories
{
    // Cart Repository Class
    public class CartRepository : ICartRepository
    {
        // DbContext Object
        private readonly ApplicationDbContext _context;

        // Constructor
        public CartRepository( ApplicationDbContext context)
        {
            _context = context;
        }

        // ADD TO CART
        public async Task<Cart>AddToCart(AddCartDTO dto)
        {
            // Check Cart Exists
            var cart = await _context.Carts.Include(c => c.CartItems)
                     .FirstOrDefaultAsync(c => c.UserId == dto.UserId);

            // If Cart Not Exists
            if (cart == null)
            {
                cart = new Cart
                {
                    UserId = dto.UserId
                };

                _context.Carts.Add(cart);

                await _context.SaveChangesAsync();
            }

            // Check Product Already Exists
            var existingItem =cart.CartItems.FirstOrDefault(
                    item =>item.ProductId== dto.ProductId);

            // If Product Exists
            if (existingItem != null)
            {
                existingItem.Quantity +=dto.Quantity;
            }
            else
            {
                // Create New Cart Item
                var cartItem = new CartItem
                {
                    ProductId = dto.ProductId,

                    Quantity = dto.Quantity,

                    Price = dto.Price,

                    CartId = cart.CartId
                };

                // Add Cart Item
                _context.CartItems.Add(cartItem);
            }

            // Save Changes
            await _context.SaveChangesAsync();

            return cart;
        }

        // GET USER CART
            public async Task<Cart?>GetCartByUserId(int userId)
        {
            return await _context.Carts

                .Include(c => c.CartItems)
                .FirstOrDefaultAsync( c => c.UserId == userId);
        }

        // UPDATE CART ITEM

        public async Task<CartItem?>UpdateCartItem(
                UpdateCartDTO dto)
        {
            // Find Cart Item
            var cartItem = await _context.CartItems
               .FirstOrDefaultAsync( c => c.CartItemId  == dto.CartItemId);

            // Check Null
            if (cartItem == null)
            {
                return cartItem;//cart items return
            }

            // Update Quantity
            cartItem.Quantity = dto.Quantity;

            // Save Changes
            await _context.SaveChangesAsync();

            return cartItem;
        }

        // REMOVE CART ITEM
        public async Task<bool>RemoveCartItem(int cartItemId)
        {
            // Find Cart Item
            var cartItem = await _context.CartItems.FindAsync(cartItemId);

            // Check Null
            if (cartItem == null)
            {
                return false;
            }

            // Remove Item
            _context.CartItems.Remove(cartItem);

            // Save Changes
            await _context.SaveChangesAsync();

            return true;
        }
        // CLEAR CART
  
        public async Task<bool> ClearCart(int userId)
        {
            // Find Cart
            var cart = await _context.Carts.Include(c => c.CartItems)
                      .FirstOrDefaultAsync(c => c.UserId == userId);

            // Check Null
            if (cart == null)
            {
                return false;
            }

            // Remove All Items
            _context.CartItems.RemoveRange(cart.CartItems);
            // Save Changes
            await _context.SaveChangesAsync();

            return true;
        }
    }
}