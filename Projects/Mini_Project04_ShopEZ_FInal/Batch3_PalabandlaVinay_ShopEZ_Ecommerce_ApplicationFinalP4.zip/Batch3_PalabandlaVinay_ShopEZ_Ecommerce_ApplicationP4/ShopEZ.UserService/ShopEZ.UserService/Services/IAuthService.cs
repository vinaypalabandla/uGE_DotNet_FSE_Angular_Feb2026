﻿using ShopEZ.UserService.DTOs;

namespace ShopEZ.UserService.Services
{
    public interface IAuthService
    {
        Task<string> Register(RegisterDTO dto);

        Task<object> Login(LoginDTO dto);

    }
}
