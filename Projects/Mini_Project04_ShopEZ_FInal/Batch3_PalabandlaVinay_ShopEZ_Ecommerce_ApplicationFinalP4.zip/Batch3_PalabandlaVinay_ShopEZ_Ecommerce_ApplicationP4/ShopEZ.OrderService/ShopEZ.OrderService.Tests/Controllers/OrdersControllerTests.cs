﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using ShopEZ.OrderService.Controllers;
using ShopEZ.OrderService.DTOs;
using ShopEZ.OrderService.Models;
using ShopEZ.OrderService.Services;
using Xunit;

namespace ShopEZ.OrderService.Tests.Controllers
{
    public class OrdersControllerTests
    {
        // Mock service
        private readonly Mock<IOrderService> _mockService;

        // Controller
        private readonly OrdersController _controller;

        // Constructor
        public OrdersControllerTests()
        {
            _mockService = new Mock<IOrderService>();
            _controller = new OrdersController(_mockService.Object);
        }

        // CREATE ORDER
        [Fact]
        public async Task CreateOrder_ReturnsOk()
        {
            // Arrange
            var dto = new OrderDTO();

            _mockService.Setup(x => x.CreateOrder(dto)).ReturnsAsync(new Order());
            // Act
            var result = await _controller.CreateOrder(dto);
            // Assert
            Assert.IsType<OkObjectResult>(result);
        }

        // GET ALL ORDERS
        [Fact]
        public async Task GetAllOrders_ReturnsOk()
        {
            // Arrange
            _mockService.Setup(x => x.GetAllOrders()).ReturnsAsync(new List<Order>());

            // Act
            var result = await _controller.GetAllOrders();
            // Assert
            Assert.IsType<OkObjectResult>(result);
        }

        // GET ORDER BY ID
        [Fact]
        public async Task GetOrderById_ReturnsOk()
        {
            // Arrange
            _mockService.Setup(x => x.GetOrderById(1)) .ReturnsAsync(new Order());

            // Act
            var result = await _controller.GetOrderById(1);
            // Assert
            Assert.IsType<OkObjectResult>(result);
        }

        // GET ORDERS BY USER
        [Fact]
        public async Task GetOrdersByUserId_ReturnsOk()
        {
            // Arrange
            _mockService.Setup(x => x.GetOrdersByUserId(1)).ReturnsAsync(new List<Order>());
            // Act
            var result = await _controller.GetOrdersByUserId(1);
            // Assert
            Assert.IsType<OkObjectResult>(result);
        }
    }
}