﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ShopEZ.CartService.Models
{
        // Cart Item Model
    public class CartItem
    {
       
            // Primary Key
            [Key]
            public int CartItemId { get; set; }

            // Product Id
            public int ProductId { get; set; }

            // Quantity
            public int Quantity { get; set; }

        // Price
        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }

            // Foreign Key
            public int CartId { get; set; }

            // Navigation Property
            [ForeignKey("CartId")]

            // Ignore Circular Reference
            [JsonIgnore]

            public Cart Cart { get; set; } = null!;
        
    }
}
