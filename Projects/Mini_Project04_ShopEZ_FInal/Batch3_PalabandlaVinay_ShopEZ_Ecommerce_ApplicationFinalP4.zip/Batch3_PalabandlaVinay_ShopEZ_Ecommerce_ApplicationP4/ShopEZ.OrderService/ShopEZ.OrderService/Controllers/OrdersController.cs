﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShopEZ.OrderService.DTOs;
using ShopEZ.OrderService.Services;

namespace ShopEZ.OrderService.Controllers
{
    // Route
    [Route("api/[controller]")]
    // API Controller
    [ApiController]
   [Authorize] //only loged in user placed orders
    public class OrdersController : ControllerBase
    {
        // Service Object
        private readonly IOrderService _service;
        // Constructor
        public OrdersController(IOrderService service)
        {
            _service = service;
        }
        // CREATE ORDER
        [HttpPost]
        public async Task<IActionResult> CreateOrder(OrderDTO dto)
        {
            var order = await _service.CreateOrder(dto);
            return Ok(order);
        }
        // GET ALL ORDERS

        [HttpGet]
        public async Task<IActionResult> GetAllOrders()
        {
            var orders = await _service.GetAllOrders();
            return Ok(orders);
        }

        // GET ORDER BY ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetOrderById(int id)
        {
            var order = await _service.GetOrderById(id);

            return Ok(order);
        }
        // GET ORDERS BY USER
        [HttpGet("user/{userId}")]
        public async Task<IActionResult> GetOrdersByUserId(int userId)
        {
            var orders = await _service.GetOrdersByUserId(userId);

            return Ok(orders);
        }
    }
}

