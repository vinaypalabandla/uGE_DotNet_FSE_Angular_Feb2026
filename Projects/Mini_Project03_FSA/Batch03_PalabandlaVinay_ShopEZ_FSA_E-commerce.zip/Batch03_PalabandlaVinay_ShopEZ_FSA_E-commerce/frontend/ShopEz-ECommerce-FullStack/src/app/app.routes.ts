import { Routes } from '@angular/router';
import { ProductListComponent } from './features/products/product-list-component/product-list-component';
import { CartComponent } from './features/cart/cart.component/cart.component';
import { OrderSuccess } from './features/orders/order.success/order.success';

import { Login } from './features/auth/login/login';
import { Register } from './features/auth/register/register';

import { HomeComponent } from './features/home/home.component/home.component';
import { AdminDashboardComponent } from './features/admin/admin-dashboard.component/admin-dashboard.component';
import { AdminGuard } from './core/guards/auth-guard';


export const routes: Routes = [

  { path: '', component: HomeComponent },

  { path: 'products', component: ProductListComponent },

  { path: 'cart', component: CartComponent },

  { path: 'login', component: Login },
  { path: 'register', component: Register },
  {
    path: 'admin',
    component: AdminDashboardComponent,
    canActivate: [AdminGuard]
  },
  {
    path: 'checkout',
    loadComponent: () =>
      import('./features/orders/checkout-component/checkout-component')
        .then(m => m.CheckoutComponent)
  },

  {
    path: 'order-success',
    loadComponent: () =>
      import('./features/orders/order.success/order.success')
        .then(m => m.OrderSuccess)
  },

  {
    path: 'products',
    loadComponent: () =>
      import('./features/products/product-list-component/product-list-component')
        .then(m => m.ProductListComponent)
  },

  { path: '**', redirectTo: '' }

];