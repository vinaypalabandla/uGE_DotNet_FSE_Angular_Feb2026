﻿using Microsoft.EntityFrameworkCore;
using ShopEZ_Backend_Api_Development.Data;
using ShopEZ_Backend_Api_Development.DTOs;
using ShopEZ_Backend_Api_Development.Helpers;

namespace ShopEZ_Backend_Api_Development.Services
{
    public class AuthService
    {
        private readonly ApplicationDbContext _context;
        private readonly JwtHelper _jwt;

        public AuthService(ApplicationDbContext context, JwtHelper jwt)
        {
            _context = context;
            _jwt = jwt;
        }

        public async Task<string> Login(LoginDTO dto)
        {
            var user = await _context.Users
            .FirstOrDefaultAsync(u => u.Email == dto.Email && u.Password == dto.Password);

            if (user == null)
                throw new Exception("Invalid credentials");

            return _jwt.GenerateToken(user);
        }
        //registration
        // ADD THIS BELOW Login() METHOD
        public async Task<string> Register(RegisterDTO dto)
        {
            // check if email already exists
            var existingUser = await _context.Users
                .FirstOrDefaultAsync(u => u.Email == dto.Email);

            if (existingUser != null)
                throw new Exception("Email already exists");

            // create new user
            var user = new Models.User
            {
                Name = dto.Name,
                Email = dto.Email,
                Password = dto.Password,
                Role = "Customer"
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return "User registered successfully";
        }

    }
}
