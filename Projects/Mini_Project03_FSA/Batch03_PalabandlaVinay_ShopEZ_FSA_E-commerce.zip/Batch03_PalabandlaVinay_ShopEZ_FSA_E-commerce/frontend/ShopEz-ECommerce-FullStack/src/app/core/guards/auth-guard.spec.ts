import { TestBed } from '@angular/core/testing';
import { AdminGuard } from './auth-guard';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth-service';

describe('AdminGuard', () => {
  let guard: AdminGuard;
  let authServiceSpy: any;
  let routerSpy: any;

  beforeEach(() => {
    authServiceSpy = jasmine.createSpyObj('AuthService', ['getUser']);
    routerSpy = jasmine.createSpyObj('Router', ['navigate']);

    TestBed.configureTestingModule({
      providers: [
        AdminGuard,
        { provide: AuthService, useValue: authServiceSpy },
        { provide: Router, useValue: routerSpy }
      ]
    });

    guard = TestBed.inject(AdminGuard);
  });

  it('should allow access for Admin user', () => {
    authServiceSpy.getUser.and.returnValue({ role: 'Admin' });

    expect(guard.canActivate()).toBeTrue();
  });

  it('should deny access for non-admin user', () => {
    authServiceSpy.getUser.and.returnValue({ role: 'User' });

    expect(guard.canActivate()).toBeFalse();
    expect(routerSpy.navigate).toHaveBeenCalledWith(['/']);
  });
});