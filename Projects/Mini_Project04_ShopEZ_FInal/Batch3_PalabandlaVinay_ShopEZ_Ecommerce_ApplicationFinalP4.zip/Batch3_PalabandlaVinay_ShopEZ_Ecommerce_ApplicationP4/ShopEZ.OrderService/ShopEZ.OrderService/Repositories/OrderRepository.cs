﻿
using Microsoft.EntityFrameworkCore;
using System.Text;
using System.Text.Json;
using ShopEZ.OrderService.Data;
using ShopEZ.OrderService.DTOs;
using ShopEZ.OrderService.Models;

namespace ShopEZ.OrderService.Repositories
{
    // Order Repository Class
    public class OrderRepository : IOrderRepository
    {
        // DbContext Object
       
        private readonly ApplicationDbContext _context;
        private readonly IHttpClientFactory _httpClientFactory; // communcate http clinet product service

        // Constructor
        public OrderRepository(ApplicationDbContext context,IHttpClientFactory httpClientFactory)
        {
            _context = context;
            _httpClientFactory = httpClientFactory;
        }

        // CREATE ORDER
        public async Task<Order> CreateOrder(OrderDTO dto)
        {
            // Create Order Object
            var order = new Order
            {
                UserId = dto.UserId,
                OrderDate = DateTime.Now,
                TotalAmount = dto.TotalAmount,
                OrderItems = dto.OrderItems .Select(item => new OrderItem
                    {
                        ProductId = item.ProductId,
                        Quantity = item.Quantity,
                        Price = item.Price

                    }).ToList() // Convert into List
            };

            // Add Order
            _context.Orders.Add(order);
            // Save Changes
            await _context.SaveChangesAsync();
            //Redece Stock From Prodcutservice
            // Create HttpClient
            var client = _httpClientFactory.CreateClient();

            // Loop all ordered items
            foreach (var item in dto.OrderItems)
            {
                // Product Service API URL  // 7136 port nummber we used for productservice to orderservice communication  
                //IN DOCKER COMPOSE TIME WE CHANGE 8080 port insted of 7136       $ "http: //shopez-productservice:8080
                //  $"https: //localhost:7136
                var url =
                    $"http://shopez-productservice:8080/api/products/reduce-stock" +
                    $"?productId={item.ProductId}" +
                    $"&quantity={item.Quantity}";
                // Call Product Service API
                await client.PutAsync(url, null);
            }
            // Return Order
            return order;
        }

        //GET ALL ORDERS
        public async Task<IEnumerable<Order>> GetAllOrders()
        {
            return await _context.Orders
               .Include(o => o.OrderItems)
                .ToListAsync();
        }

        // GET ORDER BY ID
        public async Task<Order?> GetOrderById(int id)
        {
            return await _context.Orders
                  .Include(o => o.OrderItems)
                  .FirstOrDefaultAsync(
                    o => o.OrderId == id);
        }
        // GET ORDERS BY USER ID
        public async Task<IEnumerable<Order>> GetOrdersByUserId(int userId)
        {
            return await _context.Orders
                .Include(o => o.OrderItems)
                .Where(o => o.UserId == userId)
                .ToListAsync();
        }
    }
}

