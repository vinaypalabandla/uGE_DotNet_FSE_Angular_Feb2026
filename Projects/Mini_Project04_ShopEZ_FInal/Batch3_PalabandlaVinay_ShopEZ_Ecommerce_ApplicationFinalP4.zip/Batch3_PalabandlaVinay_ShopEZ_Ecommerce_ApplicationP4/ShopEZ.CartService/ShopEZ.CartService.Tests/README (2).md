# ShopEZ – E-Commerce Microservices Backend

> **Prepared by:** Palabandla Vinay | / Angular and .NET Full Stack Developer  
> **Final-Project** | Microservices Architecture, Testing & Docker Deployment

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Technology Stack](#2-technology-stack)
3. [System Architecture](#3-system-architecture)
4. [Microservices Breakdown](#4-microservices-breakdown)
   - [4.1 User Service](#41-user-service)
   - [4.2 Product Service](#42-product-service)
   - [4.3 Order Service](#43-order-service)
   - [4.4 Cart Service](#44-cart-service)
5. [API Gateway (Ocelot)](#5-api-gateway-ocelot)
6. [Database Design](#6-database-design)
7. [Docker Architecture](#7-docker-architecture)
8. [Project Folder Structure](#8-project-folder-structure)
9. [Authentication & Security](#9-authentication--security)
10. [Unit Testing](#10-unit-testing)
11. [Swagger API Documentation](#11-swagger-api-documentation)
12. [Postman Testing](#12-postman-testing)
13. [Key Challenges & Solutions](#13-key-challenges--solutions)
14. [Future Enhancements](#14-future-enhancements)
15. [Conclusion](#15-conclusion)

---

## 1. Project Overview

**ShopEZ** is a full-featured, cloud-ready e-commerce platform built on a **microservices architecture** using ASP.NET Core Web API (.NET 8). Each domain is encapsulated in its own independently deployable service, communicating through a centralized **Ocelot API Gateway**.

### Objective
- Scalability through independent microservices
- Security via JWT authentication + role-based authorization
- Reliability through xUnit unit testing (34 tests, 100% pass rate)
- Portability through Docker containerization
- Performance via Dapper ORM in Product Service

### Key Features

| Feature | Detail |
|---|---|
| Authentication | JWT Bearer Tokens |
| Authorization | Role-Based (Admin / Customer) |
| API Gateway | Ocelot (centralized routing) |
| Services | User, Product, Order, Cart |
| ORM | EF Core + Dapper (Product Service) |
| Testing | xUnit + Moq — 34 tests, 0 failures |
| Containers | Docker + Docker Compose |
| API Docs | Swagger / OpenAPI 3.0 per service |
| Frontend | Angular SPA + Nginx |

---

## 2. Technology Stack

| Layer | Technology |
|---|---|
| Backend Framework | ASP.NET Core Web API (.NET 8) |
| Architecture | Microservices |
| API Gateway | Ocelot / YARP |
| Database | Microsoft SQL Server 2022 |
| ORM – User / Order / Cart | Entity Framework Core 8 |
| ORM – Product Service | Dapper (High-Performance) |
| Authentication | JWT (JSON Web Tokens) |
| Authorization | Role-Based (Admin / Customer) |
| Containerization | Docker + Docker Compose |
| Unit Testing | xUnit + Moq |
| API Documentation | Swagger / OpenAPI 3.0 |
| Frontend | Angular SPA |
| Web Server | Nginx (in Docker) |
| IDE | Visual Studio 2022 |

---

## 3. System Architecture

```
Angular SPA (Frontend)
        │
        ▼  REST API Calls (HTTP + JWT)
┌─────────────────────────┐
│  API Gateway (Ocelot)   │  Port 5000
│  Routing | Auth | Proxy │
└─────────────────────────┘
        │
  ┌─────┼─────────┬──────────┐
  ▼     ▼         ▼          ▼
User  Product   Order      Cart
5001   5002      5003       5004
  │     │         │          │
  └─────┴─────────┴──────────┘
                 │
        SQL Server (Per-Service DBs)
               Port 1433
```

**Architecture Layers:**

| Layer | Component | Responsibility |
|---|---|---|
| Presentation | Angular SPA | UI, HTTP calls, JWT interceptor |
| Gateway | Ocelot (Port 5000) | Routing, reverse proxy, load balancing |
| Services | User, Product, Order, Cart | Business logic & domain APIs |
| Data | SQL Server (per service) | Data persistence, schema isolation |

---

## 4. Microservices Breakdown

### 4.1 User Service

Handles all authentication and authorization. Manages registration, login, JWT generation, and role assignment.

**Port:** `7110` (dev) / `5001` (Docker)

**Endpoints:**

| Method | Endpoint | Description | Auth |
|---|---|---|---|
| POST | `/api/Auth/register` | Register new user | No |
| POST | `/api/Auth/login` | Login + receive JWT token | No |



> The login response returns `userId`, `email`, `role`, and a signed **JWT Bearer token**. Include it as `Authorization: Bearer <token>` in all protected requests.

---

### 4.2 Product Service

Manages the full product catalog. Uses **Dapper ORM** for high-performance queries.

**Port:** `7136` (dev) / `5002` (Docker)

**Why Dapper?**  
Dapper executes raw SQL directly with minimal overhead — ideal for the read-heavy catalog operations (listing, search, pagination).

**Endpoints:**

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/Products` | Get all products |
| POST | `/api/Products` | Add product *(Admin)* |
| GET | `/api/Products/{id}` | Get product by ID |
| PUT | `/api/Products/{id}` | Update product *(Admin)* |
| DELETE | `/api/Products/{id}` | Delete product *(Admin)* |
| GET | `/api/Products/search` | Search by keyword |
| GET | `/api/Products/category` | Filter by category |
| GET | `/api/Products/pagination` | Paginated listing |
| PUT | `/api/Products/reduce-stock` | Reduce stock *(called by Order Service)* |


### 4.3 Order Service

Handles the complete order lifecycle. Calls **Product Service** over HTTP to reduce stock on checkout.

**Port:** `7056` (dev) / `5003` (Docker)

**Endpoints:**

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/Orders` | Place a new order |
| GET | `/api/Orders` | Get all orders *(Admin)* |
| GET | `/api/Orders/{id}` | Get order by ID |
| GET | `/api/Orders/user/{userId}` | Get orders by user |

**Inter-Service Flow:**
```
Order Service  ──►  PUT /api/Products/reduce-stock  ──►  Product Service
```


### 4.4 Cart Service

Manages shopping cart operations per user.

**Port:** `7267` (dev) / `5004` (Docker)

**Endpoints:**

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/Cart` | Add item to cart |
| PUT | `/api/Cart` | Update item quantity |
| GET | `/api/Cart/{userId}` | Get cart for user |
| DELETE | `/api/Cart/{cartItemId}` | Remove cart item |
| DELETE | `/api/Cart/clear/{userId}` | Clear entire cart |


## 5. API Gateway (Ocelot)

Single entry point for all frontend requests. Routes to downstream services and forwards JWT tokens.

**Port:** `5000`

**Routing:**

| Client Calls | Routes To |
|---|---|
| `localhost:5000/gateway/products/{everything}` | `product-service:80/api/Products/{everything}` |
| `localhost:5000/gateway/orders/{everything}` | `order-service:80/api/Orders/{everything}` |
| `localhost:5000/gateway/cart/{everything}` | `cart-service:80/api/Cart/{everything}` |
| `localhost:5000/gateway/auth/{everything}` | `user-service:80/api/Auth/{everything}` |

**Sample `ocelot.json`:**
```json
{
  "Routes": [
    {
      "DownstreamPathTemplate": "/api/Products/{everything}",
      "DownstreamScheme": "http",
      "DownstreamHostAndPorts": [{ "Host": "product-service", "Port": 80 }],
      "UpstreamPathTemplate": "/gateway/products/{everything}",
      "UpstreamHttpMethod": [ "GET", "POST", "PUT", "DELETE" ]
    }
  ],
  "GlobalConfiguration": {
    "BaseUrl": "http://localhost:5000"
  }
}
```

---

## 6. Database Design

Each service owns its own database (Database-per-Service pattern).

| Table | Service | Key Columns |
|---|---|---|
| Users | User Service | UserId, Name, Email, PasswordHash, Role |
| Products | Product Service | ProductId, Name, Description, Price, Stock, Category |
| Orders | Order Service | OrderId, UserId, TotalAmount, Status, CreatedAt |
| OrderItems | Order Service | OrderItemId, OrderId, ProductId, Quantity, UnitPrice |
| CartItems | Cart Service | CartItemId, UserId, ProductId, ProductName, Quantity, Price |

**Relationships:**
```
Users     (1) ──── (N)  Orders
Orders    (1) ──── (N)  OrderItems
Products  (1) ──── (N)  OrderItems
Users     (1) ──── (N)  CartItems
```

---

## 7. Docker Architecture

All services run as Docker containers orchestrated by Docker Compose.

```bash
docker-compose up --build
```

**Services:**

| Container | Technology | Port | Depends On |
|---|---|---|---|
| angular-frontend | Angular + Nginx | 80 | api-gateway |
| api-gateway | Ocelot / YARP | 5000 | All services |
| user-service | ASP.NET Core + EF Core | 5001 | sqlserver |
| product-service | ASP.NET Core + Dapper | 5002 | sqlserver |
| order-service | ASP.NET Core + EF Core | 5003 | sqlserver, product-service |
| cart-service | ASP.NET Core + EF Core | 5004 | sqlserver |
| sqlserver | SQL Server 2022 | 1433 | — |
| redis-cache | Redis | 6379 | — |

**Dockerfile pattern (multi-stage):**
```dockerfile
# Stage 1: Build
FROM mcr.microsoft.com/dotnet/sdk:8.0 AS build
WORKDIR /src
COPY . .
RUN dotnet restore
RUN dotnet publish -c Release -o /app/publish

# Stage 2: Runtime
FROM mcr.microsoft.com/dotnet/aspnet:8.0 AS final
WORKDIR /app
COPY --from=build /app/publish .
ENTRYPOINT ["dotnet", "ShopEZ.ProductService.dll"]
```


> **Key Fix:** Inside Docker Compose, services must use the service name (`http://product-service`) instead of `localhost` for inter-container communication.

---

## 8. Project Folder Structure


```
microservices-app/
├── docker-compose.yml
├── gateway/
│   ├── Dockerfile
│   └── ocelot.json
├── product-service/
│   └── Dockerfile
├── order-service/
│   └── Dockerfile
├── auth-service/
│   └── Dockerfile
└── angular-app/
    └── Dockerfile
```

**Per-Service Structure:**
```
ShopEZ.<ServiceName>/
├── Controllers/
├── Services/         ← Business logic
├── Repositories/     ← Data access
├── Models/
├── DTOs/
├── Data/             ← DB context / Dapper setup
├── Migrations/
├── Middlewares/
├── appsettings.json
├── Program.cs
└── Dockerfile

ShopEZ.<ServiceName>.Tests/
├── Controllers/      ← Controller unit tests
└── Services/         ← Service unit tests
```

---

## 9. Authentication & Security

**JWT Flow:**
```
1. POST /api/Auth/login  →  Validate credentials
2. Generate JWT (HS256)  →  Contains: userId, email, role, expiry
3. Return token to client
4. Client sends:  Authorization: Bearer <token>
5. Protected endpoints:  [Authorize]
   Admin-only endpoints:  [Authorize(Roles = "Admin")]
```

**Roles:**

| Role | Permissions |
|---|---|
| Customer | Browse products, place orders, manage own cart, view own orders |
| Admin | All customer permissions + add/edit/delete products, view all orders |

---

## 10. Unit Testing

**Frameworks:** xUnit + Moq  
**Total: 34 tests | 34 passed | 0 failed**

---

### User Service — 5 Tests 


| Test | Result |
|---|---|
| Login_ReturnsOk | Passed |
| Register_ReturnsBadRequest | Passed |
| Register_ReturnsOk |  Passed |
| Login_Should_Return_Token_When_Valid |  Passed |
| Login_Should_Throw_Exception_When_Invalid |  Passed |

---

### Product Service — 10 Tests 


| Test | Result |
|---|---|
| AddProduct_ReturnsOk | Passed |
| DeleteProduct_ReturnsOk |  Passed |
| GetAllProducts_ReturnsOk |  Passed |
| ReduceStock_ReturnsBadRequest |  Passed |
| ReduceStock_ReturnsOk |  Passed |
| AddProduct_Should_Return_Success |  Passed |
| DeleteProduct_Should_Return_Success | Passed |
| GetAllProducts_Should_Return_List | Passed |
| GetProductById_Should_Return_Product |  Passed |
| SearchProducts_Should_Return_Results | Passed |

---

### Order Service — 9 Tests 

| Test | Result |
|---|---|
| CreateOrder_ReturnsOk |  Passed |
| GetAllOrders_ReturnsOk |  Passed |
| GetOrderById_ReturnsOk | Passed |
| GetOrdersByUserId_ReturnsOk |  Passed |
| CreateOrder_Should_Return_Order |  Passed |
| GetAllOrders_Should_Return_Orders | Passed |
| GetOrderById_Should_Return_NotNull | Passed |
| GetOrderById_Should_Return_Order |  Passed |
| GetOrdersByUserId_Should_Return_List |  Passed |

---

### Cart Service — 10 Tests 

| Test | Result |
|---|---|
| AddToCart_ReturnsOk |  Passed |
| ClearCart_ReturnsOk |  Passed |
| GetCartByUserId_ReturnsOk | Passed |
| RemoveCartItem_ReturnsOk |  Passed |
| UpdateCartItem_ReturnsOk |  Passed |
| AddToCart_Should_Return_Cart |  Passed |
| ClearCart_Should_Return_True |  Passed |
| GetCart_Should_Return_Cart |  Passed |
| RemoveCart_Should_Return_True |  Passed |
| UpdateCart_Should_Return_Item |  Passed |

---

### Test Summary

| Service | Tests | Passed | Failed | Duration |
|---|---|---|---|---|
| User Service | 5 | 5 | 0 | 410 ms |
| Product Service | 10 | 10 | 0 | 598 ms |
| Order Service | 9 | 9 | 0 | 3.6 sec |
| Cart Service | 10 | 10 | 0 | 3.7 sec |
| **TOTAL** | **34** | **34** | **0** | **~8.5 sec** |

---

## 11. Swagger API Documentation

Each service exposes its own Swagger UI at `/swagger/index.html`.

| Service | URL |
|---|---|
| User Service | http://localhost:7110/swagger/index.html |
| Product Service | http://localhost:7136/swagger/index.html |
| Order Service | http://localhost:7056/swagger/index.html |
| Cart Service | http://localhost:7267/swagger/index.html |


---

## 13. Key Challenges & Solutions

| Challenge | Root Cause | Solution |
|---|---|---|
| Docker inter-service communication failed | Order Service used `http://localhost:5002` which resolves to itself inside Docker | Replaced with Docker service name: `http://product-service` |
| SQL Server connection refused on startup | Container not fully ready before .NET services started | Added `depends_on` with `condition: service_healthy` + SQL Server healthcheck |
| JWT authorization errors | Mismatched issuer/audience config between token generation and validation | Aligned JWT settings in `appsettings.json` and fixed `AddJwtBearer()` in `Program.cs` |
| Port conflicts in local dev | Multiple services binding to overlapping ports | Assigned unique port ranges per service |
| Moq `ReturnsAsync` compile error (CS1929) | Version mismatch causing async setup failure | Used `Returns(Task.FromResult(...))` as fallback |
| Concurrent stock over-reduction | Two simultaneous orders could both read and reduce the same stock | Added stock availability pre-check returning `400` when insufficient |

---

## 14. Future Enhancements

| Enhancement | Priority |
|---|---|
| Payment Gateway (Razorpay / Stripe) | High |
| Redis Caching for product catalog | High |
| Azure / AKS Deployment | High |
| CI/CD Pipeline (GitHub Actions) | Medium |
| Wishlist Service | Medium |
| Notification Service (Email/SMS) | Medium |
| AI Product Recommendations | Low |
| API Rate Limiting at Gateway | Medium |
| Distributed Tracing (OpenTelemetry) | Low |

---

## 15. Conclusion

ShopEZ demonstrates a scalable microservices-based e-commerce platform using **ASP.NET Core**, **Angular**, **Docker**, **SQL Server**, **JWT authentication**, and **Ocelot API Gateway**. The system implements modular backend services, secure authentication, containerized deployment, and a complete order management workflow — with **34 unit tests at 100% pass rate** across all four services.

---

*Palabandla Vinay — Angular/ .NET Full Stack Developer*
