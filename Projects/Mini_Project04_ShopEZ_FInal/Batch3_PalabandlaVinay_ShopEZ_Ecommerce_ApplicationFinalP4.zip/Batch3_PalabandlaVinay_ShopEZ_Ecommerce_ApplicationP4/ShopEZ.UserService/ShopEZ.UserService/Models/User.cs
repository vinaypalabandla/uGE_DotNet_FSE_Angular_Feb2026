﻿// Data annotations namespace
using System.ComponentModel.DataAnnotations;

namespace ShopEZ.UserService.Models
{
  
        // User table model
        public class User
        {
            // Primary Key
            [Key]
            public int UserId { get; set; }

            // User Name
            [Required(ErrorMessage = "Name is required")]
            [StringLength(50)]
            public string? Name { get; set; }

            // User Email
            [Required(ErrorMessage = "Email is required")]
            [EmailAddress]
            public string? Email { get; set; }

            // User Password
            [Required(ErrorMessage = "Password is required")]
            [MinLength(6)]
            public string? Password { get; set; }

            // User Role
            [Required]
            public string? Role { get; set; }
        }
   
}
