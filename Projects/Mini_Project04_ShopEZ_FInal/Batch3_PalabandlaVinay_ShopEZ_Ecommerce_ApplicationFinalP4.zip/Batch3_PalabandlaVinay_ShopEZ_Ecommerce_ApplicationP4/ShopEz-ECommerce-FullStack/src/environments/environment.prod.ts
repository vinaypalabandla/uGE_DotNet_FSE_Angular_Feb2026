
export const environment = {
  production: true,

  gatewayUrl: 'http://localhost:5000/gateway',

  productApi: 'http://localhost:5000/gateway/products',

  cartApi: 'http://localhost:5000/gateway/cart',

  orderApi: 'http://localhost:5000/gateway/orders',

  authApi: 'http://localhost:5000/gateway/auth'
};