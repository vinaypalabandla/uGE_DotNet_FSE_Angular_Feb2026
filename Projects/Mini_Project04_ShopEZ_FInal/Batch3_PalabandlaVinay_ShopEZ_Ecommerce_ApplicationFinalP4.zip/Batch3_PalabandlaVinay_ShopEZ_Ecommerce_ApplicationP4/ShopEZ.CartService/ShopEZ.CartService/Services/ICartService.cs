﻿using ShopEZ.CartService.DTOs;
using ShopEZ.CartService.Models;

namespace ShopEZ.CartService.Services
{
    // Cart Service Interface
    public interface ICartService
    {
        // Add To Cart
        Task<Cart> AddToCart(AddCartDTO dto);

        // Get User Cart
        Task<Cart?> GetCartByUserId(int userId);

        // Update Cart Item
        Task<CartItem?> UpdateCartItem(UpdateCartDTO dto);

        // Remove Cart Item
        Task<bool> RemoveCartItem( int cartItemId);

        // Clear Cart
        Task<bool> ClearCart(int userId);
    }
}
