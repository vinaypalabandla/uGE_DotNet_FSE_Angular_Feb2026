import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthService {

  private apiUrl = 'https://localhost:7121/api/Auth';

  private userSubject = new BehaviorSubject<any>(this.getUser());
  user$ = this.userSubject.asObservable();

  constructor(private http: HttpClient) { }

  login(data: any) {
    return this.http.post(`${this.apiUrl}/login`, data);
  }

  register(data: any) {
    return this.http.post(`${this.apiUrl}/register`, data);
  }

  // UPDATED ONLY ADD TOKEN STORAGE
  saveUser(user: any) {
    //here, permanent storage (even after closing browser)
    localStorage.setItem('user', JSON.stringify(user));

    //sessionStorage = auto clears when browser/tab closes
    // sessionStorage.setItem('user', JSON.stringify(user));


    if (user?.token) {
      //localStorage.setItem('token', user.token); //session storage
      localStorage.setItem('token', user.token);
    }

    this.userSubject.next(user);
  }

  getUser() {
    if (typeof window === 'undefined') return null;

    const data = localStorage.getItem('user'); // slocalStorage removed and use session storage
    if (!data || data === 'undefined') return null;

    try {
      return JSON.parse(data);
    } catch {
      return null;
    }
  }

  // UPDATED (REMOVE TOKEN ALSO)
  logout() {
    //loccal storage related

    localStorage.removeItem('user');
    localStorage.removeItem('token');

    // sessionStorage.removeItem('user');
    // sessionStorage.removeItem('token');

    this.userSubject.next(null);
  }
}