﻿using System.ComponentModel.DataAnnotations;
namespace ShopEZ.UserService.DTOs
{
    public class RegisterDTO
    {
     
        
            // Name
            [Required]
            public string? Name { get; set; }

            // Email
            [Required]
            [EmailAddress]
            public string? Email { get; set; }

            // Password
            [Required]
            [MinLength(6)]
            public string? Password { get; set; }
        

    }
}
