import { TestBed } from '@angular/core/testing';
import { HttpRequest, HttpHandlerFn, HttpEvent } from '@angular/common/http';
import { of } from 'rxjs';
import { authInterceptor } from './jwt-interceptor';

describe('authInterceptor', () => {

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should add Authorization header if token exists', (done) => {

    // REAL TOKEN
    spyOn(localStorage, 'getItem').and.returnValue(
      JSON.stringify({ token: 'fake-token' })
    );

    const req = new HttpRequest('GET', '/test');

    const next: HttpHandlerFn = (request) => {
      expect(request.headers.get('Authorization')).toBe('Bearer fake-token');
      return of({} as HttpEvent<any>);
    };

    TestBed.runInInjectionContext(() => {
      authInterceptor(req, next).subscribe(() => done());
    });
  });

  it('should not add header if no token', (done) => {

    spyOn(localStorage, 'getItem').and.returnValue(null);

    const req = new HttpRequest('GET', '/test');

    const next: HttpHandlerFn = (request) => {
      expect(request.headers.has('Authorization')).toBeFalse();
      return of({} as HttpEvent<any>);
    };

    TestBed.runInInjectionContext(() => {
      authInterceptor(req, next).subscribe(() => done());
    });
  });

});