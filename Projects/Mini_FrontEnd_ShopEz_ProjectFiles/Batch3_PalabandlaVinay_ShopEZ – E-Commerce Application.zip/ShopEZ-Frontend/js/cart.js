// Run when page loads
$(function () {
  showCart();
});


// Add to Cart
function addToCart(product) {

  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  // Check if product already exists
  let found = false;

  for (let i = 0; i < cart.length; i++) {
    if (cart[i].id === product.id) {
      cart[i].qty++;
      found = true;
      break;
    }
  }

  // If not found =>add new
  if (!found) {
    product.qty = 1;
    cart.push(product);
  }

  localStorage.setItem("cart", JSON.stringify(cart));
  alert("Added to cart!");
}


// Show Cart Items
function showCart() {

  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  let html = "";
  let total = 0;

  // If empty
  if (cart.length === 0) {
    html = `<tr><td colspan="5" class="text-center">Cart is empty</td></tr>`;
    $("#checkoutBtn").hide();
  } else {

    for (let i = 0; i < cart.length; i++) {

      let item = cart[i];
      let itemTotal = item.price * item.qty;
      total = total + itemTotal;

      html += `
        <tr>
          <td>${item.name}</td>
          <td>
            <input type="number" value="${item.qty}" min="1"
              onchange="updateQty(${i}, this.value)">
          </td>
          <td>₹ ${item.price}</td>
          <td>₹ ${itemTotal}</td>
          <td>
            <button onclick="removeItem(${i})">Remove</button>
          </td>
        </tr>
      `;
    }

    $("#checkoutBtn").show();
  }

  $("#cartItems").html(html);
  $("#total").text(total);
}


//Update Quantity
function updateQty(index, qty) {

  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  qty = parseInt(qty);
  if (qty < 1) qty = 1;

  cart[index].qty = qty;

  localStorage.setItem("cart", JSON.stringify(cart));

  showCart();
}

// Remove Item
function removeItem(index) {

  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  cart.splice(index, 1);

  localStorage.setItem("cart", JSON.stringify(cart));

  showCart();
}