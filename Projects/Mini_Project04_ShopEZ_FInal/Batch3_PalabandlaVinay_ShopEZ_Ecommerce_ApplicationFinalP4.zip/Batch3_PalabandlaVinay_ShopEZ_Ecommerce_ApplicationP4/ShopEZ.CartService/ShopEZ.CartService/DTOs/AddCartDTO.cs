﻿namespace ShopEZ.CartService.DTOs
{
    //Add Cart DTO
    public class AddCartDTO
    {
        // User Id
        public int UserId { get; set; }

        // Product Id
        public int ProductId { get; set; }

        // Quantity
        public int Quantity { get; set; }

        // Price
        public decimal Price { get; set; }
    }
}
