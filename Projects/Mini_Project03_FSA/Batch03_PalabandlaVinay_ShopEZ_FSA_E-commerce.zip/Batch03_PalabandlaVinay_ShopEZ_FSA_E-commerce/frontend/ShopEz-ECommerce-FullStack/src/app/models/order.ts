export interface Order {
  orderId: number;
  userId: number;
  orderDate: string;
  totalAmount: number;
}