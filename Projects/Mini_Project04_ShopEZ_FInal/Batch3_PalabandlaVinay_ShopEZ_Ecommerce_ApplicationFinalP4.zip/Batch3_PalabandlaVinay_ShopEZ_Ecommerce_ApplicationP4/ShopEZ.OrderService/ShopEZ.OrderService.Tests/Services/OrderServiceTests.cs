﻿using Moq;

using ShopEZ.OrderService.DTOs;
using ShopEZ.OrderService.Models;
using ShopEZ.OrderService.Repositories;
using ShopEZ.OrderService.Services;

namespace ShopEZ.OrderService.Tests.Services
{
    public class OrderServiceTests
    {
        //CREATE ORDER TEST

        [Fact]
        public async Task CreateOrder_Should_Return_Order()
        {
            // Mock Repository
            var mockRepo =   new Mock<IOrderRepository>();

            // Order DTO
            var dto =
                new OrderDTO
                {
                    UserId = 1,
                    TotalAmount = 75000,
                    OrderItems = new List<OrderItemDTO>
                    {
                        new OrderItemDTO
                        {
                            ProductId = 1,
                            Quantity = 1,
                            Price = 75000
                        }
                    }
                };

            // Dummy Order
            var order =
                new Order
                {
                    OrderId = 1,
                    UserId = 1,
                    TotalAmount = 75000
                };

            // Setup Repository
            mockRepo.Setup(x => x.CreateOrder(dto)) .ReturnsAsync(order);

            // Service Object
            var service =new OrderServiceManager( mockRepo.Object);

            // Call Service
            var result =await service.CreateOrder(dto);

            // Assertions
            Assert.NotNull(result);

            Assert.Equal( 75000, result.TotalAmount);
        }
      //GET ALL ORDER TEST

        [Fact]
        public async Task GetAllOrders_Should_Return_Orders()
        {
            // Mock Repository
            var mockRepo = new Mock<IOrderRepository>();

            // Dummy Orders
            var orders =new List<Order>
                {
                    new Order
                    {
                        OrderId = 1,
                        UserId = 1,
                        TotalAmount = 50000
                    },

                    new Order
                    {
                        OrderId = 2,
                        UserId = 2,
                        TotalAmount = 30000
                    }
                };

            // Setup Repository
            mockRepo.Setup( x => x.GetAllOrders()).ReturnsAsync(orders);

            // Service Object
            var service =new OrderServiceManager( mockRepo.Object);

            // Call Service
            var result = await service.GetAllOrders();

            // Assertions
            Assert.NotNull(result);

            Assert.Equal(2, result.Count());
        }

        //GET ORDER BY ID TEST

        [Fact]
        public async Task GetOrderById_Should_Return_Order()
        {
            // Mock Repository
            var mockRepo = new Mock<IOrderRepository>();

            // Dummy Order
            var order = new Order
                {
                    OrderId = 1,
                    UserId = 1,
                    TotalAmount = 45000
                };

            // Setup Repository
            mockRepo.Setup( x => x.GetOrderById(1)) .ReturnsAsync(order);

            // Service Object
            var service =new OrderServiceManager(mockRepo.Object);

            // Call Service
            var result = await service.GetOrderById(1);

            // Assertions
            Assert.NotNull(result);

            Assert.Equal( 1,  result.OrderId);
        }

        //ORDER NOT FOUND TEST

        [Fact]
        public async Task GetOrderById_Should_Return_Null()
        {
            // Mock Repository
            var mockRepo =new Mock<IOrderRepository>();

            // Setup Repository
            mockRepo.Setup( x => x.GetOrderById(100)).ReturnsAsync( (Order?)null);

            // Service Object
            var service = new OrderServiceManager( mockRepo.Object);

            // Call Service
            var result =await service.GetOrderById(100);

            // Assertions
            Assert.Null(result);
        }

       //GET ORDER BYUSER TEST

        [Fact]
        public async Task GetOrdersByUserId_Should_Return_Orders()
        {
            // Mock Repository
            var mockRepo = new Mock<IOrderRepository>();

            // Dummy Orders
            var orders =new List<Order>
                {
                    new Order
                    {
                        OrderId = 1,
                        UserId = 1,
                        TotalAmount = 50000
                    },

                    new Order
                    {
                        OrderId = 2,
                        UserId = 1,
                        TotalAmount = 75000
                    }
                };

            // Setup Repository
            mockRepo.Setup( x => x.GetOrdersByUserId(1)).ReturnsAsync(orders);

            // Service Object
            var service =new OrderServiceManager( mockRepo.Object);

            // Call Service
            var result =  await service.GetOrdersByUserId(1);

            // Assertions
            Assert.Equal(2, result.Count());
        }
    }
}