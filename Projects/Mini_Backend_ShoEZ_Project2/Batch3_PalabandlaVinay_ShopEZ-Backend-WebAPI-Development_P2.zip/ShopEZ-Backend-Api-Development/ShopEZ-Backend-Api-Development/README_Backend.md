﻿# ShopEZ-Backend-API README FILE, HOW TO BUILD STEP BY STEP

## Final Folder Structure
ShopEZ-Backend-Api/
├── Controllers/
│   ├── AuthController.cs    
│   ├── ProductsController.cs    
│   └── OrdersController.cs        
├── Models/
│   ├── User.cs
│   ├── Product.cs
│   ├── Order.cs
│   └── OrderItem.cs
├── DTOs/
│   ├── LoginDTO.cs
│   ├── ProductDTO.cs
│   ├── OrderDTO.cs
│   └── OrderItemDTO.cs
├── Data/
│   └── ApplicationDbContext.cs
├── Repositories/
│   ├── IProductRepository.cs
│   ├── ProductRepository.cs
│   ├── IOrderRepository.cs
│   └── OrderRepository.cs
├── Services/
│   ├── AuthService.cs  
│   ├── IProductService.cs + ProductService.cs
│   └── IOrderService.cs + OrderService.cs 
├── Properties/launchSettings.json
├── appsettings.json
├── Program.cs
└── ShopEZ-Backend-Api.csproj
```
-----
Step-by-Step Setup

 Step 1: Create Project in Visual Studio
```
File -> New -> Project -> ASP.NET Core Web API
Name: ShopEZ-Backend-APi | Framework: .NET 10.0.3
```

 Step 2: Create Folders
Right-click project->Add ->New Folder for each:
Controllers, Models, DTOs, Data, Repositories, Services Etc

Step 3: ADD All Required .cs Files
Add file provided into its matching folder.

Step 4: Install NuGet Packages
Open Package Manager Console (Tools -> NuGet -> Package Manager Console):
======================================================
Install-Package Microsoft.EntityFrameworkCore.SqlServer
Install-Package Microsoft.EntityFrameworkCore.Tools
Install-Package Microsoft.AspNetCore.Authentication.JwtBearer
Install-Package System.IdentityModel.Tokens.Jwt
Install-Package Swashbuckle.AspNetCore
========================================================
Step 5: Update Connection String in appsettings.json
LocalDB: `"Server=VINAYKUMAR\\SQLEXPRESS\\mssqllocaldb;Database=ShopEZ_DB;Trusted_Connection=True;"`
Full SQL Server: `"Server=YOUR_SERVER;Database=ShopEZ_DB;Trusted_Connection=True;"`

Step 6: Fix Namespace and Required Packges 
 in all files with your actual project namespace if different.

Step 7: Create Database via Migrations
================================================
Add-Migration InitialCreate
Update-Database
================================================

Step 8: Run the Project
Press F5 -> Swagger opens at https://localhost:7121/swagger

Postman Testing Guide

1. Login -> Get Token
POST /api/auth/login
```json
{ "email": "admin1@gamil.com", "password": "admin123" }
```
Response: `{ "token": "eyJ..." }` ->COPY this token!

2.Set Token in Postman
Authorization tab -> Bearer Token ->  paste token

3.Add Product (Admin token)
POST /api/products
```json
{ "name": "iPhone 15", "description": "Apple smartphone", "price": 79999, "stock": 50 }
```
4 Get All Products (no token needed)
GET /api/products

5 Get Product by ID
GET /api/products/1

6 Update Product (Admin token)
PUT /api/products/1
```json
{ "name": "iPhone 15 Pro", "description": "Updated", "price": 99999, "stock": 40 }
```

7.Delete Product (Admin token)
DELETE /api/products/1

8.Get All Orders (Admin token)
GET /api/orders

9.Get Order by ID (any token)
GET /api/orders/1
=========================================
Error Testing

| Scenario Expected |
|=============================================================
| Login with wrong password | 401 Unauthorized |
| Order non-existent product | 404 Not Found |
| Order with quantity 0 | 400 Bad Request |
| Order more than stock | 400 Bad Request |
| Customer accessing admin route | 403 Forbidden |

How JWT Works
1.Login =>server creates a signed token containing: userId, email, role
2.Client stores token and sends it in every request header: `Authorization: Bearer...`
3.Server validates the signature, reads the role from the token
4.`[Authorize(Role="Admin")]` checks Role = "Admin" blocks others with 403
==================================================================
 Architecture
========================================================================
Request =>Controller =>Service -> Repository -> DbContext-> SQL Server
========================================================================
Controller: HTTP handling, input validation
Model     :Model Classes(Entities)
Service   : Business logic
Repository: DB queries via EF Core
DbContext : Bridge to SQL Server
==================================================================================


