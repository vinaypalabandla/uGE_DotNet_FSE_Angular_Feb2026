import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order.success',
  imports: [],
   standalone: true,
  templateUrl: './order.success.html',
  styleUrl: './order.success.css',
})
export class OrderSuccess {
  order: any;

  constructor(private router: Router) {
    this.order = history.state.order; // order  id logic
  }

  goToProducts() {
    this.router.navigate(['/products']);
  }
}
