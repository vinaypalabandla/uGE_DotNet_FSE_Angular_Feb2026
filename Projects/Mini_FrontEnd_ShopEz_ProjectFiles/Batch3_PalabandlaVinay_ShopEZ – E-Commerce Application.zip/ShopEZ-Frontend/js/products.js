
$(document).ready(function () {
  loadProducts();
});


/* ---- Step 1: Load products ---- */
function loadProducts() {
  $.getJSON("data/products.json", function (products) {
    showFilterButtons(products);
    displayProducts(products);
  });
}


/* ---- Step 2: Category Buttons ---- */
function showFilterButtons(products) {

  var categories = [];

  products.forEach(function (p) {
    if (categories.indexOf(p.category) === -1)
      categories.push(p.category);
  });

  var html = `<button class="btn btn-primary filter-btn" onclick="filterProducts('All')">All</button>`;

  categories.forEach(function (cat) {
    html += `<button class="btn btn-outline-primary filter-btn"
              onclick="filterProducts('${cat}')">${cat}</button>`;
  });

  $("#filterButtons").html(html);
}


/* ---- Step 3: Filter ---- */
function filterProducts(category) {

  $.getJSON("data/products.json", function (products) {

    if (category === "All") {
      displayProducts(products);
    } else {
      var filtered = products.filter(function (p) {
        return p.category === category;
      });
      displayProducts(filtered);
    }

  });

}


/* ---- Step 4: Display Products ---- */
function displayProducts(products) {

  var html = "";

  products.forEach(function (p) {

    html += `
      <div class="col-md-3 mb-4">
        <div class="card h-100">

          <img src="${p.image}" class="card-img-top"
               alt="${p.name}" onerror="this.src='images/no-image.png'">

          <div class="card-body d-flex flex-column">

            <h5 class="card-title">${p.name}</h5>
            <p class="card-text text-muted small">${p.description}</p>
            <p class="product-price">₹ ${p.price}</p>
            <span class="badge bg-info text-dark mb-2">${p.category}</span>

            <div class="mt-auto">
              <a href="product-details.html?id=${p.id}"
                 class="btn btn-primary btn-sm">View Details</a>

              <button class="btn btn-success btn-sm"
                onclick='addToCart(${JSON.stringify(p)})'>
                Add to Cart
              </button>
            </div>

          </div>

        </div>
      </div>
    `;
  });

  $("#productList").html(html);
}