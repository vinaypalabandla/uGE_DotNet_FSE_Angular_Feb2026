﻿using Moq;

using ShopEZ.ProductService.DTOs;
using ShopEZ.ProductService.Models;
using ShopEZ.ProductService.Repositories;
using ShopEZ.ProductService.Services;

namespace ShopEZ.ProductService.Tests.Services
{
    public class ProductServiceTests
    {
        //GET ALL PRODUCTS TESTING

        [Fact]
        public async Task GetAllProducts_Should_Return_All_Products()
        {
            // Mock Repository
            var mockRepo =new Mock<IProductRepository>();

            // Dummy Product List
            var products = new List<Product>
                {
                    new Product
                    {
                        ProductId = 1,
                        Name = "Laptop",
                        Description = "Gaming Laptop",
                        Price = 75000,
                        Category = "Electronics",
                        ImageUrl = "image1.jpg"
                    },

                    new Product
                    {
                        ProductId = 2,
                        Name = "Mobile",
                        Description = "Android Mobile",
                        Price = 25000,
                        Category = "Electronics",
                        ImageUrl = "image2.jpg"
                    }
                };

            // Setup Repository
            mockRepo.Setup(x => x.GetAllProducts()).ReturnsAsync(products);

            // Service Object
            var service =new ProductServiceManager(mockRepo.Object);

            // Call Service
            var result =await service.GetAllProducts();

            // Assertions
            Assert.NotNull(result);

            Assert.Equal(2, result.Count());
        }
         //GE PRODUCT BY ID TESTING

        [Fact]
        public async Task GetProductById_Should_Return_Product()
        {
            // Mock Repository
            var mockRepo = new Mock<IProductRepository>();

            // Dummy Product
            var product =  new Product
                {
                    ProductId = 1,
                    Name = "Laptop",
                    Description = "Gaming Laptop",
                    Price = 75000,
                    Category = "Electronics",
                    ImageUrl = "image.jpg"
                };

            // Setup Repository
            mockRepo.Setup( x => x.GetProductById(1)) .ReturnsAsync(product);

            // Service Object
            var service =new ProductServiceManager( mockRepo.Object);

            // Call Service
            var result = await service.GetProductById(1);

            // Assertions
            Assert.NotNull(result);

            Assert.Equal("Laptop",result.Name);
        }
         //ADD PRODUCT  TEST

        [Fact]
        public async Task AddProduct_Should_Return_Success()
        {
            // Mock Repository
            var mockRepo = new Mock<IProductRepository>();

            // Product DTO
            var dto =new ProductDTO
                {
                    Name = "Keyboard",
                    Description = "Mechanical Keyboard",
                    Price = 3000,
                    Category = "Accessories",
                    ImageUrl = "keyboard.jpg"
                };

            // Setup Repository
            mockRepo.Setup(x => x.AddProduct(dto)).ReturnsAsync(1);

            // Service Object
            var service = new ProductServiceManager( mockRepo.Object);

            // Call Service
            var result =await service.AddProduct(dto);

            // Assertions
            Assert.Equal(1, result);
        }
        //DELETE PRODUCTLIST

        [Fact]
        public async Task DeleteProduct_Should_Return_Success()
        {
            // Mock Repository
            var mockRepo = new Mock<IProductRepository>();

            // Setup Repository
            mockRepo.Setup(  x => x.DeleteProduct(1)) .ReturnsAsync(1);

            // Service Object
            var service =new ProductServiceManager(mockRepo.Object);

            // Call Service
            var result =await service.DeleteProduct(1);

            // Assertions
            Assert.Equal(1, result);
        }
     //SEARCH PRODUCTLIST

        [Fact]
        public async Task SearchProducts_Should_Return_Products()
        {
            // Mock Repository
            var mockRepo = new Mock<IProductRepository>();

            // Dummy Data
            var products = new List<Product>
                {
                    new Product
                    {
                        ProductId = 1,
                        Name = "Laptop",
                        Description = "Gaming",
                        Price = 75000,
                        Category = "Electronics",
                        ImageUrl = "img.jpg"
                    }
                };

            // Setup Repository
            mockRepo.Setup(x => x.SearchProducts("Laptop")).ReturnsAsync(products);

            // Service Object
            var service =new ProductServiceManager( mockRepo.Object);

            // Call Service
            var result =await service.SearchProducts( "Laptop");

            // Assertions
            Assert.Single(result);
        }
    }
}