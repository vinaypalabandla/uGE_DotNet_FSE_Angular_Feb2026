﻿using ShopEZ.ProductService.DTOs;
using ShopEZ.ProductService.Models;

namespace ShopEZ.ProductService.Repositories
{
    // Product Repository Interface
    public interface IProductRepository
    {
        // Get all products
        Task<IEnumerable<Product>> GetAllProducts();

        // Get product by id
        Task<Product> GetProductById(int id);

        // Add product
        Task<int> AddProduct(ProductDTO dto);

        // Update product
        Task<int> UpdateProduct(int id,ProductDTO dto);

        // Delete product
        Task<int> DeleteProduct(int id);

        // Search products
        Task<IEnumerable<Product>>SearchProducts(string name);

        // Filter by category
        Task<IEnumerable<Product>>GetProductsByCategory(string category);

        // Pagination
        Task<IEnumerable<Product>> GetPaginatedProducts( int pageNumber,int pageSize);
        // Reduce Product Stock
        Task<int> ReduceStock(int productId, int quantity);
    }
}