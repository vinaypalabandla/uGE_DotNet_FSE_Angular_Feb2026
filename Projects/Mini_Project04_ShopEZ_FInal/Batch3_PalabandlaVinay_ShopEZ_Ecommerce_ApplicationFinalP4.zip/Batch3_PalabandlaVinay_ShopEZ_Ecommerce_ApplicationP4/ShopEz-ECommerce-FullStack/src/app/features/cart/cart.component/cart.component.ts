import { Component, OnInit } from '@angular/core';
import { CartItem } from '../../../models/cart.item';
import { CartService } from '../../../core/services/cart.service';
import { CommonModule } from '@angular/common';
import { Route, Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-cart.component',
  imports: [CommonModule, RouterModule],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css',
})
export class CartComponent implements OnInit {

  cartItems: CartItem[] = [];
  // message alertstokc
  message: string = '';
  //constructor
  constructor(private cartService: CartService, private router: Router) { }

  ngOnInit() {
    this.cartService.cart$.subscribe(items => {
      this.cartItems = items;

      // MESSAGE ALERT STOCK
      this.cartService.message$.subscribe(msg => {
        this.message = msg;
      });

    });
  }

  increase(id: number) {
    this.cartService.increaseQty(id);
  }

  decrease(id: number) {
    this.cartService.decreaseQty(id);
  }

  remove(id: number) {
    this.cartService.removeItem(id);
  }

  clearCart() {
    this.cartService.clearCart();
  }

  getTotal() {
    return this.cartService.getTotal();
  }

  goToProducts() {
    this.router.navigate(['/products']);
  }
  // got  to check out page logic 
  goToCheckout() {
    this.router.navigate(['/checkout']);
  }
}
