﻿using ShopEZ_Backend_Api_Development.DTOs;
using ShopEZ_Backend_Api_Development.Models;
using ShopEZ_Backend_Api_Development.Repositories;

namespace ShopEZ_Backend_Api_Development.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _repo;
        private readonly ILogger<ProductService> _logger;

        public ProductService(IProductRepository repo, ILogger<ProductService> logger)
        {
            _repo = repo;
            _logger = logger;
        }

       //Get All Products
        public async Task<IEnumerable<Product>> GetAllAsync()
        {
            _logger.LogInformation("Getting all products");

            var products = await _repo.GetAllAsync();

            return products;
        }

      //Get Product BY ID
        public async Task<Product> GetByIdAsync(int id)
        {
            _logger.LogInformation("Getting product by id");

            var product = await _repo.GetByIdAsync(id);

            return product;
        }
         //Add Product
        public async Task AddAsync(ProductDTO dto)
        {
            _logger.LogInformation("Adding product");

            var product = new Product
            {
                Name = dto.Name,
                Description = dto.Description,
                Price = dto.Price,
                ImageUrl = dto.ImageUrl,
                Stock = dto.Stock
            };

            await _repo.AddAsync(product);
        }
        //Upadte Product
        public async Task UpdateAsync(int id, ProductDTO dto)
        {
            _logger.LogInformation("Updating product");

            var product = await _repo.GetByIdAsync(id);

            if (product == null)
            {
                throw new Exception("Product not found");
            }

            product.Name = dto.Name;
            product.Description = dto.Description;
            product.Price = dto.Price;
            product.Stock = dto.Stock;

            await _repo.UpdateAsync(product);
        }
       //Delete By Product 
        public async Task<bool> DeleteAsync(int id)
        {
            _logger.LogInformation("Deleting product");

            var product = await _repo.GetByIdAsync(id);

            if (product == null)
            {
                return false; 
            }

            await _repo.DeleteAsync(id);

            return true; 
        }
    }
}