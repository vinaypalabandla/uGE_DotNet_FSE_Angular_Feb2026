﻿using ShopEZ.CartService.DTOs;
using ShopEZ.CartService.Models;

namespace ShopEZ.CartService.Repositories
{
    // Cart Repository Interface
    public interface ICartRepository
    {
        // Add Item To Cart
        Task<Cart> AddToCart(AddCartDTO dto);

        // Get User Cart
        Task<Cart?> GetCartByUserId(int userId);

        // Update Quantity
        Task<CartItem?> UpdateCartItem(UpdateCartDTO dto);

        // Remove Cart Item
        Task<bool> RemoveCartItem( int cartItemId);

        // Clear Cart
        Task<bool> ClearCart(int userId);
    }
}