﻿using ShopEZ.UserService.Models;

namespace ShopEZ.UserService.Repositories
{
    public interface IAuthRepository
    {
        // Get User By Email
        Task<User?> GetUserByEmail(string email);

        // Register User
        Task AddUser(User user);

        // Login User
        Task<User?> Login(string email,string password);
    }
}