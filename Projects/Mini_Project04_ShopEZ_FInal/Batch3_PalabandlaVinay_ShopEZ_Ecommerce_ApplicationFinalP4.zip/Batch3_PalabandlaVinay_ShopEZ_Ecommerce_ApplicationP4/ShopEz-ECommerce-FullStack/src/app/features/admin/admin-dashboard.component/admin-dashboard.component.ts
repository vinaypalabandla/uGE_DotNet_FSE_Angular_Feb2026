import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../../services/product-service';
import { Product } from '../../../models/product';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  products: Product[] = [];

  newProduct: Product = {
    productId: 0,
    name: '',
    description: '',
    price: 0,
    imageUrl: '',
    stock: 0,
    category: ''
  };

  // Dedicated message states for different actions
  addMessage: string = '';
  addMessageType: 'success' | 'error' = 'success';

  updateMessage: string = '';
  updateMessageType: 'success' | 'error' = 'success';

  deleteMessage: string = '';
  deleteMessageType: 'success' | 'error' = 'success';

  selectedProduct: Product | null = null;

  constructor(
    private productService: ProductService,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.loadProducts();
  }

  // UI UPDATE AFTER API
  loadProducts() {
    this.productService.getAll().subscribe({
      next: (res) => {
        this.products = [...res];
        this.cdr.detectChanges(); // Trigger instant refresh
      },
      error: () => console.error('Failed to load products')
    });
  }

  showActionMessage(action: 'add' | 'update' | 'delete', msg: string, type: 'success' | 'error' = 'success') {
    if (action === 'add') {
      this.addMessage = msg;
      this.addMessageType = type;
    } else if (action === 'update') {
      this.updateMessage = msg;
      this.updateMessageType = type;
    } else if (action === 'delete') {
      this.deleteMessage = msg;
      this.deleteMessageType = type;
    }
    
    this.cdr.detectChanges(); // Immediately reflect message in UI

    setTimeout(() => {
      if (action === 'add') this.addMessage = '';
      else if (action === 'update') this.updateMessage = '';
      else if (action === 'delete') this.deleteMessage = '';
      this.cdr.detectChanges(); // Hide message after 3 seconds
    }, 3000);
  }

  validateProduct(product: Product): boolean {
    if (!product.name || product.name.toString().trim() === '') return false;
    if (!product.description || product.description.toString().trim() === '') return false;
    if (product.price == null || product.price < 0) return false;
    if (product.stock == null || product.stock < 0) return false;
    if (!product.category || product.category.toString().trim() === '') return false;
    if (!product.imageUrl || product.imageUrl.toString().trim() === '') return false;
    return true;
  }

  // AFTER ADD reload from DB
  addProduct() {
    if (!this.validateProduct(this.newProduct)) {
      this.showActionMessage('add', 'Please fill all required fields correctly.', 'error');
      return;
    }

    this.productService.add(this.newProduct).subscribe({
      next: () => {
        this.loadProducts(); // instantly refresh list
        this.showActionMessage('add', 'Product added successfully', 'success');
        this.resetForm();
      },
      error: (err) => {
        // If the backend returns 200/201 but with unparseable text, it triggers the error block
        if (err.status >= 200 && err.status < 300) {
          this.loadProducts();
          this.showActionMessage('add', 'Product added successfully', 'success');
          this.resetForm();
        } else {
          this.showActionMessage('add', 'Failed to add product', 'error');
        }
      }
    });
  }

  editProduct(product: Product) {
    this.selectedProduct = { ...product };
    // Auto-scroll to edit section
    setTimeout(() => {
      const editSection = document.getElementById('edit-section');
      if (editSection) {
        editSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 50);
  }

  // AFTER UPDATE reload
  updateProduct() {
    if (!this.selectedProduct) return;
    
    if (!this.validateProduct(this.selectedProduct)) {
      this.showActionMessage('update', 'Please fill all required fields correctly.', 'error');
      return;
    }

    this.productService.update(this.selectedProduct).subscribe({
      next: () => {
        this.loadProducts(); // instantly refresh list
        this.selectedProduct = null;
        this.showActionMessage('update', 'Product updated successfully', 'success');
      },
      error: (err) => {
        if (err.status >= 200 && err.status < 300) {
          this.loadProducts();
          this.selectedProduct = null;
          this.showActionMessage('update', 'Product updated successfully', 'success');
        } else {
          this.showActionMessage('update', 'Failed to update product', 'error');
        }
      }
    });
  }

  // AFTER DELETE reload
  deleteProduct(id: number) {
    this.productService.delete(id).subscribe({
      next: () => {
        this.loadProducts(); // instantly refresh list
        this.showActionMessage('delete', 'Product deleted successfully', 'success');
      },
      error: (err) => {
        if (err.status >= 200 && err.status < 300) {
          this.loadProducts();
          this.showActionMessage('delete', 'Product deleted successfully', 'success');
        } else {
          this.showActionMessage('delete', 'Failed to delete product', 'error');
        }
      }
    });
  }

  resetForm() {
    this.newProduct = {
      productId: 0,
      name: '',
      description: '',
      price: 0,
      imageUrl: '',
      stock: 0,
      category: ''
    };
  }

  trackById(index: number, item: Product) {
    return item.productId;
  }

  cancelEdit() {
    this.selectedProduct = null;
  }
}