﻿using System.ComponentModel.DataAnnotations;

namespace ShopEZ_Backend_Api_Development.DTOs
{
    public class LoginDTO
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }
    }
}
