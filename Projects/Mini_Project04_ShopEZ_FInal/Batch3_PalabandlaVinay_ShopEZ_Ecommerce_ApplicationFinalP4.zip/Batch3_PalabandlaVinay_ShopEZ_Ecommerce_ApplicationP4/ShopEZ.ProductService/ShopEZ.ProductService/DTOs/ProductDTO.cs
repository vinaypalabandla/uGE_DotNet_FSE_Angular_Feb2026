﻿using System.ComponentModel.DataAnnotations;
namespace ShopEZ.ProductService.DTOs
{
        // Product DTO
    public class ProductDTO
        
    {
      
          // Product Name
         [Required]
         public string Name { get; set; }= string.Empty;

        // Description
        [Required]
          public string Description { get; set; }= string.Empty;

        // Price
        [Required]
         public decimal Price { get; set; }

          // Image
           [Required]
         public string ImageUrl { get; set; } = string.Empty;

            // Stock
            [Required]
            public int Stock { get; set; } 

            // Category
            [Required]
            public string Category { get; set; }=string.Empty;
        }
    
}
