﻿using ShopEZ.ProductService.DTOs;
using ShopEZ.ProductService.Models;
using ShopEZ.ProductService.Repositories;

namespace ShopEZ.ProductService.Services
{
    // Product Service Class
    public class ProductServiceManager : IProductServiceManager
    {
        // Repository Object
        private readonly IProductRepository _repository;

        // Constructor ingecting
        public ProductServiceManager( IProductRepository repository)
        {
            _repository = repository;
        }

        //GET ALL PRODUCTS
        public async Task<IEnumerable<Product>> GetAllProducts()
        {
            return await _repository.GetAllProducts();
        }

         //GET PRODUCT BY ID
        public async Task<Product>  GetProductById(int id)
        {
            return await _repository.GetProductById(id);
        }

         //ADD PRODUCT
        public async Task<int> AddProduct(ProductDTO dto)
        {
            return await _repository .AddProduct(dto);
        }

        //UPDATE PRODUCT
        public async Task<int> UpdateProduct( int id, ProductDTO dto)
        {
            return await _repository.UpdateProduct(id, dto);
        }

        // DELETE PRODUCT
        public async Task<int> DeleteProduct(int id)
        {
            return await _repository .DeleteProduct(id);
        }

        // SEARCH PRODUCTS
        public async Task<IEnumerable<Product>> SearchProducts(string name)
        {
            return await _repository.SearchProducts(name);
        }

        // FILTER BY CATEGORY
        public async Task<IEnumerable<Product>> GetProductsByCategory(string category)
        {
            return await _repository.GetProductsByCategory(category);
        }

        // PAGINATION
       
        public async Task<IEnumerable<Product>>GetPaginatedProducts(int pageNumber,int pageSize)
        {
            return await _repository.GetPaginatedProducts( pageNumber, pageSize);
        }

        // REDUCE STOCK
        public async Task<int> ReduceStock(int productId, int quantity)
        {
            return await _repository.ReduceStock(productId, quantity);
        }
    }
}