﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using ShopEZ.CartService.Controllers;
using ShopEZ.CartService.DTOs;
using ShopEZ.CartService.Models;
using ShopEZ.CartService.Services;
using Xunit;

namespace ShopEZ.CartService.Tests.Controllers
{
    public class CartControllerTests
    {
        // Mock service
        private readonly Mock<ICartService> _mockService;

        // Controller
        private readonly CartController _controller;

        // Constructor
        public CartControllerTests()
        {
            _mockService = new Mock<ICartService>();
            _controller = new CartController(_mockService.Object);
        }

        // ADD TO CART
        [Fact]
        public async Task AddToCart_ReturnsOk()
        {
            // Arrange
            var dto = new AddCartDTO();

            _mockService
                .Setup(x => x.AddToCart(dto))
                .ReturnsAsync(new Cart());

            // Act
            var result = await _controller.AddToCart(dto);

            // Assert
            Assert.IsType<OkObjectResult>(result);
        }

        // GET USER CART
        [Fact]
        public async Task GetCartByUserId_ReturnsOk()
        {
            // Arrange
            _mockService
                .Setup(x => x.GetCartByUserId(1))
                .ReturnsAsync(new Cart());

            // Act
            var result = await _controller.GetCartByUserId(1);

            // Assert
            Assert.IsType<OkObjectResult>(result);
        }

        // UPDATE CART ITEM
        [Fact]
        public async Task UpdateCartItem_ReturnsOk()
        {
            // Arrange
            var dto = new UpdateCartDTO();

            _mockService
                .Setup(x => x.UpdateCartItem(dto))
                .ReturnsAsync(new CartItem());

            // Act
            var result = await _controller.UpdateCartItem(dto);

            // Assert
            Assert.IsType<OkObjectResult>(result);
        }

        // REMOVE CART ITEM
        [Fact]
        public async Task RemoveCartItem_ReturnsOk()
        {
            // Arrange
            _mockService
                .Setup(x => x.RemoveCartItem(1))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.RemoveCartItem(1);

            // Assert
            Assert.IsType<OkObjectResult>(result);
        }

        // CLEAR CART
        [Fact]
        public async Task ClearCart_ReturnsOk()
        {
            // Arrange
            _mockService.Setup(x => x.ClearCart(1))
                .ReturnsAsync(true);
            // Act
            var result = await _controller.ClearCart(1);
            // Assert
            Assert.IsType<OkObjectResult>(result);
        }
    }
}