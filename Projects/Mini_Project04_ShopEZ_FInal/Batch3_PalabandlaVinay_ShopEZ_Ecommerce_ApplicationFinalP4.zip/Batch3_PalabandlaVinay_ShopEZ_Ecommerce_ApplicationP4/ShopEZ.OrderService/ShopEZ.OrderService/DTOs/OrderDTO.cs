﻿namespace ShopEZ.OrderService.DTOs
{
    //Order DTO
    public class OrderDTO
    {
        // User Id
        public int UserId { get; set; }

        // Total Amount
        public decimal TotalAmount { get; set; }

        // Order Items
        public List<OrderItemDTO> OrderItems { get; set; }
            = new List<OrderItemDTO>();
    }
}
