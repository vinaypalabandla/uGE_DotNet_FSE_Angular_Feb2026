﻿using ShopEZ_Backend_Api_Development.Models;

namespace ShopEZ_Backend_Api_Development.Repositories
{
    public interface IOrderRepository
    {
        Task<IEnumerable<Order>> GetAllAsync();
        Task<Order> GetByIdAsync(int id);
        Task AddAsync(Order order);
    }
}
