﻿using System.ComponentModel.DataAnnotations;

namespace ShopEZ_Backend_Api_Development.Models
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [Required]
        [StringLength(500)]
        public string Description { get; set; }

        [Required]
        [Range(1, 100000, ErrorMessage = "Price must be greater than 0")]
        public decimal Price { get; set; }

        [Url(ErrorMessage = "Invalid URL format")]
        [Required]
        public string ImageUrl { get; set; } 

        [Required]
        [Range(0, 10000, ErrorMessage = "Stock cannot be negative")]
        public int Stock { get; set; }

        [Required]
        public string Category { get; set; }

        //Navigation 1 Product=>Many OrderItems
        public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
    
}
}
