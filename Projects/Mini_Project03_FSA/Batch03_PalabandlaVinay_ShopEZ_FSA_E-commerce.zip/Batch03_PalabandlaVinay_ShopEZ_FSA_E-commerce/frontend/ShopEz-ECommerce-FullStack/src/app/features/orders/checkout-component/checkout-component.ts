import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CartService } from '../../../core/services/cart.service';
import { Router } from '@angular/router';
import { OrderService } from '../../../core/services/order.service';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './checkout-component.html',
  styleUrls: ['./checkout-component.css']
})
export class CheckoutComponent implements OnInit {

  cartItems: any[] = [];
  total = 0;

  // form data
  form = {
    firstName: '',
    lastName: '',
    address: '',
    city: '',
    pin: '',
    state: '',
    phone: '',
    payment: 'Cash on Delivery'
  };

  constructor(
    private cartService: CartService,
    private router: Router,
    private orderService: OrderService
  ) { }

  ngOnInit() {
    this.cartService.cart$.subscribe(items => {
      this.cartItems = items;
      this.total = this.cartService.getTotal();
    });
  }
  placeOrder() {

    // 1. VALIDATION CHECK
    if (
      !this.form.firstName ||
      !this.form.lastName ||
      !this.form.address ||
      !this.form.city ||
      !this.form.pin ||
      !this.form.state ||
      !this.form.phone
    ) {
      alert(' Please fill all required fields');
      return;
    }


    // 2. EMPTY CART CHECK
    if (this.cartItems.length === 0) {
      alert('🛒 Cart is empty');
      return;
    }

    //  3. PREPARE DATA FOR BACKEND
    const orderPayload = {
      userId: 1, // later replace with logged user
      totalAmount: this.total,
      //in backend orderItems reflected 
      Items: this.cartItems.map(item => ({
        productId: item.productId,
        quantity: item.quantity,
        price: item.price
      }))
    };

    // 4. CALL BACKEND API
    this.orderService.placeOrder(orderPayload).subscribe({

      next: (res) => {

        console.log('Order Success', res);

        //  6. CLEAR CART
        this.cartService.clearCart();

        // 7. NAVIGATE TO SUCCESS PAGE
        this.router.navigate(['/order-success'], {
          state: { order: res }
        });
      },

      error: (err) => {
        console.error('Order Failed', err);
        alert(' Order Failed. Try again');
      }


    });

  }
  goToCart() {
    this.router.navigate(['/cart']);
  }
}