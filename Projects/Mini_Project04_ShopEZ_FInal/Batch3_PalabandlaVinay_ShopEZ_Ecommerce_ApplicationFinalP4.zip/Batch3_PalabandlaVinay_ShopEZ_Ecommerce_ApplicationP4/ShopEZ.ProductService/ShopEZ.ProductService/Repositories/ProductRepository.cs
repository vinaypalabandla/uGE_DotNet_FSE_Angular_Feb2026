﻿using Dapper;

using ShopEZ.ProductService.Data;
using ShopEZ.ProductService.DTOs;
using ShopEZ.ProductService.Models;
//Pagination Queries using Dapper
namespace ShopEZ.ProductService.Repositories
{
    // Product Repository Class
    public class ProductRepository : IProductRepository
    {
        // Dapper Context Object
        private readonly DapperContext _context;

        // Constructor
        public ProductRepository( DapperContext context)
        {
            _context = context;
        }

        // GET ALL PRODUCTS
        public async Task<IEnumerable<Product>>GetAllProducts()
        {
            // SQL Query
            string query =  "SELECT * FROM Products";

            // Create Connection
            using var connection = _context.CreateConnection();

            // Execute Query
            var products =await connection.QueryAsync<Product>( query);
            return products;
        }

     
        // GET PRODUCT BY ID
       
        public async Task<Product> GetProductById(int id)
        {
            // SQL Query
            string query =
                "SELECT * FROM Products " +
                "WHERE ProductId = @Id";

            // Create Connection
            using var connection = _context.CreateConnection();
            // Execute Query
            var product =  await connection  .QueryFirstOrDefaultAsync<Product>( query,  new { Id = id });
            return product!; // here change ! not symbol I understand possible null warning here
        }

      
        // ADD PRODUCT
      
        public async Task<int>AddProduct(ProductDTO dto)
        {
            // SQL Insert Query
            string query =
                @"INSERT INTO Products
                (Name, Description, Price,
                 ImageUrl, Stock, Category)

                VALUES

                (@Name, @Description, @Price,
                 @ImageUrl, @Stock, @Category)";

            // Create Connection
            using var connection =  _context.CreateConnection();

            // Execute Query
            return await connection.ExecuteAsync( query, dto);
        }

        // UPDATE PRODUCT
     
        public async Task<int>UpdateProduct(  int id, ProductDTO dto)
        {
            // SQL Update Query
            string query =
                @"UPDATE Products

                SET
                    Name = @Name,
                    Description = @Description,
                    Price = @Price,
                    ImageUrl = @ImageUrl,
                    Stock = @Stock,
                    Category = @Category

                WHERE ProductId = @Id";

            // Create Connection
            using var connection = _context.CreateConnection();

            // Execute Query
            return await connection.ExecuteAsync( query,
                new
                {
                    Id = id,
                    dto.Name,
                    dto.Description,
                    dto.Price,
                    dto.ImageUrl,
                    dto.Stock,
                    dto.Category
                });
        }

            // DELETE PRODUCT
        public async Task<int>DeleteProduct(int id)
        {
            // SQL Delete Query
            string query =
                "DELETE FROM Products " +
                "WHERE ProductId = @Id";

            // Create Connection
            using var connection = _context.CreateConnection();

            // Execute Query
            return await connection.ExecuteAsync(query,new { Id = id });
        }
        // SEARCH PRODUCTS
     
        public async Task<IEnumerable<Product>>SearchProducts(string name)
        {
            // SQL Query
            string query =
                @"SELECT * FROM Products
                WHERE Name LIKE '%' + @Name + '%'";

            // Create Connection
            using var connection = _context.CreateConnection();

            // Execute Query
            return await connection.QueryAsync<Product>(query, new { Name = name });
        }

        // FILTER BY CATEGORY
      
        public async Task<IEnumerable<Product>>
            GetProductsByCategory(string category)
        {
            // SQL Query
            string query =
                @"SELECT * FROM Products
                WHERE Category = @Category";

            // Create Connection
            using var connection = _context.CreateConnection();

            // Execute Query
            return await connection.QueryAsync<Product>(query,
                new { Category = category });
        }

      
        // PAGINATION Query Implemented

        public async Task<IEnumerable<Product>> GetPaginatedProducts(int pageNumber,int pageSize)
        {
            // Offset Calculation
            int offset =  (pageNumber - 1) * pageSize;

            // SQL Pagination Query
            string query =
                @"SELECT * FROM Products
                ORDER BY ProductId
                OFFSET @Offset ROWS
                FETCH NEXT @PageSize ROWS ONLY";

            // Create Connection
            using var connection = _context.CreateConnection();

            // Execute Query
            return await connection.QueryAsync<Product>(query,
                new
                {
                    Offset = offset,
                    PageSize = pageSize
                });
        }

        // REDUCE PRODUCT STOCK
        public async Task<int> ReduceStock(int productId, int quantity)
        {
            // SQL Query
            string query =
                @"UPDATE Products
          SET Stock = Stock - @Quantity
          WHERE ProductId = @ProductId
          AND Stock >= @Quantity"; //prevents negative stock

            // Create Connection
            using var connection = _context.CreateConnection();

            // Execute Query
            return await connection.ExecuteAsync(query,
                new
                {
                    ProductId = productId,
                    Quantity = quantity
                });
        }
    }
}