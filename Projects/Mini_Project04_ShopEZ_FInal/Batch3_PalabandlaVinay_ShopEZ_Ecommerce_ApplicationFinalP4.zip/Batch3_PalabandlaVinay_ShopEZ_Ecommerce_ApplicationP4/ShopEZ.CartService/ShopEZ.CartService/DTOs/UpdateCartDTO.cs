﻿namespace ShopEZ.CartService.DTOs
{
    // Update Cart DTO
    public class UpdateCartDTO
    {
        // Cart Item Id
        public int CartItemId { get; set; }

        // Quantity
        public int Quantity { get; set; }
    }
}
