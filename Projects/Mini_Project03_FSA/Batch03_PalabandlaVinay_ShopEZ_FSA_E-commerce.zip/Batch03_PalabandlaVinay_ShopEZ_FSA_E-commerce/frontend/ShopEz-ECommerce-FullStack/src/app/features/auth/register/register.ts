import { Component } from '@angular/core';
import { AuthService } from '../../../core/services/auth-service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterModule],
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})
export class Register {

  // ================= VARIABLES =================
  name: string = '';
  email: string = '';
  password: string = '';

  errorMsg: string = '';
  successMsg: string = '';

  constructor(
    private auth: AuthService,
    private router: Router
  ) { }

  // ================= REGISTER FUNCTION =================
  register() {

    // SIMPLE VALIDATION
    if (!this.name || !this.email || !this.password) {
      this.errorMsg = 'Please fill all fields';
      this.successMsg = '';
      return;
    }

    const data = {
      name: this.name,
      email: this.email,
      password: this.password,
      role: 'Customer'
    };

    // API CALL
    this.auth.register(data).subscribe({

      // SUCCESS
      next: () => {
        this.successMsg = 'Registration successful! Please login.';
        this.errorMsg = '';

        // redirect after 1.5 sec
        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 1500);
      },

      // ERROR
      error: () => {
        this.errorMsg = 'Registration failed. Try again.';
        this.successMsg = '';
      }

    });
  }
}