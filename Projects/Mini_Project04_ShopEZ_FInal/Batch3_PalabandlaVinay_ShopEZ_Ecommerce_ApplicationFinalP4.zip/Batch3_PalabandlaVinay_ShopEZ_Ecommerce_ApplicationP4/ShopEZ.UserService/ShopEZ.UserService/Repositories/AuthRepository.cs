﻿using Microsoft.EntityFrameworkCore;

using ShopEZ.UserService.Data;
using ShopEZ.UserService.Models;

namespace ShopEZ.UserService.Repositories
{
    public class AuthRepository : IAuthRepository
    {
        // Database Context
        private readonly ApplicationDbContext _context;

        // Constructor
        public AuthRepository(ApplicationDbContext context)
        {
            _context = context;
        }

       //CHEKC USER BY EMAIL
        public async Task<User?> GetUserByEmail(string email)
        {
            return await _context.Users
                .FirstOrDefaultAsync( u => u.Email == email);
        }

            //Add User 
        public async Task AddUser(User user)
        {
            _context.Users.Add(user);
            await _context.SaveChangesAsync();
        }
        //Login User

        public async Task<User?> Login( string email, string password)
        {
            return await _context.Users
                .FirstOrDefaultAsync( u => u.Email == email &&u.Password == password);
        }
    }
}