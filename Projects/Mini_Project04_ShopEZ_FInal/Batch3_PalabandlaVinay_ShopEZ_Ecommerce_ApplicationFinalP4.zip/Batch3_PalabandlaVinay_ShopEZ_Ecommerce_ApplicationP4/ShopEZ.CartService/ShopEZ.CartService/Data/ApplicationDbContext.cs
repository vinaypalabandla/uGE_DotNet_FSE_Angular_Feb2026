﻿using Microsoft.EntityFrameworkCore;
using ShopEZ.CartService.Models;

namespace ShopEZ.CartService.Data
{
    // Database Context
    public class ApplicationDbContext: DbContext
    {
        // Constructor
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext>options)
            : base(options) { }

        // Carts Table
        public DbSet<Cart> Carts{ get; set; }

        // CartItems Table
        public DbSet<CartItem> CartItems{ get; set; }
    }
}
