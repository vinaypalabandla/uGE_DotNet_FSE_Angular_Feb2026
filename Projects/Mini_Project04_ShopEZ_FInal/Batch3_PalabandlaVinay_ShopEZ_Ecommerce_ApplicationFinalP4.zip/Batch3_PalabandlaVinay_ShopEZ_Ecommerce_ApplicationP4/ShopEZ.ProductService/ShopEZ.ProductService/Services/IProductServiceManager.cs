﻿using ShopEZ.ProductService.DTOs;
using ShopEZ.ProductService.Models;

namespace ShopEZ.ProductService.Services
{
    // Product Service Interface
    public interface IProductServiceManager
    {
        // Get all products
        Task<IEnumerable<Product>> GetAllProducts();

        // Get product by id
        Task<Product> GetProductById(int id);

        // Add product
        Task<int> AddProduct(ProductDTO dto);

        // Update product
        Task<int> UpdateProduct( int id, ProductDTO dto);

        // Delete product
        Task<int> DeleteProduct(int id);

        // Search products
        Task<IEnumerable<Product>>SearchProducts(string name);

        // Category filter
        Task<IEnumerable<Product>>GetProductsByCategory(string category);

        // Pagination
        Task<IEnumerable<Product>>GetPaginatedProducts(int pageNumber,int pageSize);

        // Reduce Stock
        Task<int> ReduceStock(int productId, int quantity);
    }
}