﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ShopEZ.CartService.Migrations
{
    /// <inheritdoc />
    public partial class CartDecimalFixed : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
