﻿using System.ComponentModel.DataAnnotations;

namespace ShopEZ_Backend_Api_Development.DTOs
{
    public class ProductDTO
    {

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [Required]
        [StringLength(500)]
        public string Description { get; set; }

        [Required]
        [Range(1, 100000)]
        public decimal Price { get; set; }
        [Required]
        public string ImageUrl { get; set; }
        [Required]
        [Range(0, 10000)]
        public int Stock { get; set; }

        [Required]
        public string Category { get; set; }
    }
}
