﻿using Moq;
using ShopEZ.UserService.DTOs;
using ShopEZ.UserService.Helpers;
using ShopEZ.UserService.Models;
using ShopEZ.UserService.Repositories;
using ShopEZ.UserService.Services;
using Microsoft.Extensions.Configuration;

namespace ShopEZ.UserService.Tests.Services
{
    public class AuthServiceTests
    {
       //LOGIN SUCCESS TEST

        [Fact]
        public async Task Login_Should_Return_Token_When_Valid()
        {
            // Mock Repository
            var mockRepo =  new Mock<IAuthRepository>();

            // Dummy User data
            var user = new User
            {
                UserId = 1,
                Name = "Vinay",
                Email = "vinay@gmail.com",
                Password = "123",
                Role = "Customer"
            };

            // Setup Repository
            mockRepo.Setup(x =>x.Login("vinay@gmail.com","123")).ReturnsAsync(user);

            // Fake JWT Config
            var inMemorySettings = new Dictionary<string, string>
                {
                    {"Jwt:Key","ThisIsMyVeryLongSecretKeyForJwtToken123456789"},
                    {"Jwt:Issuer","Test"},
                    {"Jwt:Audience","Test"}
                };

            IConfiguration configuration = new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings!).Build();

            // JWT Helper
            var jwtHelper = new JwtHelper(configuration);

            // Service Object
            var service =new AuthService( mockRepo.Object,jwtHelper);

            // Login DTO
            var dto = new LoginDTO
            {
                Email = "vinay@gmail.com",
                Password = "123"
            };

            // Call Login
            var result =await service.Login(dto);

            // Verify Token
            Assert.NotNull(result);
        }
           //Invalid Login Test

        [Fact]
        public async Task Login_Should_Throw_Exception_When_Invalid()
        {
            // Mock Repository
            var mockRepo =new Mock<IAuthRepository>();

            // Setup Repository
            mockRepo.Setup(x => x.Login("wrong@gmail.com","wrong")).ReturnsAsync( (User?)null);

            // Fake JWT Config
            var inMemorySettings =new Dictionary<string, string>
                {
                    {"Jwt:Key","ThisIsMySecretKey12345"},
                    {"Jwt:Issuer","Test"},
                    {"Jwt:Audience","Test"}
                };

            IConfiguration configuration =new ConfigurationBuilder().AddInMemoryCollection( inMemorySettings!).Build();

            // JWT Helper
            var jwtHelper =new JwtHelper(configuration);

            // Service Object
            var service =new AuthService( mockRepo.Object, jwtHelper);

            // Login DTO
            var dto = new LoginDTO
            {
                Email = "wrong@gmail.com",
                Password = "wrong"
            };

            // Verify Exception
            await Assert.ThrowsAsync<Exception>( async () =>
                {
                    await service.Login(dto);
                });
        }
    }
}