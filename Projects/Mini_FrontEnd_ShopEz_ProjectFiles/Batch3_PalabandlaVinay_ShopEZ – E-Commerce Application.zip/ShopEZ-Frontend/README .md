# ShopEZ - E-Commerce Website Project

---

## What is ShopEZ?

ShopEZ is a frontend-based e-commerceweb application developed using modern web technologies.
ShopEZ is a simple shopping website built using HTML, CSS, JavaScript, Bootstrap and jQuery.
This project is fully client-side and uses JSON for product data and LocalStorage for cart persistence.
It allows users to browse products, view details, add items to a cart, and simulate a checkout process.


In this website, users can:
- See products (AC, Coolers, Laptops, etc.)
- Click on a product to see full details
- Add products to a cart
- Remove products from the cart
- Fill a form and place an order

This project does NOT need any server or database.
All data is saved using the browser's LocalStorage.

---

## Technologies Used

| Technology | What it does |
|------------|--------------|
| HTML5 | Creates the structure of each page |
| CSS3 | Adds colors, fonts and design |
| JavaScript | Makes the website work (buttons, cart, etc.) |
| Bootstrap 5 | Makes the website look good on all screen sizes |
| jQuery | Simplifies JavaScript code |
| LocalStorage | Saves cart data in the browser |
| JSON | Stores product information |

---

## Pages in this Project

| Page | File Name | What it shows |
|------|-----------|---------------|
| Home | index.html | Hero banner and all products |
| Products | products.html | Full list of products with filter |
| Product Details | product-details.html | One product with full details |
| Cart | cart.html | Items added to cart |
| Checkout | checkout.html | Order form and order summary |

---

## Folder Structure

This is how all files are organized:

```
ShopEZ/
│
├── index.html               (Home page)
├── products.html            (All products page)
├── product-details.html     (Single product page)
├── cart.html                (Cart page)
├── checkout.html            (Checkout page)
│
├── css/
│   └── styles.css           (Our custom styles)
│
├── js/
│   ├── common.js            (Navbar shown on all pages)
│   ├── products.js          (Shows product cards)
│   ├── cart.js              (Add, remove, update cart)
│   ├── product-details.js   (Shows one product detail)
│   └── checkout.js          (Order summary and form)
│
├── data/
│   └── products.json        (All product data - 16 products)
│
├── images/
│   └── img1.png, img2.jpg   (Product images)
│
└── lib/
    ├── bootstrap/
    │   ├── bootstrap.min.css
    │   └── bootstrap.bundle.min.js
    └── jquery/
        └── jquery.min.js
```


## Application Flow

Home → Products → Product Details → Add to Cart → Cart → Checkout

---

## How to Run This Project

### Step 1 - Open in VS Code
- Open the ShopEZ folder in VS Code

### Step 2 - Install Live Server
- Click on Extensions icon on the left side bar
- Search for "Live Server"
- Click Install

### Step 3 - Open the Website
- Right click on index.html
- Click "Open with Live Server"
- Browser will open at: http://127.0.0.1:5500/index.html


## What Each JS File Does

### common.js
- This file creates the navbar (top menu)
- It shows how many items are in the cart
- It runs on every page

### products.js
- This file reads the products.json file
- It creates the product cards on screen
- It also creates the filter buttons (AC, Cooler, All, etc.)

### cart.js
- addToCart() - adds a product to the cart
- showCart() - shows all items in the cart table
- updateQty() - changes the quantity of an item
- removeItem() - removes an item from the cart

### product-details.js
- It reads the product id from the URL
- It finds that product in the JSON file
- It shows the product image, name, price and description

### checkout.js
- It shows all cart items in the Order Summary box
- It checks that the form is filled correctly
- It clears the cart and goes to home after order is placed

## Products in This Project

All products are saved in the file: data/products.json

Each product looks like this:

```json
{
  "id": 1,
  "name": "Whirlpool 2025 Model 1.5 Ton Star Inverter AC",
  "description": "High performance AC cooler",
  "price": 60000,
  "category": "AC",
  "image": "images/img1.png"
}
```
Total products: 16

| Category | Number of Products |
|----------|--------------------|
| AC | 6 |
| Cooler | 6 |
| Laptop | 2 |
| iPhone | 1 |
| Tab | 1 |

## How to Add a New Product

1. Open the file: data/products.json
2. Copy one existing product block
3. Paste it at the end (before the last ] bracket)
4. Change the id, name, price, category and image
5. Add the image file to the images/ folder
6. Save the file

Example:

```json
{
  "id": 17,
  "name": "Your Product Name",
  "description": "Your product description here",
  "price": 9999,
  "category": "AC",
  "image": "images/your-image.jpg"
}
```

## How to Add New Images

1. Copy your image file (.jpg or .png)
2. Paste it inside the images/ folder
3. Use a simple name like img13.jpg
4. Update the image value in products.json
## Features of This Website

- Shows products in a 4-column grid
- Filter products by category (AC, Cooler, Laptop, etc.)
- Click View Details to see full product information
- Select quantity before adding to cart
- Cart saves automatically in browser even after refresh
- Update quantity directly in cart table
- Remove any item from cart
- Grand total updates automatically
- Checkout form checks all fields before submitting
- Order summary shows on the right side of checkout page
## Important Notes

- This is a frontend only project - no server is needed
- Cart data is saved in browser LocalStorage
- No real payment is done - it is just a simulation
- Always run using Live Server for best results

## Limitations

* No backend integration
* No real payment system
* Data stored only in browser