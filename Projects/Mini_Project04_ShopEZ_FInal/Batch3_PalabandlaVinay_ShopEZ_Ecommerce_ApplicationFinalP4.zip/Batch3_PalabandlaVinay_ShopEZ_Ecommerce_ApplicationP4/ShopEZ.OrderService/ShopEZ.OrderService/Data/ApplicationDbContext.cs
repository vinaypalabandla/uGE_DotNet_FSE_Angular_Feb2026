﻿using Microsoft.EntityFrameworkCore;

using ShopEZ.OrderService.Models;
namespace ShopEZ.OrderService.Data
{
    //Database Context
    public class ApplicationDbContext : DbContext
    {
        // Constructor
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        // Orders Table
        public DbSet<Order> Orders { get; set; }

        // OrderItems Table
        public DbSet<OrderItem> OrderItems { get; set; }
    }
}


