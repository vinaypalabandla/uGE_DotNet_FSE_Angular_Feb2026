﻿// EF Core namespace
using Microsoft.EntityFrameworkCore;
using ShopEZ.UserService.Models;
namespace ShopEZ.UserService.Data
{
    public class ApplicationDbContext : DbContext
    {
        // Constructor
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {

        }

        // Users Table
        public DbSet<User> Users { get; set; }
    }
}
