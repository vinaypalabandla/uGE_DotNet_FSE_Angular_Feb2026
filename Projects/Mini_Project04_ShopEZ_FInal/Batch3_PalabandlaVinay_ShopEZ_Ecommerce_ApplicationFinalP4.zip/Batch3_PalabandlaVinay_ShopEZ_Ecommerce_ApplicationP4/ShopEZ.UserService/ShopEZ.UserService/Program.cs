using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;   
using ShopEZ.UserService.Data;
using ShopEZ.UserService.Helpers;
using ShopEZ.UserService.Middlewares;
using ShopEZ.UserService.Repositories;
using ShopEZ.UserService.Services;

using System.Text;



namespace ShopEZ.UserService
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

 
            // Add Controllers
            builder.Services.AddControllers();

            // Swagger
     
            builder.Services.AddEndpointsApiExplorer();

            builder.Services.AddSwaggerGen();


            // SQL Server Connection
            builder.Services.AddDbContext<ApplicationDbContext>(options =>
            {
                options.UseSqlServer( builder.Configuration.GetConnectionString("DefaultConnection"));
            });

            // Dependency Injection
            builder.Services.AddScoped<IAuthRepository, AuthRepository>();
            builder.Services.AddScoped<IAuthService, AuthService>();
            builder.Services.AddScoped<AuthService>();

            builder.Services.AddScoped<JwtHelper>();

            // JWT Authentication
            builder.Services
                .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters =
                        new TokenValidationParameters
                        {
                            ValidateIssuer = true,
                            ValidateAudience = true,
                            ValidateLifetime = true,
                            ValidateIssuerSigningKey = true,
                            ValidIssuer = builder.Configuration["Jwt:Issuer"]!,
                            //nullable warnigs used not ! ,This value will never be null

                            ValidAudience = builder.Configuration["Jwt:Audience"]!,
                            //nullable warnings user  not! ,This value will never be null

                            IssuerSigningKey = new SymmetricSecurityKey( Encoding.UTF8.GetBytes(
                                    builder.Configuration["Jwt:Key"]!)) 
                            //nullable warnings used not !, This value will never be null
                        };
                });

            // CORS used here for connection ANGULAR AND  BACKEND
            
            builder.Services.AddCors(options =>
            {
                options.AddPolicy(
                    "AllowAngular",
                    policy =>
                    {
                        policy
                            .WithOrigins("http://localhost:4200")
                            .AllowAnyHeader()
                            .AllowAnyMethod();
                    });
            });


            // Authorization
            builder.Services.AddAuthorization();

            // Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
            builder.Services.AddOpenApi();

            var app = builder.Build();


            // Swagger Middleware
            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                //app.MapOpenApi();

                app.UseSwagger();

                app.UseSwaggerUI();
            }
            // HTTPS
          //  app.UseHttpsRedirection();
            // Custom Exception Middleware
            app.UseMiddleware<ExceptionMiddleware>();

            // CORS
            app.UseCors("AllowAngular");
            // Authentication
            app.UseAuthentication();
            // Authorization
            app.UseAuthorization();

            // Map Controllers
            app.MapControllers();

            //DOCKER COMPOSE PURPOSE USED this  local time COMMENTED THIS CODE

            using (var scope = app.Services.CreateScope())
            {
                try
                {
                    // wait for sql server
                    Thread.Sleep(20000);

                    var db = scope.ServiceProvider
                        .GetRequiredService<ApplicationDbContext>();

                    db.Database.Migrate();

                    Console.WriteLine("User DB Migrated Successfully");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Migration Error");
                    Console.WriteLine(ex.Message);
                }
            }

            app.Run();
        }
    }
}
