
// this below Url used on docker compose time /

export const environment = {
  production: false,

  gatewayUrl: 'http://localhost:5000/gateway',

  productApi: 'http://localhost:5000/gateway/products',

  cartApi: 'http://localhost:5000/gateway/cart',

  orderApi: 'http://localhost:5000/gateway/orders',

  authApi: 'http://localhost:5000/gateway/auth'
};




//Local System Time

// export const environment = {
//   production: false,

//   gatewayUrl: 'https://localhost:5000/gateway',

//   productApi: 'https://localhost:5000/gateway/products',

//   cartApi: 'https://localhost:5000/gateway/cart',

//   orderApi: 'https://localhost:5000/gateway/orders',

//   authApi: 'https://localhost:5000/gateway/auth'
// };
//=====================================