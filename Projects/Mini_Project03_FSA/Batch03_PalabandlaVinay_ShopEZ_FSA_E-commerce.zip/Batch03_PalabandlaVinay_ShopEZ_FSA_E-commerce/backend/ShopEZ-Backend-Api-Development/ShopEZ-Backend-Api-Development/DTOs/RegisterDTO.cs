﻿using System.ComponentModel.DataAnnotations;

namespace ShopEZ_Backend_Api_Development.DTOs
{
    public class RegisterDTO
    {
        [Required]
        public string Name { get; set; }
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        public string Password { get; set; }
    }
}
