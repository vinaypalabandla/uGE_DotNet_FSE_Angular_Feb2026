﻿using Moq;

using ShopEZ.CartService.DTOs;
using ShopEZ.CartService.Models;
using ShopEZ.CartService.Repositories;
using ShopEZ.CartService.Services;

namespace ShopEZ.CartService.Tests.Services
{
    public class CartServiceTests
    {
        [Fact]
        public async Task AddToCart_Should_Return_Cart()
        {
            var mockRepo = new Mock<ICartRepository>();

            var dto = new AddCartDTO
            {
                UserId = 1,
                ProductId = 1,
                Quantity = 2
            };

            var cart = new Cart
            {
                CartId = 1,
                UserId = 1
            };

            mockRepo.Setup(x => x.AddToCart(dto))
                .ReturnsAsync(cart);

            var service =
                new CartServiceManager(
                    mockRepo.Object);

            var result =
                await service.AddToCart(dto);

            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetCart_Should_Return_Cart()
        {
            var mockRepo = new Mock<ICartRepository>();

            mockRepo.Setup(x => x.GetCartByUserId(1))
                .ReturnsAsync(new Cart());

            var service =
                new CartServiceManager(
                    mockRepo.Object);

            var result =
                await service.GetCartByUserId(1);

            Assert.NotNull(result);
        }

        [Fact]
        public async Task UpdateCart_Should_Return_Item()
        {
            var mockRepo = new Mock<ICartRepository>();

            var dto = new UpdateCartDTO
            {
                CartItemId = 1,
                Quantity = 5
            };

            mockRepo.Setup(x => x.UpdateCartItem(dto))
                .ReturnsAsync(new CartItem());

            var service =
                new CartServiceManager(
                    mockRepo.Object);

            var result =
                await service.UpdateCartItem(dto);

            Assert.NotNull(result);
        }

        [Fact]
        public async Task RemoveCart_Should_Return_True()
        {
            var mockRepo = new Mock<ICartRepository>();

            mockRepo.Setup(x => x.RemoveCartItem(1))
                .ReturnsAsync(true);

            var service =
                new CartServiceManager(
                    mockRepo.Object);

            var result =
                await service.RemoveCartItem(1);

            Assert.True(result);
        }

        [Fact]
        public async Task ClearCart_Should_Return_True()
        {
            var mockRepo = new Mock<ICartRepository>();

            mockRepo.Setup(x => x.ClearCart(1))
                .ReturnsAsync(true);

            var service =
                new CartServiceManager(
                    mockRepo.Object);

            var result =
                await service.ClearCart(1);

            Assert.True(result);
        }
    }
}