
$(document).ready(function () {

  loadOrderSummary();

  $("#checkoutForm").on("submit", function (e) {
    e.preventDefault();

    if (validateForm()) {
      placeOrder();
    }
  });

});


/* -------- Load Order Summary -------- */
function loadOrderSummary() {

  // Get cart data from localStorage
  let cart = JSON.parse(localStorage.getItem("cart"));

  // If cart is null or empty
  if (!cart || cart.length === 0) {
    alert("Your cart is empty!");
    window.location.href = "cart.html";
    return;
  }

  let total = 0;
  let html = "";

  // Loop through each item
  for (let i = 0; i < cart.length; i++) {

    let item = cart[i];

    // Calculate total for each item
    let itemTotal = item.price * item.qty;

    // Add to grand total
    total = total + itemTotal;

    // Create HTML
    html = html + `
      <div class="mb-2">
        <b>${item.name}</b><br>
        Qty: ${item.qty} × ₹ ${item.price} <br>
        Total: ₹ ${itemTotal}
        <hr>
      </div>
    `;
  }

  // Display items
  document.getElementById("orderItems").innerHTML = html;

  // Display total
  document.getElementById("orderTotal").innerText = total;
}

/* -------- Form Validation -------- */
function validateForm() {

  let inputs = $("#checkoutForm input, #checkoutForm textarea");

  let name = inputs.eq(0).val().trim();
  let email = inputs.eq(1).val().trim();
  let phone = inputs.eq(2).val().trim();
  let address = inputs.eq(3).val().trim();
  let city = inputs.eq(4).val().trim();
  let pin = inputs.eq(5).val().trim();

  // Name check
  if (name.length < 3) {
    alert("Please enter a valid name");
    return false;
  }

  // Email check
  if (!email.includes("@") || !email.includes(".")) {
    alert("Enter a valid email");
    return false;
  }

  // Phone check (optional but must be 10 digits if entered)
  if (phone !== "" && phone.length !== 10) {
    alert("Phone number must be 10 digits");
    return false;
  }

  // Address
  if (address.length < 10) {
    alert("Enter full address");
    return false;
  }

  // City
  if (city === "") {
    alert("Enter city");
    return false;
  }

  // PIN code
  if (pin.length !== 6 || isNaN(pin)) {
    alert("Enter valid 6-digit PIN code");
    return false;
  }

  return true;
}


/* -------- Place Order -------- */
function placeOrder() {

  let confirmOrder = confirm("Do you want to place this order?");

  if (!confirmOrder) return;

  // Clear cart
  localStorage.removeItem("cart");

  // Success message
  alert("Order placed successfully!");

  // Redirect
  window.location.href = "index.html";
}