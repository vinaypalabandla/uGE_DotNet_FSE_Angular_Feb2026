import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter } from '@angular/router';
import { routes } from './app.routes';
import { provideHttpClient, withFetch, withInterceptors } from '@angular/common/http';
import { authInterceptor } from './core/interceptors/jwt-interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),

    // ONLY ONE HTTP CLIENT (IMPORTANT)
    provideHttpClient(
      withFetch(),
      withInterceptors([authInterceptor])
    )
  ]
};










// import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
// import { provideRouter, withRouterConfig } from '@angular/router';
// import { routes } from './app.routes';
// import { provideHttpClient, withFetch, withInterceptors } from '@angular/common/http';
// import { authInterceptor } from './core/interceptors/jwt-interceptor';

// export const appConfig: ApplicationConfig = {
//   providers: [
//     provideBrowserGlobalErrorListeners(),
//      provideRouter(routes) ,
//     provideHttpClient(withFetch()),
  

//     // provideRouter(
//     //   routes,
//     //   withRouterConfig({
//     //     onSameUrlNavigation: 'reload'
//     //   })
//     // ),
//     provideHttpClient( 
//       withFetch(),
//        withInterceptors([authInterceptor])),
       
//   ]
// };

