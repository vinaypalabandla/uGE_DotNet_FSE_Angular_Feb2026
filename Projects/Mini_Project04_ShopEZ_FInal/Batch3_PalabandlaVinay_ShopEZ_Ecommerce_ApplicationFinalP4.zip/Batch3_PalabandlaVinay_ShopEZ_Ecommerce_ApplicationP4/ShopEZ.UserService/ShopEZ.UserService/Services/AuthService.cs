﻿using ShopEZ.UserService.DTOs;
using ShopEZ.UserService.Helpers;
using ShopEZ.UserService.Models;
using ShopEZ.UserService.Repositories;

namespace ShopEZ.UserService.Services
{
    // Auth Service Class
    public class AuthService : IAuthService
    {
        // Repository Object
        private readonly IAuthRepository _repository;

        // JWT Helper Object
        private readonly JwtHelper _jwt;

        // Constructor Injection
        public AuthService(IAuthRepository repository,JwtHelper jwt)
        {
            _repository = repository;
            _jwt = jwt;
        }

          //REGISTER USER
        public async Task<string> Register(
            RegisterDTO dto)
        {
            // Check email exists
            var existingUser = await _repository.GetUserByEmail(dto.Email!);

            // If exists
            if (existingUser != null)
            {
                throw new Exception("Email already exists");
            }

            // Create User Object
            var user = new User
            {
                Name = dto.Name,
                Email = dto.Email,
                Password = dto.Password,
                Role = "Customer"
            };
            // Save User
            await _repository.AddUser(user);
            return "User Registered Successfully";
        }
        //LOGIN USER

        public async Task<object> Login(LoginDTO dto)
        {
            // Check User
            var user = await _repository.Login(dto.Email!,dto.Password!
            );

            // Invalid User
            if (user == null)
            {
                throw new Exception("Invalid Credentials");
            }

            // Generate JWT Token
            var token = _jwt.GenerateToken(user);
            // Return User Details
            return new
            {
                userId = user.UserId,
                name = user.Name,
                email = user.Email,
                role = user.Role,
                token = token
            };
        }
    }
}