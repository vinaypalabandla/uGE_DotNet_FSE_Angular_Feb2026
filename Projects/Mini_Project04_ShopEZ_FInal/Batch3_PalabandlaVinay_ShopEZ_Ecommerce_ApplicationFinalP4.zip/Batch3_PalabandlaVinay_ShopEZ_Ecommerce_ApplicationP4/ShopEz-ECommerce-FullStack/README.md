# 🛒 ShopEz — Full-Stack E-Commerce Application

> An Angular 21 + ASP.NET Core full-stack e-commerce application with product browsing, cart management, checkout flow, order placement, and an admin dashboard for product CRUD.

# ShopEZ Ecommerce (Angular)

Modern e-commerce demo app with customer and admin flows, responsive UI, and local fallback support when backend APIs are unavailable.

## Quick Start

1. Install dependencies: `npm install`
2. Start app: `npm start` or `ng s -o`
3. Open: `http://localhost:4200`

## Demo Login Credentials

> [!NOTE]
> Since default users are no longer seeded automatically, please register a new account on the **Sign Up** page. You can use the following credentials as a guide for your first registration:
>here default admin details seeded in database ,customer can register and login , when user trying to register default  user type or customer  not admin,  here admin fixed  

- Admin
  - Useremail: `admin1@gmail.com`
  - Password: `admin123`
  - Role: `Admin`
- Customer
  - Useremail: `user1@gmail.com`
  - Password: `user123`
  - Role: `Customer`

## Implemented Features

- Real-time style UI polish:
  - Improved colorful gradients, typography, and card styling
- Product browsing:
  - Search bar and category filter on products page
  - More products added to catalog mock data
  - Image fallback when external image URLs fail
- Wishlist:
  - Add/remove wishlist from product list and product details
  - Dedicated wishlist page
  - Move items from wishlist to cart
- Cart and checkout:
  - Quantity updates, remove, and clear cart
  - Full checkout form validation
  - Order success confirmation page after placing order
- Authentication:
  - Usernemail + password + role-based login
  - Registration validation and duplicate-user check
  - Local storage fallback if auth API is unavailable (requires manual registration)
- Admin CRUD operations:
  - Product create/update/delete
  - View and delete orders
  - Update order status 
  - View and delete users (except currently logged-in admin)

## Notes

- App supports backend APIs when available (`https://localhost:7121/api/...`).
- If backend is unavailable, key features continue working using local storage fallbacks.

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. Tech Stack
3. Complete Folder Structure
4. File-by-File Description
5. Architecture & Data
6. Models 
7. Services
8. Guards & Interceptors
9. Features / Components
10. Routing
11. Prerequisites
12. Step-by-Step Setup & Run
13. Environment & API Configuration
14. Available Scripts
15. Backend API Endpoints (Expected)
16. Admin Access
17. SSR (Server-Side Rendering)
18. Known Issues & Notes

---

## 1. Project Overview

**ShopEz** is a responsive Angular-based e-commerce storefront that connects to a .NET backend (ASP.NET Core Web API). Users can browse products by category, manage a persistent shopping cart, register/login, and place orders. Admins can log in to access a protected dashboard where they can create, edit, and delete products.

Key features at a glance:

- Product listing with category filter and search
- Persistent cart stored in `localStorage` (survives page reload)
- User authentication with JWT tokens
- Role-based routing: `Customer` vs `Admin`
- Admin dashboard: full product CRUD (Create, Read, Update, Delete)
- Checkout with order placement via REST API
- Server-Side Rendering (SSR) via `@angular/ssr` + Express
- Jasimine and Karama unit tests for services and components

---

## 2. Tech Stack

| Layer | Technology | Version |
|---|---|---|
| Frontend Framework | Angular | 21.2.x |
| Language | TypeScript | ~5.9.2 |
| Styling | Bootstrap | 5.3.8 |
| HTTP Client | Angular HttpClient | built-in |
| Reactive Programming | RxJS | ~7.8.0 |
| SSR Runtime | @angular/ssr + Express | 21.2.7 / 5.1.0 |
| Build Tool | Angular CLI + Karama +Jasimine | 21.2.7 |
| Testing | Karama and Jasimine | 4.0.8 |
| Package Manager | npm | 10.9.3 |
| Backend (separate) | ASP.NET Core Web API | — |

---

## 3. Complete Folder Structure

```
ShopEz-ECommerce-FullStack/
│
├── .angular/                          # Angular build cache (auto-generated, do not edit)
│
├── .vscode/                           # VS Code workspace settings
│   ├── extensions.json                # Recommended extensions
│   ├── launch.json                    # Debug configurations
│   ├── mcp.json                       # MCP (Model Context Protocol) config
│   └── tasks.json                     # Build/serve task shortcuts
│
├── public/
│   └── favicon.ico                    # Browser tab icon
│
├── src/
|   |
│   ├── app/
│   │   ├── core/                      # Singleton services, guards, interceptors
│   │   │   ├── guards/
│   │   │   │   ├── admi-guard.ts      # (legacy/stub) admin guard
│   │   │   │   ├── admin-guard.spec.ts
│   │   │   │   ├── auth-guard.ts      # AdminGuard — protects /admin route
│   │   │   │   └── auth-guard.spec.ts
│   │   │   ├── interceptors/
│   │   │   │   ├── jwt-interceptor.ts      # Attaches Bearer token to all HTTP requests
│   │   │   │   └── jwt-interceptor.spec.ts
│   │   │   └── services/
│   │   │       ├── auth-service.ts         # Login, register, save/get/logout user (JWT)
│   │   │       ├── auth-service.spec.ts
│   │   │       ├── cart.service.ts         # Cart state (BehaviorSubject + localStorage)
│   │   │       ├── cart.service.spec.ts
│   │   │       ├── order.service.ts        # POST order to backend API
│   │   │       └── order.service.spec.ts
│   │   │
│   │   ├── features/                  # Feature modules (one folder per page/feature)
│   │   │   ├── admin/
│   │   │   │   └── admin-dashboard.component/
│   │   │   │       ├── admin-dashboard.component.ts    # Admin CRUD logic
│   │   │   │       ├── admin-dashboard.component.html  # Admin UI table + forms
│   │   │   │       ├── admin-dashboard.component.css
│   │   │   │       └── admin-dashboard.component.spec.ts
│   │   │   │
│   │   │   ├── auth/
│   │   │   │   ├── login/
│   │   │   │   │   ├── login.ts            # Login form + JWT handling + role redirect
│   │   │   │   │   ├── login.html
│   │   │   │   │   ├── login.css
│   │   │   │   │   └── login.spec.ts
│   │   │   │   └── register/
│   │   │   │       ├── register.ts         # Registration form + API call
│   │   │   │       ├── register.html
│   │   │   │       ├── register.css
│   │   │   │       └── register.spec.ts
│   │   │   │
│   │   │   ├── cart/
│   │   │   │   └── cart.component/
│   │   │   │       ├── cart.component.ts   # Cart page: list items, qty, total, checkout
│   │   │   │       ├── cart.component.html
│   │   │   │       ├── cart.component.css
│   │   │   │       └── cart.component.spec.ts
│   │   │   │
│   │   │   ├── home/
│   │   │   │   └── home.component/
│   │   │   │       ├── home.component.ts   # Landing page with hero/banner
│   │   │   │       ├── home.component.html
│   │   │   │       ├── home.component.css
│   │   │   │       └── home.component.spec.ts
│   │   │   │
│   │   │   ├── orders/
│   │   │   │   ├── checkout-component/
│   │   │   │   │   ├── checkout-component.ts    # Checkout form, address, place order
│   │   │   │   │   ├── checkout-component.html
│   │   │   │   │   ├── checkout-component.css
│   │   │   │   │   └── checkout-component.spec.ts
│   │   │   │   └── order.success/
│   │   │   │       ├── order.success.ts         # Order confirmation page
│   │   │   │       ├── order.success.html
│   │   │   │       ├── order.success.css
│   │   │   │       └── order.success.spec.ts
│   │   │   │
│   │   │   └── products/
│   │   │       └── product-list-component/
│   │   │           ├── product-list-component.ts    # Fetch + filter + search products
│   │   │           ├── product-list-component.html
│   │   │           ├── product-list-component.css
│   │   │           └── product-list-component.spec.ts
│   │   │
│   │   ├── models/                    # TypeScript interfaces (data shapes)
│   │   │   ├── product.ts             # Product interface
│   │   │   ├── user.ts                # User interface
│   │   │   ├── order.ts               # Order interface
│   │   │   └── cart.item.ts           # CartItem interface
│   │   │
│   │   ├── services/                  # Feature-level (non-singleton) services
│   │   │   ├── product-service.ts     # GET/POST/PUT/DELETE products via HTTP
│   │   │   └── product-service.spec.ts
│   │   │
│   │   ├── shared/                    # Reusable UI components
│   │   │   └── navbar/
│   │   │       └── navbar.component/
│   │   │           ├── navbar.component.ts    # Nav with cart badge + auth links
│   │   │           ├── navbar.component.html
│   │   │           ├── navbar.component.css
│   │   │           └── navbar.component.spec.ts
│   │   │
│   │   ├── app.ts                     # Root component (AppComponent)
│   │   ├── app.html                   # Root template (<router-outlet>)
│   │   ├── app.css                    # Global app-level styles
│   │   ├── app.config.ts              # App providers (router, HttpClient, interceptors)
│   │   ├── app.config.server.ts       # SSR-specific providers
│   │   ├── app.routes.ts              # All client-side routes
│   │   ├── app.routes.server.ts       # SSR route config
│   │   └── app.spec.ts                # Root component test
│   │
│   ├── assets/
│   │   └── images/                    # All product and banner images (JPG/PNG)
│   │       ├── laptop.jpg
│   │       ├── smartphone.jpg
│   │       ├── headphones.jpg
│   │       └── ... (50+ product images)
│   │__Enviornmen varibles.ts
│   ├── index.html                     # Main HTML shell (Angular injects app here)
│   ├── main.ts                        # Browser bootstrap entry point
│   ├── main.server.ts                 # SSR bootstrap entry point
│   ├── server.ts                      # Express SSR server
│   └── styles.css                     # Global CSS (Bootstrap import + custom variables)
│
├── .editorconfig                      # Editor formatting rules
├── .gitignore                         # Files excluded from git
├── .prettierrc                        # Prettier formatting config
|__ karama.conf.js                     # UnitTesint using karma and Jasimine
├── angular.json                       # Angular workspace config (build, serve, test)
├── package.json                       # Dependencies and npm scripts
├── package-lock.json                  # Locked dependency tree
├── tsconfig.json                      # Root TypeScript config
├── tsconfig.app.json                  # App-specific TS config
└── tsconfig.spec.json                 # Test-specific TS config
```

---

## 4. File-by-File Description

### Root Config Files

| File | Purpose |
|---|---|
| `angular.json` | Angular workspace configuration — defines build, serve, and test targets, output paths, and asset/style includes |
| `package.json` | Lists all npm dependencies, devDependencies, and npm scripts |
| `tsconfig.json` | Base TypeScript compiler options shared across app and tests |
| `tsconfig.app.json` | Extends base tsconfig; targets browser compilation for the app |
| `tsconfig.spec.json` | Extends base tsconfig; targets Vitest test runner |
| `.prettierrc` | Code formatting rules (single quotes, 2-space indent, etc.) |
| `.editorconfig` | Enforces consistent whitespace/line endings across editors |
| `.gitignore` | Excludes `node_modules`, `dist`, `.angular/cache`, etc. |

### src/ Entry Points

| File | Purpose |
|---|---|
| `src/index.html` | HTML shell; Angular inserts `<app-root>` here at build time |
| `src/main.ts` | Browser bootstrap: calls `bootstrapApplication(App, appConfig)` |
| `src/main.server.ts` | SSR bootstrap: used by Express for server-side rendering |
| `src/server.ts` | Express server that handles SSR rendering requests in production |
| `src/styles.css` | Global stylesheet: imports Bootstrap, sets CSS variables for theme colours |

---

## 5. Architecture & Data Flow

```
User Browser
     │
     ▼
Angular Router (app.routes.ts)
     │
     ├──▶ HomeComponent       (/)
     ├──▶ ProductListComponent (/products)
     ├──▶ CartComponent        (/cart)
     ├──▶ CheckoutComponent    (/checkout)   <-- lazy loaded
     ├──▶ OrderSuccess         (/order-success) <--lazy loaded
     ├──▶ Login                (/login)
     ├──▶ Register             (/register)
     └──▶ AdminDashboard       (/admin)      <-- AdminGuard protected
          │
          ▼
     Services (Angular DI)
          │
          ├── AuthService     → POST /api/Auth/login, /api/Auth/register
          ├── ProductService  → GET/POST/PUT/DELETE /api/Products
          ├── CartService     → localStorage (no server call)
          └── OrderService    → POST /api/orders
          │
          ▼
     JWT Interceptor (authInterceptor)
     Reads token from localStorage → adds "Authorization: Bearer <token>"
     to every outgoing HTTP request automatically
          │
          ▼
     ASP.NET Core Web API (https://localhost:7121)
          │
          ├── /api/Auth
          ├── /api/Products
          └── /api/orders
```

---

## 6. Models (TypeScript Interfaces)

Located in `src/app/models/`

### `product.ts`
```typescript
export interface Product {
  productId?: number;   // optional (not set on create)
  name: string;
  description: string;
  price: number;
  imageUrl: string;     // path to image in assets/images/ or URL
  stock: number;
  category: string;
}
```

### `user.ts`
```typescript
export interface User {
  userId: number;
  name: string;
  email: string;
  password: string;
  role: string;         // 'Admin' or 'Customer'
}
```

### `order.ts`
```typescript
export interface Order {
  orderId: number;
  userId: number;
  orderDate: string;
  totalAmount: number;
}
```

### `cart.item.ts`
```typescript
export interface CartItem {
  productId: number;
  name: string;
  price: number;
  imageUrl: string;
  quantity: number;
}
```

---

## 7. Services

### `AuthService` — `src/app/core/services/auth-service.ts`

Handles all authentication logic.

| Method | Description |
|---|---|
| `login(data)` | POST to `/api/Auth/login` with `{ email, password }` |
| `register(data)` | POST to `/api/Auth/register` with user registration data |
| `saveUser(user)` | Saves user object and JWT token to `localStorage`, emits to `user$` stream |
| `getUser()` | Reads and parses user from `localStorage` (returns `null` on SSR) |
| `logout()` | Removes user and token from `localStorage`, emits `null` to `user$` |
| `user$` | `Observable<any>` — subscribe to react to login/logout events |

---

### `CartService` — `src/app/core/services/cart.service.ts`

Manages cart state entirely client-side using `localStorage`.

| Method | Description |
|---|---|
| `addToCart(product)` | Adds product to cart; increments quantity if already present |
| `increaseQty(id)` | Increases quantity of a specific cart item |
| `decreaseQty(id)` | Decreases quantity (minimum 1) |
| `removeItem(id)` | Removes item from cart by `productId` |
| `clearCart()` | Empties the entire cart |
| `getTotal()` | Returns sum of `price × quantity` for all items |
| `getCart()` | Returns raw array of cart items |
| `cart$` | `Observable<CartItem[]>` — subscribe for reactive cart updates |

Cart is **persisted** in `localStorage` under the key `'cart'` and reloaded on service construction.

---

### `ProductService` — `src/app/services/product-service.ts`

Talks to the backend Products API.

| Method | Description |
|---|---|
| `getAll()` | GET `/api/Products` — returns `Observable<Product[]>` |
| `getById(id)` | GET `/api/Products/{id}` — returns `Observable<Product>` |
| `add(product)` | POST `/api/Products` — creates a new product |
| `update(product)` | PUT `/api/Products/{id}` — updates existing product |
| `delete(id)` | DELETE `/api/Products/{id}` — removes a product |

---

### `OrderService` — `src/app/core/services/order.service.ts`

| Method | Description |
|---|---|
| `placeOrder(order)` | POST `/api/orders` — places a new order |

---

## 8. Guards & Interceptors

### `AdminGuard` — `src/app/core/guards/auth-guard.ts`

Implements `CanActivate`. Reads user from `AuthService.getUser()` and checks `user.role === 'Admin'`. If not admin, redirects to `/`. Applied to the `/admin` route.

### `authInterceptor` — `src/app/core/interceptors/jwt-interceptor.ts`

A functional HTTP interceptor (`HttpInterceptorFn`). On every outgoing HTTP request it:

1. Reads the user object from `localStorage`
2. Extracts the `token` field
3. Clones the request with an `Authorization: Bearer <token>` header
4. Passes the cloned request to `next()`

Registered globally in `app.config.ts` via `withInterceptors([authInterceptor])`.

---

## 9. Features / Components

### `HomeComponent` — `/`
Landing page with hero banner, featured categories, and promotional sections. Uses images from `src/assets/images/`.

### `ProductListComponent` — `/products`
Fetches all products from the API on init. Provides category filter and search. Each product card has an "Add to Cart" button that calls `CartService.addToCart()`.

### `CartComponent` — `/cart`
Displays all items in the cart from `CartService.cart$`. Allows quantity increase/decrease, item removal, and shows running total. Has a "Proceed to Checkout" button.

### `CheckoutComponent` — `/checkout` _(lazy loaded)_
Collects shipping details and payment info. On submit, builds an order payload and calls `OrderService.placeOrder()`. On success, navigates to `/order-success`.

### `OrderSuccess` — `/order-success` _(lazy loaded)_
Simple confirmation page shown after a successful order placement.

### `Login` — `/login`
Email + password form. On successful API response, saves user data via `AuthService.saveUser()`. Redirects Admin to `/admin`, regular users to `/`.

> **Note:** Role is currently determined client-side: if `email === 'admin1@gmail.com'` the role is set to `'Admin'`. This should be replaced with a server-provided role in production.

### `Register` — `/register`
Registration form. POSTs to `/api/Auth/register`. On success, redirects to `/login`.

### `AdminDashboardComponent` — `/admin` _(AdminGuard protected)_
Full product management interface:
- View all products in a table
- Add new product via form
- Edit existing product (inline form populated on click)
- Delete product with confirmation
- Shows transient success/error messages (auto-clears after 1.5s)

### `NavbarComponent` — shared
Appears on every page. Shows navigation links, cart item count badge , and login/logout controls .

---

## 10. Routing

Defined in `src/app/app.routes.ts`:

| Path | Component | Guard | Loading |
|---|---|---|---|
| `/` | `HomeComponent` | None | Eager |
| `/products` | `ProductListComponent` | None | Eager |
| `/cart` | `CartComponent` | None | Eager |
| `/login` | `Login` | None | Eager |
| `/register` | `Register` | None | Eager |
| `/admin` | `AdminDashboardComponent` | `AdminGuard` | Eager |
| `/checkout` | `CheckoutComponent` | None | **Lazy** |
| `/order-success` | `OrderSuccess` | None | **Lazy** |
| `**` | redirect → `/` | — | — |

---

## 11. Prerequisites

Make sure the following are installed before you begin:

| Tool | Minimum Version | Check Command |
|---|---|---|
| Node.js | 20.x or higher | `node -v` |
| npm | 10.x or higher | `npm -v` |
| Angular CLI | 21.x | `ng version` |
| .NET SDK | 8.0 or higher | `dotnet --version` |
| Git | any | `git --version` |

To install Angular CLI globally (if not already installed):
```bash
npm install -g @angular/cli@21
```

---

## 12. Step-by-Step Setup & Run

### Step 1 — Clone or Extract the Project

If cloning from Git:
```bash
git clone <your-repository-url>
cd ShopEz-ECommerce-FullStack
```

If extracting from the ZIP:
```bash
unzip ShopEz-ECommerce-FullStack.zip
cd ShopEz-ECommerce-FullStack
```

---

### Step 2 — Install Node Dependencies

```bash
npm install
```

This installs all packages listed in `package.json` into `node_modules/`. This may take a few minutes on first run.

---

### Step 3 — Set Up and Run the Backend API

The Angular frontend expects a running ASP.NET Core Web API at `https://localhost:7121`.

Navigate to your backend project folder and run:
```bash
dotnet run
```

Confirm the API is running by visiting:
```
https://localhost:7121/api/Products
```

You should see a JSON array of products (or an empty array `[]` if the database is empty).

> **Note:** If you see a certificate error in the browser, run `dotnet dev-certs https --trust` once to trust the development certificate.

---

### Step 4 — Start the Angular Development Server

```bash
npm start
```

or equivalently:
```bash
ng serve -o
```

The app will be available at:
```
http://localhost:4200
```

The development server watches for file changes and reloads automatically.

---

### Step 5 — Open the App

Open your browser and navigate to `http://localhost:4200`.

- **Home page** loads immediately (no login required)
- **Products** page fetches products from the backend API
- **Cart** works immediately (localStorage-based, no login required)
- **Checkout** requires being logged in (navigates to login if not authenticated — backend will reject unauthenticated orders)
- **Admin Dashboard** at `/admin` requires logging in as `admin1@gmail.com`

---

### Step 6 — Register a User (Optional)

1. Click **Register** in the navbar
2. Fill in the form (name, email, password)
3. Submit — you will be redirected to `/login`
4. Log in with your new credentials

---

### Step 7 — Access Admin Dashboard

1. Log in with email: `admin1@gmail.com` and the admin password set in your backend
2. You will be automatically redirected to `/admin`
3. From here you can add, edit, or delete products

---

## 13. Environment & API Configuration

The API base URL is currently hardcoded in the service files. To change the backend URL, update these three files:

**`src/app/core/services/auth-service.ts`**
```typescript
private apiUrl = 'https://localhost:7121/api/Auth';
```

**`src/app/services/product-service.ts`**
```typescript
private apiUrl = 'https://localhost:7121/api/Products';
```

**`src/app/core/services/order.service.ts`**
```typescript
private api = 'https://localhost:7121/api/orders';
```

For a production deployment, replace `https://localhost:7121` with your live backend URL in all three files, or better yet, move these to Angular environment files (`src/environments/environment.ts` and `src/environments/environment.prod.ts`).

---

## 14. Available Scripts

All scripts are run from the project root with `npm run <script>`:

| Script | Command | Description |
|---|---|---|
| `start` | `ng serve` | Start dev server on `http://localhost:4200` |
| `build` | `ng build` | Production build (output to `dist/`) |
| `watch` | `ng build --watch --configuration development` | Rebuild on file change (dev mode) |
| `test` | `ng test` | Run unit tests with Karama browser |
| `serve:ssr:ShopEz-ECommerce-FullStack` | `node dist/.../server.mjs` | Serve SSR production build |

---

## 15. Backend API Endpoints (Expected)

The frontend calls these endpoints on `https://localhost:7121`:

| Method | Endpoint | Auth Required | Description |
|---|---|---|---|
| POST | `/api/Auth/register` | No | Register a new user |
| POST | `/api/Auth/login` | No | Login, returns JWT token |
| GET | `/api/Products` | No | Get all products |
| GET | `/api/Products/{id}` | No | Get product by ID |
| POST | `/api/Products` | Yes (Admin) | Add a new product |
| PUT | `/api/Products/{id}` | Yes (Admin) | Update a product |
| DELETE | `/api/Products/{id}` | Yes (Admin) | Delete a product |
| POST | `/api/orders` | Yes | Place a new order |

---

## 16. Admin Access

Admin access is determined in two places:

1. **`Login` component** (`src/app/features/auth/login/login.ts`): If the logged-in email is `admin1@gmail.com`, the role is set to `'Admin'` in the stored user object.

2. **`AdminGuard`** (`src/app/core/guards/auth-guard.ts`): Checks `user.role === 'Admin'` before allowing access to `/admin`.

To add more admin emails, update the login component:
```typescript
role: ['admin1@gmail.com', 'admin2@gmail.com'].includes(this.email) ? 'Admin' : 'Customer'
```

> For production, the role should come from the JWT claims returned by the backend, not be assigned client-side.

---

## 17. SSR (Server-Side Rendering)

This project supports Angular Universal SSR via `@angular/ssr`.

To build and serve the SSR version:

```bash
# Build SSR bundle
npm run build

# Serve the SSR server
npm run serve:ssr:ShopEz-ECommerce-FullStack
```

The SSR server (`src/server.ts`) is an Express app that pre-renders Angular pages on the server for better SEO and initial load performance.

SSR-specific considerations in the code:

- `CartService` uses `isPlatformBrowser(platformId)` to skip `localStorage` access on the server
- `AuthService.getUser()` checks `typeof window === 'undefined'` before accessing `localStorage`
- `app.config.server.ts` provides SSR-specific Angular providers

---

## 18. Known Issues & Notes

- **Role assignment is client-side:** The admin role is assigned based on a hardcoded email in the login component. In production, this must come from the server's JWT payload.

- **`admi-guard.ts` typo:** There is a file named `admi-guard.ts` (missing the 'n'). The active guard used in routing is `auth-guard.ts` which exports `AdminGuard`.

- **`product-service.ts` has a stub method:** The `getProducts()` method in `ProductService` throws `new Error('Method not implemented.')`. Use `getAll()` instead — it is the fully implemented version.

- **HTTPS certificate for localhost:** The backend runs on `https://localhost:7121`. On first setup you may need to trust the .NET development certificate: `dotnet dev-certs https --trust`.

- **CORS:** The ASP.NET Core backend must be configured to allow CORS from `http://localhost:4200` for development. Ensure your backend `Program.cs` includes the appropriate CORS policy.

- **Images:** Product images are served as static assets from `src/assets/images/`. The `imageUrl` field in the database should match the filenames in this folder (e.g., `assets/images/laptop.jpg`).
===================================================================================================================================================
                                             #          DATABASE
====================================================================================================================================================

1. SQL INSERT QUERIES

Use this after creating your tables.
=========================
🔹 Users Table
INSERT INTO Users (UserId, Name, Email, Password, Role) VALUES
(1, 'Admin1', 'admin1@gmail.com', 'admin123', 'Admin'),
(2, 'User1', 'user1@gmail.com', 'user123', 'Customer'),
(3, 'User2', 'user2@gmail.com', 'user123', 'Customer');
==========================
🔹 Products Table
INSERT INTO Products (ProductId, Name, Description, Price, ImageUrl, Stock, Category) VALUES
(47, 'Dell Mouse', 'Dell Mouse scroll button', 650.00, '/assets/images/mouse.jpg', 30, 'Appliances'),
(48, 'Dell Pendrive', 'Pendrive 256GB', 650.00, '/assets/images/pendrive.jpg', 30, 'Appliances'),
(49, 'Power Bank', 'powerbank 10000mah', 500.00, '/assets/images/powerbank.jpg', 30, 'Appliances'),
(50, 'Star Link Router', 'StarLink Router', 1201.00, '/assets/images/router.jpg', 20, 'Appliances'),
(51, 'LENOVO Smartbulb', 'Lenovo Build with Charging', 452.00, '/assets/images/smartbulb.jpg', 20, 'Appliances'),
(52, 'Samsung SmartWatch', 'Samsung Smartwatch AI features', 1500.00, '/assets/images/smartwatch.jpg', 20, 'Watches'),
(53, 'Samsung VR', 'Samsung VR Gen AI features', 15001.00, '/assets/images/vr.jpg', 20, 'Appliances'),
(54, 'Logitech 4kWebcam', 'Logitech web camera', 1500.00, '/assets/images/webcam.jpg', 20, 'Camera');
===========================
🔹 Orders Table
INSERT INTO Orders (OrderId, UserId, OrderDate, TotalAmount) VALUES
(5, 1, '2026-05-05 01:52:23.880', 95990.00);
===========================
🔹 OrderItems Table
INSERT INTO OrderItems (OrderItemId, OrderId, ProductId, Quantity, Price) VALUES
(2, 5, 2, 1, 95990.00);
=================================================================================
2. SELECT QUERIES 
USE ShopEZDb;

SELECT * FROM OrderItems;
SELECT * FROM Orders;
SELECT * FROM Products;
SELECT * FROM Users;
================================================================================
🛒 ShopEZ Database
ShopEZ is an e-commerce database designed to manage users, products, orders, and order items efficiently.

`Database Name`
ShopEZDb

Tables
1. Users

Stores user details.

UserId (PK)
Name
Email
Password
Role (Admin / Customer)
2. Products

Stores product information.

ProductId (PK)
Name
Description
Price
ImageUrl
Stock
Category
3. Orders

Stores order details.

OrderId (PK)
UserId (FK)
OrderDate
TotalAmount
4. OrderItems

Stores items in each order.

OrderItemId (PK)
OrderId (FK)
ProductId (FK)
Quantity
Price
`Relationships`
One User ➝ Many Orders
One Order ➝ Many OrderItems
One Product ➝ Many OrderItems
` Features`
User management (Admin & Customer)
Product catalog
Order tracking
Inventory management
##`How to Run`
USE ShopEZDb;

SELECT * FROM Users;
SELECT * FROM Products;
SELECT * FROM Orders;
SELECT * FROM OrderItems;

>Author
Vinay Kumar
(> .Net Full Stack Developer)