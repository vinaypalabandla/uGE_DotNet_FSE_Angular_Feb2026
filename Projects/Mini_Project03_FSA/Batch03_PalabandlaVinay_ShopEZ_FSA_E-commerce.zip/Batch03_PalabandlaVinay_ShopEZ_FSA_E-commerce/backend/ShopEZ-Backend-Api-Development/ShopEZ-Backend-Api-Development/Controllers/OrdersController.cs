﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShopEZ_Backend_Api_Development.DTOs;
using ShopEZ_Backend_Api_Development.Services;

namespace ShopEZ_Backend_Api_Development.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderService _service;

        // Constructor Injection
        public OrdersController(IOrderService service)
        {
            _service = service;
        }

        // Get All Orders
        
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var orders = await _service.GetAllAsync();

            return Ok(orders);
        }

        // Get Order ByID
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var order = await _service.GetByIdAsync(id);

            if (order == null)
            {
                return NotFound("Order not found");
            }

            return Ok(order);
        }

       //Create Order
        [HttpPost]
        public async Task<IActionResult> Create(OrderDTO dto)
        {
            //null check 
            if (dto == null)
            {
                return BadRequest("Order data is required");
            }

            // Model validation check
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Call service
           // await _service.CreateOrderAsync(dto);

            // Clear response
            //return Ok("Order Created Successfully
            //acording t=to frontend i update order placed succes message pop
            var order = await _service.CreateOrderAsync(dto);

            return Ok(new
            {
                message = "Order Created Successfully",
                orderId = order.OrderId   
            });
        }
    }
}