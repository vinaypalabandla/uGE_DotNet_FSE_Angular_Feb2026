﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ShopEZ_Backend_Api_Development.Models
{
    //One order -->Many order items
    public class Order
    {
        [Key]
        public int OrderId { get; set; }

        [Required]
        public int UserId { get; set; } // FK
        
        public User User { get; set; }
        public DateTime OrderDate { get; set; } = DateTime.Now;

        [Range(0, 1000000)]
        public decimal TotalAmount { get; set; }

        //Navigation 1 Order => Many OrderItems
        //null refernce so empty list crceated  
        public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
    }

}
