﻿using Microsoft.EntityFrameworkCore;
using ShopEZ.ProductService.Models;

namespace ShopEZ.ProductService.Data
{
    public class ProductDbContext : DbContext
    {
        public ProductDbContext( DbContextOptions<ProductDbContext> options)
            : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
    }
}