import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ProductListComponent } from './product-list-component';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { ProductService } from '../../../services/product-service';
import { CartService } from '../../../core/services/cart.service';
import { PLATFORM_ID } from '@angular/core';

describe('ProductListComponent', () => {
  let component: ProductListComponent;
  let fixture: ComponentFixture<ProductListComponent>;
  let productServiceSpy: any;
  let cartServiceSpy: any;

  beforeEach(async () => {
    productServiceSpy = jasmine.createSpyObj('ProductService', ['getAll']);
    cartServiceSpy = jasmine.createSpyObj('CartService', ['addToCart']);

    productServiceSpy.getAll.and.returnValue(of([]));

    await TestBed.configureTestingModule({
      imports: [ProductListComponent],
      providers: [
        provideRouter([]),
        { provide: ProductService, useValue: productServiceSpy },
        { provide: CartService, useValue: cartServiceSpy },
        { provide: PLATFORM_ID, useValue: 'browser' }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(ProductListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});