﻿using System.ComponentModel.DataAnnotations;

namespace ShopEZ_Backend_Api_Development.DTOs
{
    public class OrderItemDTO
    {
        [Required]
        public int ProductId { get; set; }

        [Required]
        [Range(1, 100)]
        public int Quantity { get; set; }
    }
}
