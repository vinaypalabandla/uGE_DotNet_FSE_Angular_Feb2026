﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using ShopEZ.CartService.DTOs;
using ShopEZ.CartService.Services;

namespace ShopEZ.CartService.Controllers
{
    // API Controller
    [ApiController]

    // Route
    [Route("api/[controller]")]
   [Authorize]
    public class CartController: ControllerBase
    {
        // Service Object
        private readonly ICartService  _service;

        // Constructor
        public CartController( ICartService service)
        {
            _service = service;
        }
       //ADD TO CART 
        [HttpPost]
        public async Task<IActionResult> AddToCart(AddCartDTO dto)
        {
            var cart =  await _service .AddToCart(dto);
            return Ok(cart);
        }
        //GET USER CART
        [HttpGet("{userId}")]
        public async Task<IActionResult> GetCartByUserId(int userId)
        {
            var cart =  await _service.GetCartByUserId(userId);

            return Ok(cart);
        }
        //UPDATE CART ITEM
        [HttpPut]
        public async Task<IActionResult>  UpdateCartItem(UpdateCartDTO dto)
        {
            var cartItem = await _service.UpdateCartItem(dto);

            return Ok(cartItem);
        }
        //REMOVE CART ITEM
        [HttpDelete("{cartItemId}")]
        public async Task<IActionResult> RemoveCartItem(int cartItemId)
        {
            var result = await _service.RemoveCartItem(cartItemId);
            return Ok(result);
        }
        //CLEAR CART
        [HttpDelete("clear/{userId}")]
        public async Task<IActionResult> ClearCart(int userId)
        {
            var result =  await _service.ClearCart(userId);

            return Ok(result);
        }
    }
}