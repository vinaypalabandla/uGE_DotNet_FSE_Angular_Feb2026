﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ShopEZ.OrderService.Models
{
    // Order Item Model
    public class OrderItem
    {
        // Primary Key
        [Key]
        public int OrderItemId { get; set; }

        // Product Id
        public int ProductId { get; set; }

        // Quantity
        public int Quantity { get; set; }

        // Price
        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }

        // Foreign Key
        public int OrderId { get; set; }

        // Navigation Property
        [ForeignKey("OrderId")]
        [JsonIgnore]
        public Order Order { get; set; } = null!;
    }
}
