﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShopEZ_Backend_Api_Development.DTOs;
using ShopEZ_Backend_Api_Development.Services;

namespace ShopEZ_Backend_Api_Development.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService _service;

        // Constructor
        public ProductsController(IProductService service)
        {
            _service = service;
        }
     //GetAllProduct by id
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var products = await _service.GetAllAsync();

            return Ok(products);
        }

     //Get product by ID
        [HttpGet("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Get(int id)
        {
            var product = await _service.GetByIdAsync(id);

            if (product == null)
            {
                return NotFound("Product not found");
            }

            return Ok(product);
        }
         //Create product
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create(ProductDTO dto)
        {
            if (dto == null)
            {
                return BadRequest("Product data is required");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            await _service.AddAsync(dto);

            return Ok("Product Created Successfully");
        }

        //Update product Admin only
        [Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, ProductDTO dto)
        {
            if (dto == null)
            {
                return BadRequest("Product data is required");
            }

            await _service.UpdateAsync(id, dto);

            return Ok("Product Updated Successfully");
        }
        //Delete product Admin only
    
        [Authorize(Roles = "Admin")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _service.DeleteAsync(id);

            return Ok("Product Deleted Successfully");
        }
    }
}