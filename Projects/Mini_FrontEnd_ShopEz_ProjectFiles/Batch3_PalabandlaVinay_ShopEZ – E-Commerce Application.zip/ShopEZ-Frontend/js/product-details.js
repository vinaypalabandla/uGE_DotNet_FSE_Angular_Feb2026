$(function () {

  // Get product id from URL
  let params = new URLSearchParams(window.location.search);
  let id = params.get("id");

  // If no id =>go back
  if (!id) {
    location.href = "products.html";
    return;
  }

  // Load products.json
  $.getJSON("data/products.json", function (products) {

    let product = null;

    // Find product using simple loop
    for (let i = 0; i < products.length; i++) {
      if (products[i].id == id) {
        product = products[i];
        break;
      }
    }

    // If not found
    if (!product) {
      location.href = "products.html";
      return;
    }

    // Show data on page
    $("#productImage").attr("src", product.image);
    $("#productName").text(product.name);
    $("#productCategory").text(product.category);
    $("#productDescription").text(product.description);
    $("#productPrice").text("₹ " + product.price);

    // Add to cart button
    $("#addCartBtn").click(function () {

      let qty = $("#detailQty").val(); // get quantity
      product.qty = parseInt(qty);

      addToCart(product);

    });

  });

});