import { CommonModule } from '@angular/common';
import { Component, NgZone, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { ProductService } from '../../../services/product-service';
import { map, Observable } from 'rxjs';
import { CartService } from '../../../core/services/cart.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],

})
export class HomeComponent implements OnInit {


  products$!: Observable<any[]>;

  constructor(private productService: ProductService, private router: Router, private cartService: CartService) { }

  ngOnInit() {
    this.products$ = this.productService.getAll().pipe(
      map((data: any[]) => data.slice(0, 9)) //this like products scroll on home page
    );
  }

  goToProducts() {
    this.router.navigate(['/products']);
  }

  trackById(index: number, item: any) {
    return item.productId;
  }

  addToCart(product: any) {
    this.cartService.add(product);
    this.router.navigate(['/cart']);
  }
}