﻿using Moq;
using ShopEZ.UserService.Controllers;
using Microsoft.AspNetCore.Mvc;
using ShopEZ.UserService.DTOs;
using ShopEZ.UserService.Services;
using Xunit;

namespace ShopEZ.UserService.Tests.Controllers
{
    public class AuthControllerTests
    {
        private readonly Mock<IAuthService> _mockService;
        private readonly AuthController _controller;

        public AuthControllerTests()
        {
            _mockService = new Mock<IAuthService>();
            _controller = new AuthController(_mockService.Object);
        }

        [Fact]
        public async Task Register_ReturnsOk()
        {
            // Arrange
            var dto = new RegisterDTO();

            _mockService
                .Setup(x => x.Register(dto))
                .ReturnsAsync("User Registered");

            // Act
            var result = await _controller.Register(dto);

            // Assert
            Assert.IsType<OkObjectResult>(result);
        }

        [Fact]
        public async Task Login_ReturnsOk()
        {
            // Arrange
            var dto = new LoginDTO();

            _mockService
                .Setup(x => x.Login(dto))
                .ReturnsAsync((object)"abc");

            // Act
            var result = await _controller.Login(dto);

            // Assert
            Assert.IsType<OkObjectResult>(result);
        }

        [Fact]
        public async Task Register_ReturnsBadRequest()
        {
            // Arrange
            var dto = new RegisterDTO();
            _mockService
                .Setup(x => x.Register(dto))
                .ThrowsAsync(new Exception("Error"));

            // Act
            var result = await _controller.Register(dto);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }
    }
}