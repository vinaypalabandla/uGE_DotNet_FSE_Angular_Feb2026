﻿using System.ComponentModel.DataAnnotations;

namespace ShopEZ.UserService.DTOs
{
    public class LoginDTO
    {

           // Email field
            [Required]
            [EmailAddress]
            public string? Email { get; set; }

            // Password field
            [Required]
            public string? Password { get; set; }
        }
     
}
