import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../../services/product-service';
import { CartService } from '../../../core/services/cart.service';
import { Router, RouterModule } from '@angular/router';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Observable, map } from 'rxjs';
import { Product } from '../../../models/product';
import { Inject, PLATFORM_ID } from '@angular/core';

@Component({
  selector: 'app-product-list-component',
  standalone: true,
  imports: [RouterModule, CommonModule, FormsModule],
  templateUrl: './product-list-component.html',
  styleUrls: ['./product-list-component.css']
})
export class ProductListComponent implements OnInit {

  products$!: Observable<Product[]>;

  searchText: string = '';

  // category filter
  selectedCategory: string = 'all';

  // add alll categories in array type
  categories: string[] = [
    'all',
    'ac',
    'laptops',
    'tabs',
    'mobiles',
    'coolers',
    'fans',
    'watches',
    'gas',
    'induction',
    'washing machine',
    'appliances',
    'chair',
    'drives',
    'headphones'
  ];

  // PAGINATION
  currentPage: number = 1;

  itemsPerPage: number = 8;

  private isBrowser: boolean;

  constructor(
    private productService: ProductService,
    private cartService: CartService,
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    this.isBrowser = isPlatformBrowser(this.platformId);
  }

  ngOnInit() {
    this.loadProducts();
  }

  // LOAD + SEARCH + CATEGORY FILTER
  loadProducts() {

    this.products$ = this.productService.getAll().pipe(

      map((products: Product[]) => {

        // category filter
        if (this.selectedCategory !== 'all') {

          products = products.filter(p =>
            p.category?.toLowerCase() ===
            this.selectedCategory.toLowerCase()
          );
        }

        // search filter
        if (!this.searchText ||
          this.searchText.trim() === '') {

          this.currentPage = 1;

          return products;
        }

        this.currentPage = 1;

        return products.filter(p =>
          p.name?.toLowerCase().includes(
            this.searchText.toLowerCase()
          )
        );
      })
    );
  }

  // SEARCH
  applyFilter() {
    this.loadProducts();
  }

  // CATEGORY DROPDOWN CHANGE
  onCategoryChange() {
    this.loadProducts();
  }

  // NEXT PAGE
  nextPage(totalItems: number) {

    const totalPages =
      Math.ceil(totalItems / this.itemsPerPage);

    if (this.currentPage < totalPages) {
      this.currentPage++;
    }
  }

  // PREVIOUS PAGE
  previousPage() {

    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  // CHANGE PAGE
  changePage(page: number) {
    this.currentPage = page;
  }

  // TOTAL PAGES ARRAY
  getPages(totalItems: number): number[] {

    const totalPages =
      Math.ceil(totalItems / this.itemsPerPage);

    return Array(totalPages)
      .fill(0)
      .map((x, i) => i + 1);
  }

  // ADD TO CART
  addToCart(product: Product) {

    console.log('CLICKED', product);

    const isLoggedIn =
      localStorage.getItem('user');

    if (!isLoggedIn) {

      this.router.navigate(['/login']);

      return;
    }

    this.cartService.addToCart(product);
  }

  // TRACK BY
  trackById(index: number, item: Product) {
    return item.productId;
  }
}