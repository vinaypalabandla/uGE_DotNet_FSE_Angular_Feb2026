﻿using System.Net;

namespace ShopEZ.UserService.Middlewares
{
    // Custom Exception Middleware
    public class ExceptionMiddleware
    {
        // Request Delegate
        private readonly RequestDelegate _next;

        // Constructor
        public ExceptionMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        // Middleware Method
        public async Task InvokeAsync( HttpContext context)
        {
            try
            {
                // Move to next middleware
                await _next(context);
            }
            catch (Exception ex)
            {
                // Handle Exception
                await HandleExceptionAsync( context, ex);
            }
        }

        // Exception Handling Method
        private static Task HandleExceptionAsync( HttpContext context, Exception exception)
        {
            // Response Content Type
            context.Response.ContentType =  "application/json";

            // Status Code
            context.Response.StatusCode =  (int)HttpStatusCode.InternalServerError;

            // Error Message
            var result = new
            {
                StatusCode = context.Response.StatusCode,
                Message = "Something went wrong.",
                Detailed = exception.Message
            };

            // Return JSON Response
            return context.Response.WriteAsJsonAsync(result);
        }
    }
}