import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { isPlatformBrowser } from '@angular/common';
import { Product } from '../../models/product';

@Injectable({
  providedIn: 'root'
})
export class CartService {


  private cartItems: any[] = [];

  // Reactive (new system)
  private cartSubject = new BehaviorSubject<any[]>([]);
  cart$ = this.cartSubject.asObservable();

  private isBrowser: boolean;

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {

    this.isBrowser = isPlatformBrowser(this.platformId);

    //  load from localStorage
    if (this.isBrowser) {
      const stored = localStorage.getItem(this.getCartKey());
      this.cartItems = stored ? JSON.parse(stored) : [];
    }

    this.cartSubject.next(this.cartItems);
  }

  //  get user-based cart key
  private getCartKey(): string {
    if (!this.isBrowser) return 'cart_guest';

    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return user?.email ? `cart_${user.email}` : 'cart_guest';
  }

  // reload cart when user changes
  loadUserCart() {
    if (this.isBrowser) {
      const stored = localStorage.getItem(this.getCartKey());
      this.cartItems = stored ? JSON.parse(stored) : [];
      this.cartSubject.next(this.cartItems);
    }
  }

  // USED IN PRODUCT PAGE)
  addToCart(product: Product) {

    const existing = this.cartItems.find(
      item => item.productId === product.productId
    );

    if (existing) {
      existing.quantity++;
    } else {
      this.cartItems.push({
        productId: product.productId,
        name: product.name,
        price: product.price,
        imageUrl: product.imageUrl,
        quantity: 1
      });
    }

    this.updateCart();
  }

  //METHODS
  add(item: any) {
    this.cartItems.push(item);
    this.updateCart();
  }

  getCart() {
    return this.cartItems;
  }

  remove(index: number) {
    this.cartItems.splice(index, 1);
    this.updateCart();
  }

  clear() {
    this.cartItems = [];
    this.updateCart();
  }

  //CART  FEATURES

  increaseQty(id: number) {
    const item = this.cartItems.find(i => i.productId === id);
    if (item) item.quantity++;
    this.updateCart();
  }

  decreaseQty(id: number) {
    const item = this.cartItems.find(i => i.productId === id);
    if (item && item.quantity > 1) item.quantity--;
    this.updateCart();
  }

  removeItem(id: number) {
    this.cartItems = this.cartItems.filter(i => i.productId !== id);
    this.updateCart();
  }

  clearCart() {
    this.cartItems = [];
    this.updateCart();
  }

  getTotal(): number {
    return this.cartItems.reduce(
      (sum, item) => sum + item.price * item.quantity,
      0
    );
  }

  //UPDATE MTHOD

  private updateCart() {

    if (this.isBrowser) {
      localStorage.setItem(this.getCartKey(), JSON.stringify(this.cartItems));
    }

    this.cartSubject.next(this.cartItems);
  }
}