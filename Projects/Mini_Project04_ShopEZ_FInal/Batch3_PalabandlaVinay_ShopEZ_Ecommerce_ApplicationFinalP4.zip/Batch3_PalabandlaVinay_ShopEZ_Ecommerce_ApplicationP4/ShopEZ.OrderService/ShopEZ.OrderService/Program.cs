using Microsoft.AspNetCore.Authentication.JwtBearer;

using Microsoft.EntityFrameworkCore;

using Microsoft.IdentityModel.Tokens;

using ShopEZ.OrderService.Data;
using ShopEZ.OrderService.Middlewares;
using ShopEZ.OrderService.Repositories;
using ShopEZ.OrderService.Services;
using System.Text;
using System.Text.Json.Serialization;

namespace ShopEZ.OrderService
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            //ADD Controllers //inifte loop remove using json circular error
            builder.Services.AddControllers() 
             .AddJsonOptions(options =>
              {
                  options.JsonSerializerOptions
                      .ReferenceHandler =
                          System.Text.Json.Serialization
                          .ReferenceHandler.IgnoreCycles;
              });
            // Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
            builder.Services.AddOpenApi();

            // Swagger
            builder.Services.AddEndpointsApiExplorer();

            builder.Services.AddSwaggerGen();
            // SQL Server Connection
            builder.Services.AddDbContext<ApplicationDbContext>(options =>
                {
                    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"));

                });

            // Dependency Injection

            builder.Services.AddScoped<IOrderRepository, OrderRepository>();

            builder.Services.AddScoped<IOrderService, OrderServiceManager>();

            // JWT Authentications

            builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
               .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters =
                        new TokenValidationParameters
                        {
                            ValidateIssuer = true,

                            ValidateAudience = true,

                            ValidateLifetime = true,

                            ValidateIssuerSigningKey = true,

                            ValidIssuer = builder.Configuration["Jwt:Issuer"]!,

                            ValidAudience = builder.Configuration["Jwt:Audience"]!,

                            IssuerSigningKey =
                                new SymmetricSecurityKey(
                                    Encoding.UTF8.GetBytes(
                                        builder.Configuration["Jwt:Key"]!))
                        };
                });
            // Authorization
            builder.Services.AddAuthorization();

            // CORS
           
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAngular",policy => {
                        policy.WithOrigins("http://localhost:4200")
                            .AllowAnyHeader()
                            .AllowAnyMethod();
                    });
            });

            // HttpClient communicate with product service
            builder.Services.AddHttpClient();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            // Swagger MiddleWare COnfiguration
            if (app.Environment.IsDevelopment())
            {
                app.MapOpenApi();
                app.UseSwagger();
                app.UseSwaggerUI();
            }
            // HTTPS
      //   app.UseHttpsRedirection();
            //ECEPTION MIDLEWARE
            app.UseMiddleware<ExceptionMiddleware>();
            //CORS
            app.UseCors("AllowAngular");
            // Authentication
            app.UseAuthentication();
            // Authorization
            app.UseAuthorization();

            // Controllers
            app.MapControllers();
            //Docker Compose purpose we used  
            using (var scope = app.Services.CreateScope())
            {
                var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

                db.Database.Migrate();
            }

            app.Run();
        }
    }
}
