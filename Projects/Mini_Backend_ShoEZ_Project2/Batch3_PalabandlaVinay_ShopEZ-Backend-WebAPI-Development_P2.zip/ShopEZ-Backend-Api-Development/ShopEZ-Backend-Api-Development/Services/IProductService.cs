﻿using ShopEZ_Backend_Api_Development.DTOs;
using ShopEZ_Backend_Api_Development.Models;

public interface IProductService
{
    Task<IEnumerable<Product>> GetAllAsync();
    Task<Product> GetByIdAsync(int id);
    Task AddAsync(ProductDTO dto);
    Task UpdateAsync(int id, ProductDTO dto);
    Task<bool> DeleteAsync(int id);
}