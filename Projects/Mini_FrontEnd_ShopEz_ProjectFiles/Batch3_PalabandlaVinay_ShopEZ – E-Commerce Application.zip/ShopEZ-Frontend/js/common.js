
$(document).ready(function () {

  // Get cart data
  var cart = JSON.parse(localStorage.getItem("cart")) || [];

  // Calculate total quantity
  var count = 0;
  for (var i = 0; i < cart.length; i++) {
    count += cart[i].qty;
  }

  // Get current page name
  var page = window.location.pathname.split("/").pop();

  // Set active class
  var homeActive = page === "index.html" ? "active fw-bold" : "";
  var productActive = page === "products.html" ? "active fw-bold" : "";
  var cartActive = page === "cart.html" ? "active fw-bold" : "";

  // Navbar HTML
  var nav = `
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <div class="container">

        <a class="navbar-brand fw-bold" href="index.html">ShopEZ</a>

        <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navMenu">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navMenu">
          <ul class="navbar-nav ms-auto">

            <li class="nav-item">
              <a class="nav-link ${homeActive}" href="index.html">Home</a>
            </li>

            <li class="nav-item">
              <a class="nav-link ${productActive}" href="products.html">Products</a>
            </li>

            <li class="nav-item">
              <a class="nav-link ${cartActive}" href="cart.html">
                Cart
                <span class="badge bg-warning text-dark">${count}</span>
              </a>
            </li>

          </ul>
        </div>

      </div>
    </nav>
  `;

  // Insert navbar
  $("#navbar").html(nav);

});