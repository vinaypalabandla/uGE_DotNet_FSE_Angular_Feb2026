﻿// Import namespaces
using Microsoft.AspNetCore.Mvc;
using ShopEZ.UserService.DTOs;
using ShopEZ.UserService.Services;
//using Microsoft.AspNetCore.Http;

namespace ShopEZ.UserService.Controllers
{
    // Route
    [Route("api/[controller]")]
    // API Controller
    [ApiController]
    public class AuthController : ControllerBase
    {

        // AuthService Object
        private readonly IAuthService _service;

        // Constructor Injection
        public AuthController(IAuthService service)
        {
            _service = service;
        }

       //Register Api
        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterDTO dto)
        {
            try
            {
                // Call to  the  service
                var result = await _service.Register(dto);

                // Return success response
                return Ok(new
                {
                    message = result
                });
            }
            catch (Exception ex)
            {
                // Return error
                return BadRequest(ex.Message);
            }
        }

        // login api logic here 
       
        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDTO dto)
        {
            try
            {
                // Login Response
                var result = await _service.Login(dto);

                // Return Full Response
                return Ok(result);
            }
            catch (Exception ex)
            {
                // Return error
                return BadRequest(ex.Message);
            }
        }

    }
}
