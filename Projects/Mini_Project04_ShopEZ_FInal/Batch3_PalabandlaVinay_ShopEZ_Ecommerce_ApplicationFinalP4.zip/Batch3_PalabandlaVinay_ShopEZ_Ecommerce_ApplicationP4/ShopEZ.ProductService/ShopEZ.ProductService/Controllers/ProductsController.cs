﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


using ShopEZ.ProductService.DTOs;
using ShopEZ.ProductService.Services;

namespace ShopEZ.ProductService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
 //  [Authorize]
    public class ProductsController : ControllerBase
    {
        // Product Service Object
        private readonly IProductServiceManager _service;

        // Constructor injecting di
        public ProductsController(IProductServiceManager service)
        {
            _service = service;
        }
        //GET ALL PRODUCTS==> GET /api/products
        [HttpGet]
        public async Task<IActionResult>  GetAllProducts()
        {
            var products = await _service.GetAllProducts();

            return Ok(products);
        }

        //GET PRODUCT BY ID -->GET /api/products/1
        [HttpGet("{id}")]
        public async Task<IActionResult> GetProductById(int id)
        {
            var product =await _service.GetProductById(id);

            return Ok(product);
        }
        //ADD PRODUCT
        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> AddProduct(ProductDTO dto)
        {
            var result =await _service.AddProduct(dto);

            return Ok(new
            {
                message ="Product Added Successfully"
            });
        }
        //UPDATE PRODUCT
        [Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public async Task<IActionResult>  UpdateProduct( int id,  ProductDTO dto)
        {
            var result = await _service.UpdateProduct(id,dto);

            return Ok(new
            {
                message ="Product Updated Successfully"
            });
        }
        //DELETE PRODUCT
        [Authorize(Roles = "Admin")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var result =await _service.DeleteProduct(id);

            return Ok(new
            {
                message = "Product Deleted Successfully"
            });
        }

        //SEARCH PRODUCTS
        [HttpGet("search")]
        public async Task<IActionResult> SearchProducts(string name)
        {
            var products = await _service.SearchProducts(name);

            return Ok(products);
        }

       //FILTER CATEGORY WIASED
        [HttpGet("category")]
        public async Task<IActionResult> GetProductsByCategory(string category)
        {
            var products = await _service.GetProductsByCategory(category);

            return Ok(products);
        }
        //PAGINATION LOGIc
        [HttpGet("pagination")]
        public async Task<IActionResult> GetPaginatedProducts( int pageNumber = 1,int pageSize = 5)
        {
            var products = await _service.GetPaginatedProducts( pageNumber,pageSize);
              return Ok(products);
        }
        // REDUCE STOCK
        [HttpPut("reduce-stock")]
        public async Task<IActionResult> ReduceStock(int productId,int quantity)
        {
            var result = await _service.ReduceStock(productId, quantity);
            if (result > 0)
            {
                return Ok(new
                {
                    message = "Stock Reduced Successfully"
                });
            }

            return BadRequest(new
            {
                message = "Stock Not Available"
            });
        }
    }
}